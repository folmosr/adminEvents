/**
Codigo Global
*/

/**
 Configuración del objeto ajax
*/
$.ajaxSetup({
           type: "GET",
           dataType: "json",
           contentType: "application/x-www-form-urlencoded",
           timeout:10000,
           async:true
});


function geThan(field, rules, i, options){
 var a=rules[i+2];
 if(parseFloat(field.val()) < parseFloat( jQuery("#"+a).val() ) ){
   return "El valor para el campo \"Rango de Participación (Fin)\" debe ser mayor al campo \"Rango de Participación (inicio)\"."
 }
}											

function confirm_action()
{
	if(!confirm('Esta seguro de realizar esta acción'))
	  return false;
	 else
	   return true; 
}


function marcar()
{
	var ele = $('.inner-list > .checkbox > input[type=checkbox]');	
	ele.each(function(  ) {
				$(this).prop("checked", true);
		});
}

function desmarcar()
{
	var ele = $('.inner-list > .checkbox > input[type=checkbox]');	
	ele.each(function(  ) {
				$(this).prop("checked", false);
		});
	
}

function marcar_nw(e)
{
	var ele = $('.inner-list >  .form-element  > input[type=checkbox]');	
	ele.each(function(  ) {
				$(this).prop("checked", true);
		});
	e.preventDefault();
}

function desmarcar_nw(e)
{
	var ele = $('.inner-list > .form-element > input[type=checkbox]');	
	ele.each(function(  ) {
				$(this).prop("checked", false);
		});
	e.preventDefault();
}


function lista_categorias(parentId)
{
	$("#categoria-disc-"+parentId).modal();
	return false;
}

function limitGrupos()
{
	var activador = $('#CaracteristicaActivarGrupo');
	if(parseInt( $('#CaracteristicaNGrupo').val()) == 0)
		$('#CaracteristicaNGrupo').val(null);
	if(parseInt( $('#CaracteristicaPGrupo').val()) == 0)
		$('#CaracteristicaPGrupo').val(null);
	activador.click(function() {
			if($(this).prop('checked')){
					  $('#CaracteristicaPGrupo').val(null);
					  $('#CaracteristicaNGrupo').val(null);
					  $('#CaracteristicaPGrupo').prop('disabled', false);
					  $('#CaracteristicaNGrupo').prop('disabled', false);
					  $('#CaracteristicaPGrupo').attr('class', 'validate[required,custom[integer],minsize[1],maxSize[2]]');
					  $('#CaracteristicaNGrupo').attr('class', 'validate[required,custom[integer],minsize[1],maxSize[2]]');
				}else{
					  $('#CaracteristicaPGrupo').val(null);
					  $('#CaracteristicaNGrupo').val(null);
					  $('#CaracteristicaPGrupo').prop('disabled', true);
					  $('#CaracteristicaNGrupo').prop('disabled', true);
					  $('#CaracteristicaPGrupo').removeAttr('class');
					  $('#CaracteristicaNGrupo').removeAttr('class');
			}
	});
}
/*
* Dibuja dataTable en 
* formato simple
*/
function simpleDataTableForEventos(Base){
	var oTable = $("#eventos").dataTable( {
		"bPaginate": false,
		"bLengthChange": false,
		"bFilter": true,
		"bInfo": false,
		"bAutoWidth": false ,
		"bProcessing": true,
		"bServerSide": true,
		"sScrollY": "750px",
		"bScrollCollapse": true,
		"sDom": '<"top"i>rt<"bottom"flp><"clear">',
		"sAjaxSource": Base+"eventos/dataTableFilter",
		 "aoColumnDefs": [
					  { "bSearchable": false, "bSortable": true,"aTargets": [ 0 ], "sWidth": "5%" },
					  { "bSearchable": true, "bSortable": true,"aTargets": [ 1 ], "sWidth": "35%" },
					  { "bSearchable": false, "bSortable": false, "aTargets": [ 2 ], "sWidth": "5%" ,"mRender": function (  data, type, full) {
								var title = 'Evento Activo';
								if(!parseInt(data) == 1)
									title = 'Evento No Activo';
									return '<img src="'+Base+'img/icons/info-check.png" border="0" title="'+title+'" rel="status" value="'+data+'"  />';  
								
						    },
							"fnCreatedCell": function (nTd, sData, oData, iRow, iCol) {
									$(nTd).removeAttr('css');
									if ( parseInt(oData[2]) == 1 )
									  	$(nTd).addClass('activate-event');
										else
										  	$(nTd).addClass('desactivate-event');
								  }							
						 },
						 					 { "bSearchable": false, "bSortable": true,"aTargets": [ 3 ], "sWidth": "5%" },
					  { "bSearchable": false, "bSortable": false, "aTargets": [ 4 ],  "mData": 0, "mRender": function (  data, type, full) {   
					  		var html  = '<a href="#"><img src="'+Base+'img/icons/Document-text-edit-32.png" rel="'+AsciiToHex(base64_encode(data))+'" border="0" title="Editar datos del evento" onclick="eDataEvent($(this), \''+Base+'\', event);"></a>';
								html +='<a href="#"><img src="'+Base+'img/icons/inspector.png" border="0"   rel="'+AsciiToHex(base64_encode(data))+'" title="Ver detalles del evento" onclick="sDataEvent($(this), \''+Base+'\', event, $(\'#DDva\'), \'evento\');"></a>';
								html +='<a href="#"><img src="'+Base+'img/icons/List-File-256.png"          rel="'+AsciiToHex(base64_encode(data))+'" border="0" title="Ver datos deportivos"  onclick="sDataEvent($(this), \''+Base+'\', event, $(\'#DDva\'), \'modalidad\');"></a>';
								html +='<a href="'+Base+'credenciales/crear/'+AsciiToHex(base64_encode(data))+'"><img src="'+Base+'img/icons/identity.png" border="0"     rel="'+AsciiToHex(base64_encode(data))+'" title="Asignación de credenciales"></a>';
								html +='<a href="'+Base+'credenciales/filtrar/'+AsciiToHex(base64_encode(data))+'"><img src="'+Base+'img/icons/Pdf-256.png" border="0"     rel="'+AsciiToHex(base64_encode(data))+'" title="Impresión de credenciales"></a>';
								html +='<a href="'+Base+'conjuntos/imprimir/'+AsciiToHex(base64_encode(data))+'"><img src="'+Base+'img/icons/Pdf-256.png" width="24"  border="0"     rel="'+AsciiToHex(base64_encode(data))+'" title="Impresión de Equipos"></a>';							
                            	html +='<a href="'+Base+'eventos/q_on/'+AsciiToHex(base64_encode(data))+'"><img src="'+Base+'img/icons/on_off.png" border="0"      rel="'+AsciiToHex(base64_encode(data))+'" title="Activar/Desactivar evento" onclick="return confirm_action();"></a>';

						  	return html;   
						} 
								
					}
					

					
		],
		
		 "oLanguage": {
					 "sSearch": "<b>Evento (Nombre):</b>"
			}
		} ).fnSetFilteringDelay();
}


/*
 Presenta ventana con detalle del 
 evento
*/
function sDataEvent(ob, base, evt, HTMLDIVControl, mod)
{
	 evt.preventDefault();

	 HTMLDIVControl.modal({
			onShow: function (dlg) {
					$(dlg.wrap).css('overflow', 'auto'); // or try jQuery.modal.update();
				},		 
		 });
	 $.ajax({

			 	 url :base+'eventos/full/'+ob.attr('rel')+'/'+AsciiToHex(base64_encode(mod)),
				
				 
      		  beforeSend:function(){
					 HTMLDIVControl.empty();
					 HTMLDIVControl.append('<center><img src="'+base+'img/loader.gif" border="0" style="margin-top:245px;"/></center>');
		   	  },
     		  success:function(Json){
				 HTMLDIVControl.empty();
				 if(mod == 'evento')
				{
					 var html = 			'<div id="data_evento"><div class="basico"><h3>Datos Generales</h3><div class="left"><div><table cellpadding="0" cellspacing="0">'+
											'<tr style="background:#f4f4f4"><td colspan="2">'+Json['Evento']['nombre']+'</td></tr>'+
											'<tr style="background:#ddd"><td colspan="2">'+Json['Evento']['f_inicio']+' (Fecha de Iniciación)</td>'+
											'<tr style="background:#ddd"><td colspan="2">'+Json['Evento']['f_fin']+' (Fecha de Culminación)</td></tr>'+
											'<tr style="background:#fff; height:30px"><td colspan="2"></td></tr>'+
											'<tr style="background:#f4f4f4"><td colspan="2"><b>Funciones Habilitadas</b></td></tr>';
						html+= ShowSkill(Json['Caracteristica'], base);
						html+='</table></div></div><div class="right"><img src="'+base+'img/img_eventos/'+Json['Evento']['imagen']+'" /></div>'+
							  '<div class="clear"></div>'+
							  '<div id="desc_evento"><h3>Descripción de Evento</h3>'+Json['Evento']['descripcion']+'</div></div>';
				}
				if(mod == 'modalidad'){
	
						var html = '<div id="datos_deportivos"><div class="basico"><h3>Datos Deportivos</h3><table width="100%" cellpadding="0" cellspacing="0"><thead>'+
								   '<td width="50">#</td><td width="230">Disciplina</td><td width="230">Modalidad</td><td width="200">Acciones</td></thead><tbody>';
						if(!Json.length > 0)
							html+='<tr><td colspan="6"><b>El Evento</b> no posee <b>disciplinas</b> asociadas</td></tr>';	
						else{
							var color='#f4f4f4';
							for(var i in Json  ){
								 color = (color=='#f4f4f4')?'#ddd':'#f4f4f4';
								 html+='<tr style="background:'+ color +'"><td width="50" align="center"><b>'+Json[i]['DisciplinasEvento']['id']+'</b></td>'+
                        			   '<td width="230">'+Json[i]['Disciplina']['descripcion']+'</td>'+
                        			   '<td width="230" >'+Json[i]['Modalidad']['descripcion']+'</td>'+
                        			   '<td width="200" align="center" ><a href="'+base+'CategoriasDisciplinasEventos/add/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'"><img src="'+base+'img/icons/document_text_add-128.png" title="Asociar categoría(s)" /></a>'+							
									   '<a href="#"><img src="'+base+'img/icons/List-File-256.png" title="Listar categorías asociadas" rel="'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'" srel="'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'"  onclick="sDataEvent($(this), \''+base+'\', event, $(\'#DDva\'), \'categoria\');" /></a>'+
									   '<a href="'+base+'DisciplinasEventos/edit/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'"><img src="'+base+'img/icons/Document-text-edit-32.png" title="Editar datos de disciplina" /></a>'+
									   '<a href="'+base+'DisciplinasEventos/discard/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'" onclick="return confirm_action();"><img src="'+base+'img/icons/Trash-256.png" title="Descartar disciplina" /></a>'+
									   '<a href="'+base+'DisciplinasEventos/imprimir_excel/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'"><img src="'+base+'img/icons/xls-512.png" title="Descargar registrados" /></a>'+
				 					   '<a href="'+base+'DisciplinasEventos/imprimir/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['evento_id'])))+'"><img src="'+base+'img/icons/Pdf-256.png" title="Descargar registrados" /></a></td></tr>';
								}
								html+='</tbody></table>';
							  } 
						}
						if(mod == 'categoria'){
							 var html = '<div id="datos_deportivos"><div class="basico"><h3>Categorías Asociadas</h3><p><a herf="#" rel="'+ob.attr('srel')+'" border="0"  onclick="sDataEvent($(this), \''+base+'\', event, $(\'#DDva\'), \'modalidad\');" style="cursor:pointer">Volver al Listado de Disciplinas</a></p><table width="100%" cellpadding="0" cellspacing="0"><thead>'+
				                		'<td width="45">#</td><td width="200">Categoría</td><td width="45" title="Límite Atletas Masculino">Atl. M.</td>'+
                						'<td width="45" title="Límite Atletas Femenino">Atl. F.</td><td width="45" title="Límite Entrenadores">Entr.</td>'+
							            '<td width="45" title="Límite Delegados">Deleg.</td><td width="45" title="Límite Acompañantes">Acomp.</td>'+
                						'<td width="45" title="Límite Voluntarios">Volun.</td><td width="45" title="Rango inicio de participación">R. Inicio</td>'+
										'<td width="45" title="Rango fin de participación">R. Fin</td><td width="150">Acciones</td></thead><tbody>';
							var color='#f4f4f4';
							if(!Json.length > 0)
							{
								html+='<tr><td colspan="9">Esta <b>disciplina</b> no posee <b>categorías</b> asociadas</td></tr>';
							}else{
								
								for(var i in Json)
								{
									var cm = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['cantidad_m']:'Sin Límite';
									var cf = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['cantidad_f']:'Sin Límite';
									var en = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['entrenador']:'Sin Límite';
									var de = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['delegado']:'Sin Límite';
									var ac = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['acompanante']:'Sin Límite';
									var vo = (Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true)?Json[i]['CategoriasDisciplinasEvento']['voluntario']:'Sin Límite';
									var ri = Json[i]['CategoriasDisciplinasEvento']['nparticipacion_ini'];
									var rf = Json[i]['CategoriasDisciplinasEvento']['nparticipacion_fin'];																 
	
									color = (color=='#f4f4f4')?'#ddd':'#f4f4f4';
									html+= '<tr  style="background:'+ color +'"><td width="40" align="center">'+Json[i]['CategoriasDisciplinasEvento']['id']+'</td>'+
																		'<td width="100">'+Json[i]['Categoria']['descripcion']+'</td>'+
																		'<td width="45" align="center">'+cm+'</td>'+
																		'<td width="45" align="center">'+cf+'</td>'+
																		'<td width="45" align="center">'+en+'</td>'+
																		'<td width="45" align="center">'+de+'</td>'+
																		'<td width="45" align="center">'+ac+'</td>'+
																		'<td width="45" align="center">'+vo+'</td>'+
																		'<td width="45" align="center">'+ri+'</td>'+
																		'<td width="45" align="center">'+rf+'</td>'+
																		'<td width="250" align="center">';
																//if(Boolean(Json[i]['DisciplinasEvento']['Evento']['Caracteristica']['activar_limite'])== true){
																	
																	html+= '<a href="'+base+'CategoriasDisciplinasEventos/edit/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['Evento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['CategoriasDisciplinasEvento']['id'])))+'"><img src="'+base+'img/icons/Document-text-edit-32.png" title="Editar datos de categoría" /></a>'+
																		   '<a href="'+base+'CategoriasDisciplinasEventos/discard/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['Evento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['CategoriasDisciplinasEvento']['id'])))+'" onclick = "return confirm_action();"><img src="'+base+'img/icons/Trash-256.png" title="Descartar categoría" /></a>'+
																		   '<a href="'+base+'CategoriasDisciplinasEventos/imprimir_excel/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['Evento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['CategoriasDisciplinasEvento']['id'])))+'"><img src="'+base+'img/icons/xls-512.png" title="Descargar registrados" /></a>'+
																	   '<a href="'+base+'CategoriasDisciplinasEventos/imprimir/'+AsciiToHex(base64_encode(String(Json[i]['DisciplinasEvento']['Evento']['id'])))+'/'+AsciiToHex(base64_encode(String(Json[i]['CategoriasDisciplinasEvento']['id'])))+'"><img src="'+base+'img/icons/Pdf-256.png" title="Descargar Registrados" /></a>';
																//}
								}
						}
					}
				HTMLDIVControl.append(html);
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					  console.log(textStatus, errorThrown);
				}
	  });
}



/*
 Transporta los datos del evento
 para ser editados
*/
function eDataEvent(ob, base, evt)
{
	evt.preventDefault();
	window.location.href=base+"eventos/editar/"+ob.attr('rel');
}

// convert an ascii string to its hex representation
function AsciiToHex(ascii)
{
  var hex = '';
  for(i = 0; i < strlen(ascii); i++)
         hex+= str_pad(base_convert(ord(ascii[i]), 10, 16), 2, '0', 'STR_PAD_LEFT');
      return hex;
 }

// convert a hex string to ascii, prepend with '0' if input is not an even number
// of characters in length   
function HexToAscii(hex)
{
      var ascii = ''; 
      if (strlen(hex) % 2 == 1)
         hex = '0'+hex;
      
	  for(i = 0; i < strlen(hex); i += 2)
         ascii+= chr(base_convert(substr(hex, i, 2), 16, 10));
   
      return ascii;
   }

/*
*
*
*/
function initTimePicker()
{
var startDateTextBox = $('#EventoFInicio');
var endDateTextBox = $('#EventoFFin');

startDateTextBox.datetimepicker({ 
	timeFormat: 'HH:mm',
	onClose: function(dateText, inst) {
		if (endDateTextBox.val() != '') {
			var testStartDate = startDateTextBox.datetimepicker('getDate');
			var testEndDate = endDateTextBox.datetimepicker('getDate');
			if (testStartDate > testEndDate)
				endDateTextBox.datetimepicker('setDate', testStartDate);
		}
		else {
			endDateTextBox.val(dateText);
		}
	},
	onSelect: function (selectedDateTime){
		endDateTextBox.datetimepicker('option', 'minDate', startDateTextBox.datetimepicker('getDate') );
	}
});
endDateTextBox.datetimepicker({ 
	timeFormat: 'HH:mm',
	onClose: function(dateText, inst) {
		if (startDateTextBox.val() != '') {
			var testStartDate = startDateTextBox.datetimepicker('getDate');
			var testEndDate = endDateTextBox.datetimepicker('getDate');
			if (testStartDate > testEndDate)
				startDateTextBox.datetimepicker('setDate', testEndDate);
		}
		else {
			startDateTextBox.val(dateText);
		}
	},
	onSelect: function (selectedDateTime){
		startDateTextBox.datetimepicker('option', 'maxDate', endDateTextBox.datetimepicker('getDate') );
	}
});	
}

/*

*/
function ShowSkill(array, base)
{
	var indexes = new Array()  ;
		indexes['activar_foto']     = 'Permitir carga de foto';
		indexes['activar_grupo']    =	'Permitir agrupación de participantes';
		indexes['activar_menor']    =	'Permitir participación de menor de edad';
		indexes['activar_limite']   =	'Limitar Nº de participantes';
		indexes['activar_personal'] =	'Permitir registro de personal';
	var html  = null;
	var color = '#f4f4f4'; 
		$.each(array, function( index, value ) {
		  	color = (color=='#f4f4f4')?'#ddd':'#f4f4f4';
			if(html == null){
				html =  '<tr style="background:'+color+'"><td >'+indexes[index]+'</td><td>';
				html += (Boolean(value)== true)?'<img src="'+base+'img/icons/check.png" border="0" />':'<img src="'+base+'img/icons/uncheck.png" border="0" />';
				html += '</td></tr>';
			}else{
				html +=  '<tr style="background:'+color+'"><td >'+indexes[index]+'</td><td>';
				html += (Boolean(value)== true)?'<img src="'+base+'img/icons/check.png" border="0" />':'<img src="'+base+'img/icons/uncheck.png" border="0" />';
				html += '</td></tr>';
			}
		});		
  return html;		
}


/*
* obtiene nodos xml con el 
* fin de llenar lista
*
*/
function get_personal_list(key, model, fieldcondition, request, control){
	   
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+key+'/'+model +'/'+fieldcondition,
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
				 control.empty();
			  	 control.append($('<option>', {
								value: null,
								text: '[Seleccionar]'
				 }));
				 $(Xml).find('Element').each(function(){
						control.append($("<option></option>")
										 .attr("value",$(this).attr('key'))
										 .text($(this).text())); 
							});
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}



/*
* obtiene nodos xml con el 
* fin de llenar lista
*
*/
function get_list(key, basemodel, model, fieldcondition, request, control){
	   
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+key+'/'+basemodel+'/'+model +'/'+fieldcondition,
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
				 control.empty();
			  	 control.append($('<option>', {
								value: null,
								text: '[Seleccionar]'
				 }));
				 $(Xml).find('Element').each(function(){
						control.append($("<option></option>")
										 .attr("value",$(this).attr('key'))
										 .text($(this).text())); 
							});
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}

/*
* obtiene nodos xml con el 
* fin de llenar lista
*
*/
function get_advanced_list(key, basemodel, model, fieldcondition, request, control, selectedValue){
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+key+'/'+basemodel+'/'+model +'/'+fieldcondition,
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
				 control.empty();
			  	 control.append($('<option>', {
								value: null,
								text: '[Seleccionar]'
				 }));
				 $(Xml).find('Element').each(function(){
						control.append($("<option></option>")
										 .attr("value",$(this).attr('key'))
										 .text($(this).text())); 
							});
			  },
			  complete:function(){
				  control.val(selectedValue);
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}

function get_limited_list(mod_id, disc_id, func_id, request, control, flag, number_action_request, menor){
	  
	  var edad = parseInt($('#PersonaEdad').val()); 
	  var c = 0; 
	  var d = 0;
	  var RangeIni = 0;
	  var RangeFin = 0;
	  var keyVal = 0;
	  var rIni = 0;
	  var rFin = 0;
	
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+func_id+'/'+mod_id+'/'+disc_id+'/'+flag+'/'+menor+'/',
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
     		 		
				 control.empty();
				 control.append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
				if( $(Xml).find('Element').length > 0)
				{
						 $(Xml).find('Element').each(function(){
								rIni   	 = parseInt($(this).attr("ini"));
								rFin  	 = parseInt($(this).attr("fin"));

								if((edad >=rIni) && (edad <=rFin)){
										//console.log(edad+''+rIni+''+rFin);
										control.append($("<option></option>")
														 .attr("selected","selected")
														 .attr("value",$(this).attr('key'))
														 .text($(this).text())); 
										
										$("#CategoriasDisciplinasEventoId").val(AsciiToHex(base64_encode($(this).attr('key'))));			 
										
										$("#CategoriasDisciplinasEventoOtrasCategoriaId").append(
														 $("<option></option>")
														 .attr("value",$(this).attr('key'))
														 .attr("data-inicio",$(this).attr("ini"))
														 .attr("data-fin",$(this).attr("fin"))
														 .text($(this).text())										
												);
										c++;
			                                 RangeIni = parseInt($(this).attr("nparticipacion_ini"));
							                 RangeFin = parseInt($(this).attr("nparticipacion_fin"));
							             	 keyVal   = parseInt($(this).attr("key")); 
								}else{
											control.append($("<option></option>")
														 .attr("value",$(this).attr('key'))
														 .text($(this).text()));
										if((rIni == 0) || (rFin == 0))	{							
												$("#CategoriasDisciplinasEventoOtrasCategoriaId").append(
														 $("<option></option>")
														 .attr("value",$(this).attr('key'))
														 .attr("data-inicio",$(this).attr("nparticipacion_ini"))
														 .attr("data-fin",$(this).attr("nparticipacion_fin"))
														 .text($(this).text())										
												);
											d++;	
										}
								}
						});
						
						if((d > 0)||(c >1))
							$("#CategoriasDisciplinasEventoOtrasCategoriaId").parent().show("slow");
						rIni = null;
						rFin = null;
				}else{
						$(".alerta").html('<p>Los cupos para este evento se han agotado, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
						$(".alerta").show('slow');
						$('input[type=submit]').attr('disabled', 'disabled');
				}
			  },
			  complete:function() {
			  	  
				   if(c == 0)
				   {
				       
				         
					$(".alerta").html('<p>La edad calculada no se encuentra dentro de la categorías establecidad para este evento, contacta al <a href="/acredinweb/contactos/">Administrador</a> para más detalles.</p>');
					$(".alerta").show('slow');
					setTimeout(function() {
							$(".alerta").fadeOut('slow');
						}, 8000);
					$('input[type=submit]').attr('disabled', 'disabled');
						
				   }else
				     SetActionNumber(keyVal, RangeIni, RangeFin, number_action_request);  
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}

function SetActionNumber(keyVal, RangeIni, RangeFin, request)
{
	
	 var flag = true; 
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+'/'+keyVal+'/'+RangeIni+'/'+RangeFin+'/',
              dataType: "xml",
     		  success:function(Xml){
				  var r = $(Xml).find('numero').text();
				  if(parseInt(r))
				  	$('#EventosPersonaNParticipacion').val(AsciiToHex(base64_encode(r)));
					else{
						flag = false;
						$(".alerta").html('<p>Los números de particpación en esta categpría fueron agotados, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
						$(".alerta").show('slow');
						setTimeout(function() {
								$(".alerta").fadeOut('slow');
							}, 8000);
					}
			  },
			  complete:function() {
				  if(flag)
				  $("input[type=submit]").removeAttr('disabled');
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
				   console.log(errorThrown);			  
				}
	  });

}


function get_limited_list_by_funcion(mod_id, disc_id, func_id, request, control, flag){
  	 var flag = true; 
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+func_id+'/'+mod_id+'/'+disc_id+'/'+flag+'/',
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
				 control.empty();
				 control.append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
				if( $(Xml).find('Element').length > 0)
				{
						 $(Xml).find('Element').each(function(){
										control.append($("<option></option>")
														 .attr("value",$(this).attr('key'))
														 .text($(this).text())); 
						});
				}else{
						flag = false;
						$(".alerta").html('<p>Los cupos para este evento se han agotado, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
						$(".alerta").show('slow');
						setTimeout(function() {
							$(".alerta").fadeOut('slow');
						}, 8000);
				}
			  },
			  complete:function() {
				  if(flag)
				  $("input[type=submit]").removeAttr('disabled');
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}

/*
----------Funcion para obtener la edad------------
*/
/*function calcular_edad(fecha) {
	var fechaActual = new Date()
	var diaActual = fechaActual.getDate();
	var mmActual = fechaActual.getMonth() + 1;
	var yyyyActual = fechaActual.getFullYear();
	
	FechaNac = fecha.split("/");
	var diaCumple = FechaNac[0];
	var mmCumple = FechaNac[1];
	var yyyyCumple = FechaNac[2];

	//retiramos el primer cero de la izquierda
	if (mmCumple.substr(0,1) == 0) {
		mmCumple= mmCumple.substring(1, 2);
	}
	//retiramos el primer cero de la izquierda
	if (diaCumple.substr(0, 1) == 0) {
		diaCumple = diaCumple.substring(1, 2);
	}
	
	var edad = yyyyActual - yyyyCumple;

	//validamos si el mes de cumpleaños es menor al actual
	//o si el mes de cumpleaños es igual al actual
	//y el dia actual es menor al del nacimiento
	//De ser asi, se resta un año
	if ((mmActual < mmCumple) || (mmActual == mmCumple && diaActual < diaCumple)) {
		edad--;
	}
	return edad;
};
*/

/**
 * Esta función calcula la edad de una persona y los meses
 * La fecha la tiene que tener el formato yyyy-mm-dd que es
 * metodo que por defecto lo devuelve el <input type="date">
 */
function calcular_edad(fecha)
{

   
        // Si la fecha es correcta, calculamos la edad
        var values=fecha.split("/");
        var dia = values[0];
        var mes = values[1];
        var ano = values[2];

        // cogemos los valores actuales
        var fecha_hoy = new Date();
        var ahora_ano = fecha_hoy.getYear();
        var ahora_mes = fecha_hoy.getMonth()+1;
        var ahora_dia = fecha_hoy.getDate();
 
        // realizamos el calculo
        var edad = (ahora_ano + 1900) - ano;

       /* if ( ahora_mes < mes )
        {
            edad--;
        }
        if ((mes == ahora_mes) && (ahora_dia < dia))
        {
            edad--;
        }
        if (edad > 1900)
        {
            edad -= 1900;
        }*/
        return edad;
   
}

function initWebCam(base_url, controller)
{
	var camera = $('#camera'),
		photos = $('#photos'),
		screen =  $('#screen');

	var template = '<a href='+base_url+'"photos/final/{src}" rel="cam" '
		+'style="background-image:url('+base_url+'photos/final/{src})"></a>';



	$("img[rel=showup_cam]").click(function (e) {
		$("#camera").modal();
		return false;
	});

	/*----------------------------------
		Setting up the web camera
	----------------------------------*/


	webcam.set_swf_url(base_url+'js/webcam/webcam.swf');
	webcam.set_api_url(base_url+base64_decode(HexToAscii(controller))+'/sendup');	// The upload script
	webcam.set_quality(100);				// JPEG Photo Quality
	webcam.set_shutter_sound(true, base_url+'js/webcam/shutter.mp3');

	// Generating the embed code and adding it to the page:	
	screen.html(
		webcam.get_html(screen.width(), screen.height())
	);


	/*----------------------------------
		Binding event listeners
	----------------------------------*/


	var shootEnabled = false;
		
	$('#shootButton').click(function(){
		
		if(!shootEnabled){
			return false;
		}
		
		webcam.freeze();
		togglePane();
		return false;
	});
	
	$('#cancelButton').click(function(){
		webcam.reset();
		togglePane();
		return false;
	});
	
	$('#uploadButton').click(function(){
		webcam.upload();
		webcam.reset();
		togglePane();
		return false;
	});

	camera.find('.settings').click(function(){
		if(!shootEnabled){
			return false;
		}
		
		webcam.configure('camera');
	});

	

	/*---------------------- 
		Callbacks
	----------------------*/
	
	
	webcam.set_hook('onLoad',function(){
		// When the flash loads, enable
		// the Shoot and settings buttons:
		shootEnabled = true;
	});
	
	webcam.set_hook('onComplete', function(msg){
		
		// This response is returned by upload.php
		// and it holds the name of the image in a
		// JSON object format:
		msg = $.parseJSON(msg);
		
		if(msg.error){
			alert(msg.message);
		}
		else {
			alert("Foto Cargada!");
			// Adding it to the page;
			photos.prepend(templateReplace(template,{src:msg.filename}));
			var tmp = $('#PersonaFotocam').val();
			$('#EventosPersonaFoto').val(null);
			$('.upphoto').attr('style', 'display:none');
			$('.showphoto').attr('style', 'display:block');
			$('.showphoto > .fleft').html('<span><img src="'+base_url+'img/photos/final/'+msg.filename+'" border="0"/></span>');
			$('.showphoto > .fright').html('<a href="#" file="'+(msg.filename.substr(0, msg.filename.indexOf('.')))+'" onclick="showuploaderpanel(\''+base_url+'\', \''+controller+'\', $(this), event, \''+tmp+'\');"><img src="'+base_url+'img/upload_arrow_up.png" title="Descartar foto/Cargar foto" border="0"/></a>');			
			$('#PersonaFotocam').val(msg.filename);
		}
	});
	
	webcam.set_hook('onError',function(e){
		screen.html(e);
	});
}


function showuploaderpanel(base_url, controller, o, evt, tmp)
{
	  evt.preventDefault(); 	
	  $.ajax({
			  url :base_url+base64_decode(HexToAscii(controller))+'/discard_file/'+o.attr('file'),
	 		  success:function(Json){
			      $('.showphoto > .fleft').html('');
				  $('.showphoto > .fright').html('');
				  $('#PersonaFotocam').val(tmp);
				  $('.upphoto').attr('style', 'display:block');
				   $('.showphoto').attr('style', 'display:none');
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
						alert("Ha ocurrido un error durante el proceso.");
				}
	  });
}
/*----------------------
        Helper functions
    ------------------------*/
    // This function toggles the two
    // .buttonPane divs into visibility:

    function togglePane(){
        var visible = $('#camera .buttonPane:visible:first');
        var hidden = $('#camera .buttonPane:hidden:first');

        visible.fadeOut('fast',function(){
            hidden.show();
        });
    }

    // Helper function for replacing "{KEYWORD}" with
    // the respectful values of an object:

    function templateReplace(template,data){
        return template.replace(/{([^}]+)}/g,function(match,group){
            return data[group.toLowerCase()];
        });
 }

function check_ci_field(object)
{
	if(!parseInt(object.val()))	{
		object.validationEngine('showPrompt', 'Formato no válido', 'error', true);
		return false;
	}else{
		if((object.val().length < 6) || (object.val().length > 8)){
			object.validationEngine('showPrompt', 'Longitud en el valor para el campo \"Cédula\" es inválido', 'error', true);
			return false;
		  }
	 }
	return true;
}

function check_fields(objects)
{
	var c = 0;
	for (i = 0; i < objects.length; i++){
		if(!parseInt(objects[i].val())){
				$('#'+objects[i].attr('id')).validationEngine('showPrompt', 'Este valor es requerido antes de realizar esta acción', 'error', true);		
				c++;
		}
	}
	if(c == 0){
		for (i = 0; i < objects.length; i++){
				$('#'+objects[i].attr('id')).validationEngine('hideAll');		
			}
			return true;
		}else{
			objects[objects.length-1].prop('selectedIndex',0);
			objects[0].focus();
			return false;
		}
}

function setOption(subObj, parentObj, auxObj)
{
   parentObj.val(subObj.val());	
   if(auxObj)
   	auxObj.val(AsciiToHex(base64_encode(subObj.val())));
}

function  setIniDropDowns(obj)
{
	if(obj.attr('id')=='PersonaFuncionId')
	{
		$('#CategoriasDisciplinasEventoDisciplinaId').prop('selectedIndex',0);
		$('#CategoriasDisciplinasEventoModalidadId').prop('selectedIndex',0);
		$('#CategoriasDisciplinasEventoModalidadId').empty();
		$('#CategoriasDisciplinasEventoModalidadId').append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
		$('#CategoriasDisciplinasEventoCategoriaId').prop('selectedIndex',0);
		$('#CategoriasDisciplinasEventoCategoriaId').empty();
		$('#CategoriasDisciplinasEventoCategoriaId').append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
	}
	if(obj.attr('id')=='CategoriasDisciplinasEventoDisciplinaId')
	{
		$('#CategoriasDisciplinasEventoModalidadId').prop('selectedIndex',0);
		$('#CategoriasDisciplinasEventoCategoriaId').prop('selectedIndex',0);
		$('#CategoriasDisciplinasEventoCategoriaId').empty();
		$('#CategoriasDisciplinasEventoCategoriaId').append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').empty();
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').parent().attr('style', 'display:none');
	}
	if(obj.attr('id')=='CategoriasDisciplinasEventoModalidadId')
	{
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').empty();
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').append($("<option></option>")
								 .attr("selected","selected")
								// .attr("disabled","disabled")
								 .text("[Seleccionar]"));
		$('#CategoriasDisciplinasEventoOtrasCategoriaId').parent().attr('style', 'display:none');
	}
		if(obj.attr('id')=='CredencialDisciplinaId')
		{
			$('#CredencialModalidadId').prop('selectedIndex',0);
			$('#CredencialCategoriaId').prop('selectedIndex',0);
			$('#CredencialCategoriaId').empty();
			$('#CredencialCategoriaId').append($("<option></option>")
								 .attr("selected","selected")
								 .attr("disabled","disabled")
								 .text("[Seleccionar]"));
		}
		if(obj.attr('id')=='CredencialModalidadId')
		{
			$('#CredencialCategoriaId').empty();
			$('#CredencialCategoriaId').append($("<option></option>")
									 .attr("selected","selected")
									 .attr("disabled","disabled")
									 .text("[Seleccionar]"));
		}
}

function load_persona(obj, request, action, evt_id)
{
	  var list_request =  request+AsciiToHex(base64_encode('EventosPersonas/get_list/'))+evt_id;
	  request = base64_decode(HexToAscii(request));
	  $.ajax({
			  url :request+base64_decode(HexToAscii(action))+'/'+obj.val(),
              dataType: "xml",
			  beforeSend:function(){
  				  obj.attr('disabled', 'disabled');
				  $("#loding-message").html('<img src="'+request+'/img/loader.gif" border="0" width="20" />');
		   	  },
     		  success:function(Xml){
				   obj.removeAttr('disabled');
				   $("#loding-message").empty();
				   if( $(Xml).length > 0 )
				   {
					   var foto = $(Xml).find('foto').text();
					   get_advanced_list(
								 $(Xml).find('paise_id').text(),
								 AsciiToHex(base64_encode('EventosPersona')),
								 AsciiToHex(base64_encode('Estado')), 
								 AsciiToHex(base64_encode('pais_id')), 
								 list_request, 
								 $('#PersonaEstadoId'),
								 $(Xml).find('estado_id').text()
								);
					   get_advanced_list(
								 $(Xml).find('estado_id').text(),
								 AsciiToHex(base64_encode('EventosPersona')),
								 AsciiToHex(base64_encode('Municipio')), 
								 AsciiToHex(base64_encode('estado_id')), 
								 list_request, 
								 $('#PersonaMunicipioId'),
								 $(Xml).find('municipio_id').text()
								);
					   get_advanced_list(
								 $(Xml).find('municipio_id').text(),
								 AsciiToHex(base64_encode('EventosPersona')),
								 AsciiToHex(base64_encode('Parroquia')), 
								 AsciiToHex(base64_encode('municipio_id')), 
								 list_request, 
								 $('#PersonaParroquiaId'),
								 $(Xml).find('parroquia_id').text()
								);
								
					   $('#PersonaId').val($(Xml).find('id').text());
					   $('#PersonaCedula').val($(Xml).find('cedula').text());
					   $('#PersonaNombre').val($(Xml).find('nombre').text());
					   $('#PersonaApellido').val($(Xml).find('apellido').text());
					   $('#PersonaFNacimiento').val($(Xml).find('f_nacimiento').text());
					   $('#PersonaEdad').val(calcular_edad($(Xml).find('f_nacimiento').text()));
					   $('#PersonaGeneroId').val($(Xml).find('genero_id').text());
					   $('#PersonaGrupoId').val($(Xml).find('grupo_id').text());
					   $('#PersonaTallaId').val($(Xml).find('talla_id').text());
					   $('#PersonaPaiseId').val($(Xml).find('paise_id').text());
					   $('#PersonaCalleAv').val($(Xml).find('calle_av').text());
					   $('#PersonaSectorUrb').val($(Xml).find('sector_urb').text());
					   $('#PersonaCasaEdificio').val($(Xml).find('casa_edificio').text());
					   $('#PersonaTelLocal').val($(Xml).find('tel_local').text());
					   $('#PersonaTelCelular').val($(Xml).find('tel_celular').text());
					   $('#PersonaNCasaApto').val($(Xml).find('n_casa_apto').text());
					   $('#PersonaTwitter').val($(Xml).find('twitter').text());
					   $('#PersonaCorreo').val($(Xml).find('correo').text());
					   $('#PersonaRepresentante').val($(Xml).find('representante').text());
					   if(foto.length > 0){
					   		$('#PersonaFoto').removeAttr('class');
							$('#PersonaFotocam').val(foto);
							$('span[rel=showup_picture]').show('slow');
							$('span[rel=showup_picture] a').attr('href', request+'img/photos/final/'+foto);
							$('span[rel=showup_picture] a').attr('title', 'Cédula de Identidad: '+$(Xml).find('cedula').text()+' Nombre Completo: '+$(Xml).find('nombre').text()+' '+$(Xml).find('apellido').text());
					   }
					   
				   }
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
						$(".alerta").html('<p>Ha ocurrido un error durante el proceso, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
						$(".alerta").show('slow');
						setTimeout(function() {
							$(".alerta").fadeOut('slow');
						}, 8000);
						$('input[type=submit]').attr('disabled', 'disabled');
				}
	  });
}


function fancyImage()
{
	var elements = $('span[rel=showup_picture] a');
	elements.fancybox();
}

function fancyText(){

	
	$("a#inline").fancybox({
		'hideOnContentClick': true,

	});

}

function GenerateCI(fireObject,setObject, request, controller)
{
	if(parseInt(fireObject.val()) == 2)
	{
	  request     = base64_decode(HexToAscii(request));
	  uri_request = request+base64_decode(HexToAscii(controller));	
	  $.ajax({
			  url : uri_request,
              dataType: "xml",
			  beforeSend:function(){
				  $("#loding-message").html('<img src="'+request+'/img/loader.gif" border="0" width="20" />');
		   	  },
	 		  success:function(Xml){
				  		$("#loding-message").empty();
						setObject.val($(Xml).find('cedula').text().trim());
						$("label[for=PersonaCedula]").attr('style','display:none');
						setObject.attr('style','display:none');
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
						alert("Ha ocurrido un error durante el proceso.");
				}
	  });
	}else{
		setObject.val(null);
		$("label[for=PersonaCedula]").attr('style','display:inline');
		setObject.attr('style','display:block');
		setObject.focus();
	}
}

function setKeyValue(obj)
{
	$("#CategoriasDisciplinasEventoId").val(AsciiToHex(base64_encode(obj.val())));
}

function addMember(obj, request, action, evt_id, p_grupo)
{
	  var cmembers  = 	$( "#team > table > tbody > tr[type=member]" ).length;
	  if(cmembers < p_grupo)
	  {
		  request = base64_decode(HexToAscii(request));
		  $.ajax({
				  url :request+base64_decode(HexToAscii(action))+'/'+AsciiToHex(base64_encode(obj.val()))+'/'+evt_id,
				  dataType: "xml",
				  beforeSend:function(){
					  obj.attr('disabled', 'disabled');
					  $("#loding-message").html('<img src="'+request+'/img/loader.gif" border="0" width="20" />');
				  },
				  success:function(Xml){
					   obj.removeAttr('disabled');
					   obj.val(null);
					   obj.focus();
					   $("#loding-message").empty();
					   if(isNaN(parseInt($(Xml).find('existe').text()) )){		
							   if( $(Xml).find('miembro').children().length > 0)
							   {
								   var element 	   = $('#team > table > tbody').children('tr'); 
								   var c 		   = (element.attr('type')=='message')?(element.length-1):element.length;
								   var last		   = $( "#team > table > tbody > tr:last" );
								   var member	   = parseInt(last.attr('member'));
								   var categoria   = parseInt(last.attr('categoria'));
								   var disciplina  = parseInt(last.attr('disciplina'));
								   var modalidad   = parseInt(last.attr('modalidad'));
								   var type		   = last.attr('type');
								   if(type=='member')
								   {
										   if(isRegister(parseInt($(Xml).find('miembro').find('id').text())))
										   {
											   /*if
											   (
												   (categoria== parseInt($(Xml).find('miembro').find('categoria').attr('id'))  )
												   ||
												   (disciplina == parseInt($(Xml).find('miembro').find('disciplina').attr('id'))  )
												   ||
												   ( modalidad == parseInt($(Xml).find('miembro').find('modalidad').attr('id'))  )
												)	
												{*/							   
												   var html	= '<tr style="background:#eee;border-bottom:1px solid #fff;" type="member" member="'+$(Xml).find('miembro').find('id').text()+'" categoria="'+$(Xml).find('miembro').find('categoria_id').text()+'" disciplina="'+$(Xml).find('miembro').find('disciplina_id').text()+'" modalidad="'+$(Xml).find('miembro').find('modalidad_id').text()+'"><td width="70" ><input name="data[ConjuntosPersona][persona_id]['+c+']" value="'+$(Xml).find('miembro').find('id').text()+'" type="text" id="ConjuntosPersonaPersonaId'+c+'" class="col-member" /></td><td><a href="#" id="team-player-'+c+'">'+$(Xml).find('miembro').find('cedula').text()+'</a></td><td>'+$(Xml).find('miembro').find('apellido').text()+' '+$(Xml).find('miembro').find('nombre').text()+'</td><td align="center"><input name="data[ConjuntosPersona][capitan]" value="'+$(Xml).find('miembro').find('id').text()+'" type="radio" id="ConjuntosPersonaCapitan'+$(Xml).find('miembro').find('id').text()+'" class="cap-member" /></td><td align="center"><a href="#" onclick="omitPlayer($(this), event)"><img src="'+request+'img/icons/Trash-256.png" border = "0" /></a></td><script>$( \'#team-player-'+c+'\').tooltipster({content: $(\'<div style="font-size:12px;"><div style="float:left;"><img src="'+request+'img/photos/final/'+$(Xml).find('miembro').find('foto').text()+'" style="width:100px; border:#fff 4px solid"/> </div><div style="float:right; margin-left:10px;"><span><b>'+$(Xml).find('miembro').find('apellido').text()+' '+$(Xml).find('miembro').find('nombre').text()+'</b></span><br /><span><b>Disciplina: </b>'+$(Xml).find('miembro').find('disciplina').text()+'</span><br /><span><b>Modalidad: </b>'+$(Xml).find('miembro').find('modalidad').text()+'</span><br /><span><b>Categoría: </b>'+$(Xml).find('miembro').find('categoria').text()+'</span></div><div style="clear:both"></div></div>\'),position: \'right\',animation: \'grow\'});</script></tr>';
												   if((element.length  == 1) && (element.attr('type')=='message'))
														$('#team > table > tbody').html(html);
													 else	
														$('#team > table > tbody').append(html);
													html = null;
												/*}else{
													$(".alerta").html('<p>La Persona que intenta agregar difiere (en cuanto a <b>Disciplina</b>, <b>Modalidad</b> y <b>Categoría</b> se refiere) de los demás miembros del equipo.</p>');
													$(".alerta").show('slow');
													setTimeout(function() {
														$(".alerta").fadeOut('slow');
													}, 8000);
												}*/
										   }else{
												$(".alerta").html('<p>La Persona que intenta agregar a su equipo ya fue añadida, elija a otro participante.</p>');
												$(".alerta").show('slow');
												setTimeout(function() {
													$(".alerta").fadeOut('slow');
												}, 8000);
										   }
									 
								   }else{
											   var html	= '<tr style="background:#eee;border-bottom:1px solid #fff;" type="member" member="'+$(Xml).find('miembro').find('id').text()+'" categoria="'+$(Xml).find('miembro').find('categoria_id').text()+'" disciplina="'+$(Xml).find('miembro').find('disciplina_id').text()+'" modalidad="'+$(Xml).find('miembro').find('modalidad_id').text()+'"><td width="70" ><input name="data[ConjuntosPersona][persona_id]['+c+']" value="'+$(Xml).find('miembro').find('id').text()+'" type="text" id="ConjuntosPersonaPersonaId'+c+'" class="col-member" /></td><td><a href="#" id="team-player-'+c+'">'+$(Xml).find('miembro').find('cedula').text()+'</a></td><td>'+$(Xml).find('miembro').find('apellido').text()+' '+$(Xml).find('miembro').find('nombre').text()+'</td><td align="center"><input name="data[ConjuntosPersona][capitan]" value="'+$(Xml).find('miembro').find('id').text()+'" type="radio" id="ConjuntosPersonaCapitan'+$(Xml).find('miembro').find('id').text()+'" class="cap-member" checked="checked" /></td><td align="center"><a href="#" onclick="omitPlayer($(this), event)"><img src="'+request+'img/icons/Trash-256.png" border = "0" /></a></td><script>$( \'#team-player-'+c+'\').tooltipster({content: $(\'<div style="font-size:12px;"><div style="float:left;"><img src="'+request+'img/photos/final/'+$(Xml).find('miembro').find('foto').text()+'" style="width:100px; border:#fff 4px solid"/> </div><div style="float:right; margin-left:10px;"><span><b>'+$(Xml).find('miembro').find('apellido').text()+' '+$(Xml).find('miembro').find('nombre').text()+'</b></span><br /><span><b>Disciplina: </b>'+$(Xml).find('miembro').find('disciplina').text()+'</span><br /><span><b>Modalidad: </b>'+$(Xml).find('miembro').find('modalidad').text()+'</span><br /><span><b>Categoría: </b>'+$(Xml).find('miembro').find('categoria').text()+'</span></div><div style="clear:both"></div></div>\'),position: \'right\',animation: \'grow\'});</script></tr>';
											   if((element.length  == 1) && (element.attr('type')=='message'))
													$('#team > table > tbody').html(html);
												 else	
													$('#team > table > tbody').append(html);
												html = null;
								   }
								}else{
									$(".alerta").html('<p>Persona no registrada para este evento, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
									$(".alerta").show('slow');						
									setTimeout(function() {
										$(".alerta").fadeOut('slow');
									}, 8000);
							   }
						}else{
									$(".alerta").html('<p>La Persona que intenta anexar a este grupo ya se encuentra registrada para otro grupo bajo este mismo evento, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
									$(".alerta").show('slow');						
									setTimeout(function() {
										$(".alerta").fadeOut('slow');
									}, 8000);
						}
				  },
				  error: function(jqXHR, textStatus, errorThrown) {
							
							$(".alerta").html('<p>Ha ocurrido un error durante el proceso, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
							$(".alerta").show('slow');
							setTimeout(function() {
								$(".alerta").fadeOut('slow');
							}, 8000);
					
					}
		  });
	  }else{
			$(".alerta").html('<p>El número de personas que intenta agregar al equipo supera el limite permitido, contacta al <a href="/acredinweb/contactos/">Contáctanos</a> para más detalles.</p>');
			$(".alerta").show('slow');
			setTimeout(function() {
								$(".alerta").fadeOut('slow');
			}, 8000);
	  }
}

function isRegister(id)
{
	var members  = 	$( "#team > table > tbody > tr[type=member]" );
	var c = 0;
	members.each(function (){
			if(parseInt($(this).attr('member')) == id){
				c = 1;
			}
		}
	);
	
	return (c> 0)?false:true;
}

function omitPlayer(row, e)
{
	var urow = row.parent().parent();
	var root = urow.parent();
	e.preventDefault();
	urow.remove();
	if(root.children().length == 0)
		root.html('<tr type="message" ><td colspan="5" align="center"><b>Miembros de Equipo</b> no regsitrados aún</td>');
}


function checked(area, evnt)
{
	evnt.preventDefault();
	$('.'+area+' > .checkbox > input[type=checkbox]').each(
		function(){
				if(!$(this).is( ":checked" ))
					$(this).prop('checked', true);
		}
	);
}

function unchecked(area, evnt)
{
	evnt.preventDefault();
	$('.'+area+' > .checkbox > input[type=checkbox]').each(
		function(){
				if($(this).is( ":checked" ))
					$(this).prop('checked', false);
		}
	);
}
function manageActionTable(base_url,obj, controller)
{	
	 var title = null;	
     var initContainer = $("td[rel=init]");
	 var initParentContainer = $("table[rel=result] > tbody");
	  controller = 	base64_decode(HexToAscii(controller));
	  base_url = base64_decode(HexToAscii(base_url));
	 if (controller=='estados')
		 title = 'país';
	 else if (controller=='municipios')
	 	title = 'estado';
	initParentContainer.empty();	
	if(!isNaN(parseInt(obj.val())))
	{
	  $.ajax({
			  url :base_url+controller+"/get_local_list"+'/'+AsciiToHex(base64_encode(obj.val()))+'/',
              dataType: "xml",
			  beforeSend:function(){
				  initContainer.html('<p style="text-align:center"><img src="'+base_url+'/img/loader.gif" border="0" width="20" /> Cargando...</p>');
		   	  },
     		  success:function(Xml){
				  if( $(Xml).find('Element').length > 0)
					{
					  var tr_row = '#FFF';
				      var td_row = '#EAEBFF';
					  initContainer.remove();	
					  $(Xml).find('Element').each(
					  	function (){
							tr_row = (tr_row == '#E2E4FF')?'#FFF':'#E2E4FF';
							td_row = (td_row == '#EAEBFF')?'#D3D6FF':'#EAEBFF';
							var id = AsciiToHex(base64_encode($(this).attr('key')));
							var html =  '<tr style="background:'+tr_row+'"><td style="background:'+td_row+' border-right:#FFF 2px solid;" align="center" width="50">'+$(this).attr('key')+'</td></td><td>'+$(this).text()+'</td><td><a href="'+base_url+controller+'/crear/'+id+'"><img src="'+base_url+'img/icons/Document-text-edit-32.png" title="Editar" alt="Editar"></a><a href="'+base_url+controller+'/q_on/'+id+'" onclick="return confirm_action()"><img src="'+base_url+'img/icons/Trash-256.png" title="Descartar" alt="Descartar" rel="delete"></a></td></tr>';
							initParentContainer.append(html);
						}
					  );
				}else{
					  initContainer.html('No se encontraron '+controller+' registrados para este '+title);	
					}
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					initContainer.html('Ha ocurrido errores al momento de cargar la información solicitada');  		
				}
	  });
	}else{
		 if(! typeof  initContainer==='undefined')
					  initContainer.html('Seleccione un valor de Páis válido');	
					  else{
						initParentContainer.html('<tr><td colspan="3" rel="init"> Seleccione un valor de '+title+' válido</td></tr>');
					  }
	}
}

function fill_simple_list(request, key, control){
	  $.ajax({
			  url :base64_decode(HexToAscii(request))+key,
              dataType: "xml",
			  beforeSend:function(){
					(control).empty();
					 control.append($('<option>', {
									value: null,
									text: '[Cargando...]'
					 }));
		   	  },
     		  success:function(Xml){
				 control.empty();
			  	 control.append($('<option>', {
								value: null,
								text: '[Seleccionar]'
				 }));
				 $(Xml).find('Element').each(function(){
						control.append($("<option></option>")
										 .attr("value",$(this).attr('key'))
										 .text($(this).text())); 
							});
			  },
    		  error: function(jqXHR, textStatus, errorThrown) {
					 control.empty();
					 control.append($('<option>', {
									value: null,
									text: '[Seleccionar]'
					 }));
				}
	  });
}

function load_associe(obj, request, action, evt_id)
{
  	  var list_request =  request+AsciiToHex(base64_encode('EventosPersonas/get_list/'))+evt_id;
      var initContainer = $("td[rel=init]");  
	  var initParentContainer = $("div#associe > table > tbody");
	  request = base64_decode(HexToAscii(request));
	  action  = base64_decode(HexToAscii(action));
	  var val = AsciiToHex(base64_encode(obj.val())); 
	  $.ajax({
			  url :request+action+'/'+val+'/',
			  dataType:'json',
			  contentType: 'application/json',
			  beforeSend:function(){
					$("#loding-message-rep").html('<img src="'+request+'/img/loader.gif" border="0" width="20" />');
		   	  },
     		  success:function(JsonData){
				  
				  if(!('Persona' in JsonData)){
					 
					 initParentContainer.html('<tr><td colspan="3" rel="init">No se econtraron personas asociadas.<p>NOTA: Luego de colocar el número de cédula del representante presione la tecla ENTER para realizar una búsqueda.</p></td></tr> ');		  
				}else{
				 var tr_row = '#FFF';
						  var td_row = '#EAEBFF';
						  initContainer.remove();	
						  $.each(JsonData, function(key,array){
									tr_row = (tr_row == '#E2E4FF')?'#FFF':'#E2E4FF';
									td_row = (td_row == '#EAEBFF')?'#D3D6FF':'#EAEBFF';
									var html =  "<tr style='background:"+tr_row+"'><td style='background:"+td_row+" border-right:#FFF 2px solid;' align='center' width='50'>"+array['cedula']+"</td></td><td>"+array['apellido']+" "+array['nombre']+"</td><td><a href='#' onclick='asignTo("+JSON.stringify(JsonData)+", \""+list_request+"\", \""+request+"\");'><img src='"+request+"img/icons/back.png' title='Asignar'></a></td></tr>";
									initParentContainer.append(html);
							}
						  );
						  
					 
					}
					
			  },
		  complete: function(){
		  	 $("#loding-message-rep").empty();
		  },
    		  error: function(jqXHR, textStatus, errorThrown) {
    		  			
				  	initContainer.html('Ha ocurrido errores al momento de cargar la información solicitada');  	
				}
	  });
}

function asignTo(JsonData, list_request, request)
{
   var foto = JsonData.Persona.foto;
  get_advanced_list(
		 JsonData.Persona.paise_id,
		 AsciiToHex(base64_encode('EventosPersona')),
		 AsciiToHex(base64_encode('Estado')), 
		 AsciiToHex(base64_encode('pais_id')), 
	     list_request, 
		 $('#PersonaEstadoId'),
		 JsonData.Persona.estado_id
 );
  get_advanced_list(
	 JsonData.Persona.estado_id,
	 AsciiToHex(base64_encode('EventosPersona')),
	 AsciiToHex(base64_encode('Municipio')), 
	 AsciiToHex(base64_encode('estado_id')), 
	 list_request, 
	 $('#PersonaMunicipioId'),
	 JsonData.Persona.municipio_id
 );
  get_advanced_list(
	 JsonData.Persona.municipio_id,
	 AsciiToHex(base64_encode('EventosPersona')),
	 AsciiToHex(base64_encode('Parroquia')), 
	 AsciiToHex(base64_encode('municipio_id')), 
	 list_request, 
	 $('#PersonaParroquiaId'),
	 JsonData.Persona.parroquia_id
);
								
 $('#PersonaId').val(JsonData.Persona.id);
 $('#PersonaCedula').val(JsonData.Persona.cedula);
 $('#PersonaNombre').val(JsonData.Persona.nombre);
 $('#PersonaApellido').val(JsonData.Persona.apellido);
 $('#PersonaFNacimiento').val(JsonData.Persona.f_nacimiento);
 $('#PersonaEdad').val(calcular_edad(JsonData.Persona.f_nacimiento));
 $('#PersonaGeneroId').val(JsonData.Persona.genero_id);
 $('#PersonaGrupoId').val(JsonData.Persona.grupo_id);
 $('#PersonaTallaId').val(JsonData.Persona.talla_id);
 $('#PersonaPaiseId').val(JsonData.Persona.paise_id);
 $('#PersonaCalleAv').val(JsonData.Persona.calle_av);
 $('#PersonaSectorUrb').val(JsonData.Persona.sector_urb);
 $('#PersonaCasaEdificio').val(JsonData.Persona.casa_edificio);
 $('#PersonaTelLocal').val(JsonData.Persona.tel_local);
 $('#PersonaTelCelular').val(JsonData.Persona.tel_celular);
 $('#PersonaNCasaApto').val(JsonData.Persona.n_casa_apto);
 $('#PersonaTwitter').val(JsonData.Persona.twitter);
 $('#PersonaCorreo').val(JsonData.Persona.correo);
 $('#PersonaClubeId').val($(Xml).find('clube_id').text()); 
  $('#PersonaRepresentante').val(JsonData.Persona.representante);
  if(foto.length > 0){
 	$('#PersonaFoto').removeAttr('class');
 	$('#PersonaFotocam').val(foto);
 	$('span[rel=showup_picture]').show('slow');
 	$('span[rel=showup_picture] a').attr('href', request+'img/photos/final/'+foto);
    $('span[rel=showup_picture] a').attr('title', 'Cédula de Identidad: '+JsonData.Persona.cedula+' Nombre Completo: '+JsonData.Persona.nombre+' '+JsonData.Persona.apellido);
  }
					  
	$.fancybox.close();
		
}

function check_num_transacc(request, action, obj)
{
 request = base64_decode(HexToAscii(request));	
 $.ajax({
	  url :request+base64_decode(HexToAscii(action))+'/'+AsciiToHex(base64_encode(obj.val()))+'/',
	  dataType: "json",
	  beforeSend:function(){
		  $("#loding-message-transacc").html('<img src="'+request+'/img/loader.gif" border="0" width="20" />');
	  },
	  complete:function(){
		   $("#loding-message-transacc").html('');
	  },
	  success:function(JSON){
		 var r =  $(JSON)[0].rs;
		 if(r == 1){
		 		obj.validationEngine("showPrompt", "El número de operación bancaria que introdujo ya fue registrada", "error", "topRight", true);
				$('input[type=submit]').attr('disabled', 'disabled');
		 }else
            	$('input[type=submit]').removeAttr('disabled');
	  },
	  error: function(jqXHR, textStatus, errorThrown) {
					obj.validationEngine("showPrompt", "Ha ocurrido un error, no se ha podido validar el número de operación bancaria que introdujo", "error", "topRight", true);
	  			}
		  });
}

function  checkDate(field, rules, i, options){
 var expiry_month = $("#EventosPersonaTMesVen").val();
 var expiry_year = field.val(); 
 var today = new Date();
 var selDate = new Date();
	
 if (today.getTime() > selDate.setFullYear(expiry_year, expiry_month))
	return options.allrules.expiryDate.alertText;
}

function initFormaPago(param)
{
	 //$('#validaTransacc > .form-element > input').prop('disabled', true);
	
	 if(param==0){
		$('#validaPagonLine').hide();	
		$("#validaTransacc").show();
	 }else{
		 $('#validaPagonLine').show();
		 $("#validaTransacc").hide();		 
	}
}

function setOpcionPago()
{
	var elements = $(".radio-element-pago > input[type=radio]");
	
	elements.each(function()
	{
		$(this).bind('click', function(){
			if(parseInt($(this).val())==1){
				 $('#validaPagonLine > .form-element > input select').prop('disabled', false);
				 $('#validaPagonLine').show();
				// $('#validaTransacc > .form-element > input, select').prop('disabled', true);
				 $('#validaTransacc').hide(); 
			}else{
				// $('#validaTransacc > .form-element > input, select').prop('disabled', false);
				 $('#validaTransacc').show();
				// $('#validaPagonLine > .form-element > input select').prop('disabled', true);
				 $('#validaPagonLine').hide();
			}
		})					
		
	});
}