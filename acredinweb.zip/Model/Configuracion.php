<?php
class Configuracion extends AppModel {

		 public $belongsTo = array(
				'Evento' => array(
					'className' => 'Evento',
					'foreignKey' => 'evento_id'
			)
		);
}
?>