<?php
class ConjuntosPersona extends AppModel {


		 public $belongsTo = array(
				
				'Conjunto' => array(
					'className' => 'Conjunto',
					'foreignKey' => 'conjunto_id'
			),
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'persona_id'
			),
			
		);
}
?>