<?php
class Persona extends AppModel {
                
   public function beforeSave($options = array()) {
		     list($d, $m, $y) = explode('/', $this->data['Persona']['f_nacimiento']);
                     $this->data['Persona']['f_nacimiento']   = date('Y-m-d', strtotime($y.'-'.$m.'-'.$d));
		      
              $this->data['Persona']['apellido']   = mb_strtoupper(trim($this->data['Persona']['apellido']), 'UTF-8');                     
              $this->data['Persona']['nombre']   = mb_strtoupper(trim($this->data['Persona']['nombre']), 'UTF-8');                     
			
			return true;
  }

		public $virtualFields = array(
			'f_nacimiento' => 'DATE_FORMAT(Persona.f_nacimiento,  \'%d/%m/%Y\')',
  	        
		);
		
		public $belongsTo = array(
	
				   'Genero' => array(
								'className'  => 'Genero',
								'foreignKey' => 'genero_id'
					 ),
				   'Grupo' => array(
								'className'  => 'Grupo',
								'foreignKey' => 'grupo_id'
					 ),
				   'Talla' => array(
								'className'  => 'Talla',
								'foreignKey' => 'talla_id'
					 ),
 					'Club' => array(
								'className'  => 'Clube',
								'foreignKey' => 'clube_id'
					 ),						 
				 'Pais' => array(
								'className'  => 'Paise',
								'foreignKey' => 'paise_id'
					 ),					 
				 'Estado' => array(
								'className'  => 'Estado',
								'foreignKey' => 'estado_id'
					 ),	
				 'Municipio' => array(
								'className'  => 'Municipio',
								'foreignKey' => 'municipio_id'
					 ),						 				 
				 'Parroquia' => array(
								'className'  => 'Parroquia',
								'foreignKey' => 'parroquia_id'
					 )

		);


		 public $hasMany = array(
				'EventosPersona' => array(
					'className' => 'EventosPersona',
					'foreignKey' => 'persona_id'
			)
		);
	
}
?>