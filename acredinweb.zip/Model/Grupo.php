<?php
class Grupo extends AppModel {

		public function beforeDelete($cascade = true) {
			$count = $this->Persona->find("count", array(
    						    "conditions" => array("grupo_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Grupo']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Grupo']['descripcion']), 'UTF-8'));

			return true;
		}

		 public $hasMany = array(
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'grupo_id'
			)
		);
}
?>