<?php
class Categoria extends AppModel {

	public function beforeSave($options = array()) {
		$this->data['Categoria']['descripcion']   = ucwords( mb_strtolower(trim($this->data['Categoria']['descripcion']), 'UTF-8'));
		return true;
	}
	
   public $hasAndBelongsToMany = array(
        'DisciplinasEvento' =>
            array(
                'className' => 'DisciplinasEvento',
                'joinTable' => 'categorias_disciplinas_eventos',
                'foreignKey'=> 'categoria_id',
                'associationForeignKey' => 'disciplinasevento_id',
                'unique' 	=> 'keepExisting',
				'with'		=> 'CategoriasDisciplinasEvento'
            )
    );	
	
}
?>