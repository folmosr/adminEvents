<?php
class Conjunto extends AppModel {

		 public $actsAs = array('Containable');
		
		 public $belongsTo = array(
				'Evento' => array(
					'className' => 'Evento',
					'foreignKey' => 'evento_id'
			)
		);

		
		 public $hasMany = array(
				'ConjuntosPersona' => array(
					'className' => 'ConjuntosPersona',
					'foreignKey' => 'conjunto_id'
			)
		);

	public function beforeSave($options = array()) {
		$this->data['Conjunto']['descripcion']   =  mb_strtoupper(trim($this->data['Conjuto']['descripcion']), 'UTF-8');
		return true;
	}

}
?>