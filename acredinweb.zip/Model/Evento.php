<?php
class Evento extends AppModel {

  public $actsAs = array('Containable');
  
 public function beforeSave($options = array()) {
	list($d, $m, $y) = explode('/', $this->data['Evento']['f_inicio']);
        list($y, $h, $a) = explode(' ', "$y ");
        $this->data['Evento']['f_inicio']   = date('Y-m-d H:i', strtotime($y.'-'.$m.'-'.$d.' '.$h.' '.$a));
        unset($d,$m,$h, $a);
        list($d, $m, $y) = explode('/', $this->data['Evento']['f_fin']);
        list($y, $h, $a) = explode(' ', "$y ");
        $this->data['Evento']['f_fin']   = date('Y-m-d H:i', strtotime($y.'-'.$m.'-'.$d.' '.$h.' '.$a));
        unset($d,$m,$h, $a);
	return true;
  }
	var $virtualFields = array(
    	'f_inicio' => "DATE_FORMAT(Evento.f_inicio, '%d/%m/%Y %h:%i %p')",
    	'f_fin' => "DATE_FORMAT(Evento.f_fin, '%d/%m/%Y %h:%i %p')",
    	'total'=>"calcregistros(Evento.id)"
	);
	
	
	public $hasOne = array(
  		      'Caracteristica' => array(
    				        'className'  => 'Caracteristica',
							'foreignKey' => 'evento_id'
       			 ),
                    'Configuracion' => array(
    				        'className'  => 'Configuracion',
							'foreignKey' => 'evento_id'
       			 )
    );
	
	public $hasMany = array(
        'DisciplinasEvento',
		'Credencial',
		//'EventosPersona',
		'Conjunto'
    );	
    
    
 
 
}