<?php
class Clube extends AppModel {
		
		public $useTable = 'clubes'; // This model uses a database table 'exmp'

		public function beforeDelete($cascade = true) {
			$count = $this->Persona->find("count", array(
    						    "conditions" => array("Persona.clube_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Clube']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Clube']['descripcion']), 'UTF-8'));

			return true;
		}


		 public $hasMany = array(
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'clube_id'
			)
		);
}
?>