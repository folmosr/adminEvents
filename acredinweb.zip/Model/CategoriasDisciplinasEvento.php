<?php
class CategoriasDisciplinasEvento extends AppModel {

    public $actsAs = array('Containable');
     
	public $belongsTo = array(
			'Categoria' => array(
					'className' => 'Categoria',
					'foreignKey' => 'categoria_id',
					'conditions' => '',
					'fields' => '',
					'order' => ''
				),
			'DisciplinasEvento' => array(
					'className' => 'DisciplinasEvento',
					'foreignKey' => 'disciplinas_evento_id',
					'conditions' => '',
					'fields' => '',
					'order' => ''
				),
				
    );
	
	public $hasMany =  array(
			'EventosPersona' => array(
					'className' => 'EventosPersona',
					'foreignKey' => 'categorias_disciplinas_evento_id'
				),
	);

}
?>