<?php

App::uses('SimplePasswordHasher', 'Controller/Component/Auth');

class Usuario extends AppModel {

	public function beforeSave($options = array()) {
		    $passwordHasher = new SimplePasswordHasher(array('hashType' => 'sha256'));
			$this->data['Usuario']['nombre']   = strtoupper(trim($this->data['Usuario']['nombre']));
			$this->data['Usuario']['apellido'] = strtoupper(trim($this->data['Usuario']['apellido']));
			$this->data['Usuario']['correo']   = strtolower(trim($this->data['Usuario']['correo']));
			
			 $this->data['Usuario']['password'] = $passwordHasher->hash( $this->data['Usuario']['password']);
			 
			 

			return true;
		}
		
		public $virtualFields = array(
  			  'nombre_completo' => 'CONCAT(Usuario.nombre,\' \', Usuario.apellido)',
			  'f_creacion_formatted' 		=> 'DATE_FORMAT(Usuario.f_creacion,  \'%d/%m/%Y %H:%i:%s\')', 
		);

		 public $belongsTo = array(
				'Perfil' => array(
					'className' => 'Perfil',
					'foreignKey' => 'perfil_id'
			)
		);


}
?>