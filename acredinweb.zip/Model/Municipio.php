<?php
class Municipio extends AppModel {

	   public function beforeDelete($cascade = true) {
			$count = $this->Parroquia->find("count", array(
									"conditions" => array("municipio_id" => $this->id)
			 ));
			if($count > 0)
					return false;
				 else
					return true;
	  }
	
	  public function beforeSave($options = array()) {
				$this->data['Municipio']['descripcion']   = ucwords(strtolower(trim($this->data['Municipio']['descripcion'])));
				$this->data['Municipio']['estado_id']   = $this->data['Municipio']['estado_id'];
				return true;
	  }

 		public $hasMany = array(
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'municipio_id'
			),
			'Parroquia' =>array(
					'className' => 'Parroquia',
					'foreignKey' => 'parroquia_id'
			)
		);

	 public $belongsTo = array(
			'Estado' => array(
					'className' => 'Estado',
					'foreignKey' => 'estado_id'
			),
		);
		
}
?>