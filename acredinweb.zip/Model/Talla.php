<?php
class Talla extends AppModel {

		public function beforeDelete($cascade = true) {
			$count = $this->Persona->find("count", array(
    						    "conditions" => array("Persona.talla_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Talla']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Talla']['descripcion']), 'UTF-8'));

			return true;
		}


		 public $hasMany = array(
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'talla_id'
			)
		);
}
?>