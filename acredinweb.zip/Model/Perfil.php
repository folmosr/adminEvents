<?php
class Perfil extends AppModel {

		public function beforeDelete($cascade = true) {
			$count = $this->Usuario->find("count", array(
    						    "conditions" => array("perfil_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Perfil']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Perfil']['descripcion']), 'UTF-8'));

			return true;
		}

		 public $hasMany = array(
				'Usuario' => array(
					'className' => 'Usuario',
					'foreignKey' => 'perfil_id'
			)
		);


}
?>