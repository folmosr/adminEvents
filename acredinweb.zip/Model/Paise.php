<?php
class Paise extends AppModel {

		public function beforeDelete($cascade = true) {
			$count = $this->Estado->find("count", array(
    						    "conditions" => array("pais_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Paise']['descripcion']   = ucwords(strtolower(trim($this->data['Paise']['descripcion'])));
			return true;
		}

		 public $hasMany = array(
				'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'paise_id'
			),
				'Estado' => array(
					'className' => 'Estado',
					'foreignKey' => 'pais_id'
			),
		);
}
?>