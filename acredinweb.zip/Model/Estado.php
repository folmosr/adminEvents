<?php
class Estado extends AppModel {

   public function beforeDelete($cascade = true) {
		$count = $this->Municipio->find("count", array(
    						    "conditions" => array("estado_id" => $this->id)
   		 ));
		if($count > 0)
				return false;
			 else
			 	return true;
  }

  public function beforeSave($options = array()) {
			$this->data['Estado']['descripcion']   =ucwords(strtolower(trim($this->data['Estado']['descripcion'])));
			$this->data['Estado']['pais_id']   = $this->data['Estado']['paise_id'];
			return true;
  }


   public $hasMany = array(
			'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'estado_id'
			),
			 'Municipio' => array(
						'className' => 'Municipio',
						'foreignKey' => 'municipio_id'
				),
		);

	 public $belongsTo = array(
			'Paise' => array(
					'className' => 'Paise',
					'foreignKey' => 'pais_id'
			),
		);

}
?>