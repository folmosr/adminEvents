<?php
class Caracteristica extends AppModel {

		 public $belongsTo = array(
				'Evento' => array(
					'className' => 'Evento',
					'foreignKey' => 'evento_id'
			)
		);
}
?>