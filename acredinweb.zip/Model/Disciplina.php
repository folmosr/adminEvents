<?php
class Disciplina extends AppModel {

	public function beforeSave($options = array()) {
		$this->data['Disciplina']['descripcion']   =ucwords( mb_strtolower(trim($this->data['Disciplina']['descripcion']),'UTF-8'));
		return true;
	}
  /* public $hasAndBelongsToMany = array(
        'Evento' =>
            array(
                'className' => 'Evento',
                'joinTable' => 'disciplinas_eventos',
                'foreignKey'=> 'disciplina_id',
                'associationForeignKey' => 'evento_id',
                'unique' 	=> 'keepExisting',
				'with'		=> 'DisciplinasEvento'
            )
    );*/
		 public $hasMany = array(
				'DisciplinasEvento' => array(
					'className' => 'DisciplinasEvento',
					'foreignKey' => 'disciplina_id'
			)
		);

		
}
?>