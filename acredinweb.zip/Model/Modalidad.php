<?php
class Modalidad extends AppModel {

		public function beforeSave($options = array()) {
			$this->data['Modalidad']['descripcion']   = ucwords(mb_strtolower(trim($this->data['Modalidad']['descripcion']), 'UTF-8'));

			return true;
		}

		 public $hasMany = array(
				'DisciplinasEvento' => array(
					'className' => 'DisciplinasEvento',
					'foreignKey' => 'modalidad_id'
			)
		);
}
?>