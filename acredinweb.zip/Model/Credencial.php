<?php
class Credencial extends AppModel {
 	
	 public $actsAs = array('Containable');

	 public $belongsTo = array(
			'Evento' => array(
					'className' => 'Evento',
					'foreignKey' => 'evento_id'
			),
			'Tipo' => array(
					'className' => 'Tipo',
					'foreignKey' => 'tipo_id'
			),
		);
		
}
?>