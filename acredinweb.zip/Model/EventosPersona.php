<?php
class EventosPersona extends AppModel {
    
    public $actsAs = array('Containable');
 
      public function beforeSave($options = array()) {
    	if($this->data['EventosPersona']['f_transaccion']){
            list($d, $m, $y) = explode('/', $this->data['EventosPersona']['f_transaccion']);
            $this->data['EventosPersona']['f_transaccion']   = date('Y-m-d', strtotime($y.'-'.$m.'-'.$d));
        }else{
            $this->data['EventosPersona']['f_transaccion']   = date('Y-m-d');
        }    
        print_r($this->data);            
    	//return self::__check_record();
      }

	 public $belongsTo = array(
			'Persona' => array(
					'className' => 'Persona',
					'foreignKey' => 'persona_id'
			),
			 'CategoriasDisciplinasEvento'=> array(
					'className' => 'CategoriasDisciplinasEvento',
					'foreignKey' => 'categorias_disciplinas_evento_id'
			),
				   'Funcion' => array(
								'className'  => 'Funcion',
								'foreignKey' => 'funcion_id'
					 ),						
		);
    
    
    public function GetEventFeatures($evt_id)
    {
        return( $this->CategoriasDisciplinasEvento->
                                    DisciplinasEvento->
                                    Evento->
                                    Caracteristica->
                                            find('first', array(
													'conditions'=>array('Caracteristica.evento_id'=>$evt_id),
																		'recursive'=>-1	
												)
							)        
        );
        
    }
    
    public function CountNumberRegisterByEvent($evt_id){
        
        $this->bindModel(array('hasOne'=>array(
                            'CategoriasDisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id')
                            ),
                            'DisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id')
                            ),
                            
        )));
        return($this->find('count', array(
                
                'fields'=>array(
                    'id'
                ),
                'conditions' => array( 'DisciplinasEvento.evento_id' =>$evt_id )
            )));                 
        
    }
    

    public function GetNumberActionByEvent($evt_id){
        
        $this->bindModel(array('hasOne'=>array(
                            'CategoriasDisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id')
                            ),
                            'DisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id')
                            ),
                            
        )));
        return($this->find('first', array(
                
                'fields'=>array(
                    'n_participacion'
                ),
                'limit'=>1,
                'order'=>array(
            			'EventosPersona.n_participacion DESC'
        		),
                'conditions' => array( 'DisciplinasEvento.evento_id' =>$evt_id )
            )));                 
        
    }
    
    
    public function _check_cedula($ci, $evt_id)
    {
    
    
        if(is_null($ci))
             return 1;
    
    
       $this->bindModel(array('hasOne'=>array(
                            'CategoriasDisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id')
                            ),
                            'DisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id')
                            ),
                            
        )));
        if($this->find('count', array('fields'=>array(
                    'id'
                ),
                                        'conditions'=>array(
                                            'DisciplinasEvento.evento_id' =>$evt_id,
                                           // 'EventosPersona.categorias_disciplinas_evento_id'=>$this->data['EventosPersona']['categorias_disciplinas_evento_id'],
                                            'Persona.cedula'=>$ci)
                                        )
        ) > 0)
            return 2;
    
      return 0;
    }
    
     public function __check_ntransaccion($data){
      if(!is_null($data['EventosPersona']['n_transaccion'])){
        if($this->find('count', array(
                                    'conditions'=> array('EventosPersona.n_transaccion'=>$data['EventosPersona']['n_transaccion'])
                                    )) > 0)
             return true;
       }
       return false;      
     }
     
    public function __check_nparticipacion($data){
       
       
        if(is_null($data['EventosPersona']['n_participacion']) || $data['EventosPersona']['n_participacion'] == '' )
             return true;

      /*  if(is_null($this->data['Persona']['cedula']))
             return false;*/
                          
       /* if($this->find('count', array(
                                    'conditions'=> array('EventosPersona.n_transaccion'=>$data['EventosPersona']['n_transaccion'])
                                    )) > 0)
             return 0;*/
  
$this->bindModel(array('hasOne'=>array(
                            'CategoriasDisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id')
                            ),
                            'DisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id')
                            ),
                            
        )));

        if($this->find('count', array('fields'=>array(
                    'id'
                ),
                                    'conditions'=> array(
                                        'DisciplinasEvento.evento_id' =>$data['EventosPersona']['evento_id'],
                                        'EventosPersona.n_participacion'=>$data['EventosPersona']['n_participacion'])
                                    )) > 0)
             return true;
       
  
      /* $this->bindModel(array('hasOne'=>array(
                            'CategoriasDisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id')
                            ),
                            'DisciplinasEvento'=>array(
                                'foreignKey' => false,
                                'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id')
                            ),
                            
        )));
        if($this->find('count', array('fields'=>array(
                    'id'
                ),
                                        'conditions'=>array(
                                            'DisciplinasEvento.evento_id' =>$this->data['EventosPersona']['evento_id'],
                                           // 'EventosPersona.categorias_disciplinas_evento_id'=>$this->data['EventosPersona']['categorias_disciplinas_evento_id'],
                                            'Persona.cedula'=>$this->data['Persona']['cedula'])
                                        )
        ) > 0)
            return false;*/
            
       //return 2; 
       return false;      
    }
}
?>