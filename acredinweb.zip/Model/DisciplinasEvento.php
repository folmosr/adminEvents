<?php
class DisciplinasEvento extends AppModel {
    
        public $actsAs = array('Containable');
 
		public $belongsTo = array(
			'Evento' => array(
					'className' => 'Evento',
					'foreignKey' => 'evento_id',
				
				),
				'Disciplina' => array(
					'className' => 'Disciplina',
					'foreignKey' => 'disciplina_id',
				
				),
				'Modalidad' => array(
					'className' => 'Modalidad',
					'foreignKey' => 'modalidad_id',
				
				),
					
    );

   public $hasMany = array(
        'CategoriasDisciplinasEvento' =>
            array(
                'className' => 'CategoriasDisciplinasEvento'
			)
    );	
	
}
?>