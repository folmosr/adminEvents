<?php
class Tipo extends AppModel {

	public function beforeDelete($cascade = true) {
		$count = $this->Credencial->find("count", array(
    						    "conditions" => array("Credencial.tipo_id" => $this->id)
   		 ));
		if($count > 0)
				return false;
			 else
			 	return true;
	}

	public function beforeSave($options = array()) {
		$this->data['Tipo']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Tipo']['descripcion']), 'UTF-8'));
		return true;
	}

	public $hasMany = array(
		'Credencial'
    );	
}
?>