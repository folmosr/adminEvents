<?php
class Funcion extends AppModel {

		public function beforeDelete($cascade = true) {
			$count = $this->EventosPersona->find("count", array(
    						    "conditions" => array("funcion_id" => $this->id)
   			 ));
			if($count > 0)
				return false;
			 else
			 	return true;
		}

		public function beforeSave($options = array()) {
			$this->data['Funcion']['descripcion']   =  ucwords( mb_strtolower(trim($this->data['Funcion']['descripcion']), 'UTF-8'));

			return true;
		}
		
		 public $hasMany = array(
				'EventosPersona' => array(
					'className' => 'EventosPersona',
					'foreignKey' => 'funcion_id'
			)
		);
}
?>