<?php
class ConfiguracionesController extends AppController {
 
	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public $helpers 	= array('Wysiwyg.Nicedit', 'CustomFunctions');
	public function constancia($evento_id)
	{
		if(!is_null($evento_id))
		{
			if( !$this->Configuracion->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{
			  	$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		 
             
            }else{
                	if(!empty($this->request->data)){
                	    if(!is_null($this->request->data['Configuracion']['id']))
                            $this->request->data['Configuracion']['id'] = $this->Convert->decode($this->request->data['Configuracion']['id']);
                	    $this->request->data['Configuracion']['evento_id'] = $this->Convert->decode($evento_id);
                	   	if($this->Configuracion->save($this->request->data)){
  							$this->Session->setFlash('<em>Datos procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/eventos/listar/'.$evnt_id);		              	   	   
                              
                        }else{
                       	      $this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
						      $this->redirect('/eventos/listar/');	
                            
                        }
                       
             	   }else{
             	      		$this->data = $this->Configuracion->find('first', array(
																		'conditions' => array('Configuracion.evento_id' => $this->Convert->decode($evento_id)),
																		'recursive'=>-1
																	)
													);
                                                    
                        
             	   }
            }
        }else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		            
            
        }
              
     }
 }