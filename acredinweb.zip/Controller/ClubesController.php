<?php
class ClubesController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_Clube = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Clube->find('all', array(
																	'order'=>'Clube.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Clube']['id'] = (!empty($this->request->data['Clube']['id']))?$this->Convert->decode($this->request->data['Clube']['id']):NULL;
					if($this->Clube->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Clube</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/Clubes/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/Clubes/crear/');		
					}
			}
			if(!is_null($id_Clube)){
				$this->Clube->recursive=-1;
				$this->data = $this->Clube->read(NULL,$this->Convert->decode($id_Clube));
			}
			$this->set($var_configs);
		}


	public function q_on($id_Clube)
	{
		if(!is_null($id_Clube)){
			$id_Clube =  $this->Convert->decode($id_Clube);
			if($this->Clube->delete($id_Clube, true)){
							$this->Session->setFlash('<em><b>Datos de Clube</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/Clubes/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la talla a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/Clubes/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Clube</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/Clubes/crear/');		
		}
	}
}
?>