<?php
class FuncionesController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_funcion = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Funcion->find('all', array(
																	'order'=>'Funcion.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Funcion']['id'] = (!empty($this->request->data['Funcion']['id']))?$this->Convert->decode($this->request->data['Funcion']['id']):NULL;
					if($this->Funcion->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Función</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/funciones/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/funciones/crear/');		
					}
			}
			if(!is_null($id_funcion)){
				$this->Funcion->recursive=-1;
				$this->data = $this->Funcion->read(NULL,$this->Convert->decode($id_funcion));
			}
			$this->set($var_configs);
		}


	public function q_on($id_funcion)
	{
		if(!is_null($id_funcion)){
			$id_funcion =  $this->Convert->decode($id_funcion);
			if($this->Funcion->delete($id_funcion, true)){
							$this->Session->setFlash('<em><b>Datos de Función</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/funciones/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el país a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/funciones/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Función</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/funciones/crear/');		
		}
	}






}
?>