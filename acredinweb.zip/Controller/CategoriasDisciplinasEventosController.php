<?php
class CategoriasDisciplinasEventosController extends AppController {
 
	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

   public function add($id_evento, $id_disciplinasevento)
   {
	   	
		if((!is_null($id_evento)) && (!is_null($id_disciplinasevento)))
		{
			if(( $this->CategoriasDisciplinasEvento->DisciplinasEvento->find('count', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($id_disciplinasevento)))) > 0) && ( $this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($id_evento)))) > 0))
			{	
				$this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->Behaviors->load('Containable');
				$this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->recursive = -1;

				$config_vars = array(
				
							'data' 		=> $this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($id_evento)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
							'categorias'  	 => $this->CategoriasDisciplinasEvento->Categoria->find('list',array('fields'=>array('id','descripcion'))),
							'checked' 		 => $this->CategoriasDisciplinasEvento->find('list', array('fields'=>array('categoria_id'), 'conditions' => array('CategoriasDisciplinasEvento.disciplinas_evento_id' => $this->Convert->decode($id_disciplinasevento)))  ), 
							'id_disciplinasevento' => $id_disciplinasevento,
							'feature_keys'	 =>array(
																'activar_foto'	   =>	'Permitir carga de foto',
																'activar_grupo'	   =>	'Permitir agrupación de participantes',
																'activar_menor'	   =>	'Permitir participación de menor de edad',
																'activar_limite'   =>	'Limitar Nº de participantes',
																'activar_personal' =>	'Permitir registro de personal',
																
												)	
						);

						if(!empty($this->request->data)){
										$this->request->data['CategoriasDisciplinasEvento']['disciplinas_evento_id'] = $this->Convert->decode($this->request->data['CategoriasDisciplinasEvento']['disciplinas_evento_id']) ;
										/*if($config_vars['data'][0]['Caracteristica']['activar_limite'])
										{*/

											if($this->CategoriasDisciplinasEvento->saveMany($this->request->data)){
														$this->Session->setFlash('<em><b>Datos de Categoría</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
														$this->redirect('/CategoriasDisciplinasEventos/add/'.$id_evento.'/'.$id_disciplinasevento);		
													}else{
														$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
														$this->redirect('/CategoriasDisciplinasEventos/add/'.$id_evento.'/'.$id_disciplinasevento);		
												}
										/*}else{
											if($this->CategoriasDisciplinasEvento->save($this->request->data)){
														$this->Session->setFlash('<em><b>Datos de Categoría</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
														$this->redirect('/CategoriasDisciplinasEventos/add/'.$id_evento.'/'.$id_disciplinasevento);		
													}else{
														$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
														$this->redirect('/CategoriasDisciplinasEventos/add/'.$id_evento.'/'.$id_disciplinasevento);		
												}
										}*/
								
						}
						
						$this->set($config_vars);
							
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina / Evento </b></em> no encontrado.<br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina / Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/listar/');		
		}
   }
   
    public  function edit($identificador, $id_categoria) {
		if((!is_null($identificador)) && (!is_null($id_categoria)))
		{
			if(( $this->CategoriasDisciplinasEvento->find('count', array('conditions'=>array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($id_categoria)))) > 0) && ( $this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($identificador)))) > 0))
			{	
			
				$this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->Behaviors->load('Containable');
				$this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->recursive = -1;

				$config_vars = array(
				
							'data' 		=> $this->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($identificador)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
							'data_categoria' => $this->CategoriasDisciplinasEvento->find('all', array('conditions'=>array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($id_categoria)), 'recursive'=>-1)),												
							'categorias'  	 => $this->CategoriasDisciplinasEvento->Categoria->find('list',array('fields'=>array('id','descripcion'))),
							'feature_keys'	 =>array(
																'activar_foto'	   =>	'Permitir carga de foto',
																'activar_grupo'	   =>	'Permitir agrupación de participantes',
																'activar_menor'	   =>	'Permitir participación de menor de edad',
																'activar_limite'   =>	'Limitar Nº de participantes',
																'activar_personal' =>	'Permitir registro de personal',
																
												)	
						);
				if(!empty($this->request->data)){
								$this->request->data['CategoriasDisciplinasEvento']['id'] = $this->Convert->decode($this->request->data['CategoriasDisciplinasEvento']['id']) ;
								if($this->CategoriasDisciplinasEvento->save($this->request->data)){
											$this->Session->setFlash('<em><b>Datos de Categoría</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
											$this->redirect('edit/'.$identificador.'/'.$id_categoria);		
										}else{
											$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
											$this->redirect('edit/'.$identificador.'/'.$id_categoria);		
									}			
				}
				$this->set($config_vars);
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría </b></em> no encontrado.<br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/listar/');		
		}
	}
	
	public function discard($evento_id, $identificador)
	{
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{
			if( $this->CategoriasDisciplinasEvento->find('count', array('conditions'=>array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0)
			{	
		
					if($this->CategoriasDisciplinasEvento->deleteAll(array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)), false)){
									$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría </b></em> eliminado sastifactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/eventos/detalle/'.$evento_id);		
						}else{
								$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em> <br /> <b>ATENCION:</b> Debido a que existen registro en la base de datos que dependen de esta información, el resultado no ha sido satisfactorio.', 'default', array('class' => 'alerta'));
								$this->redirect($this->referer());
					}
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría </b></em>/<em><b>Datos de Evento </b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlla
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect($this->referer());
		}

	}

   public function imprimir($evento_id, $identificador)
   {
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{
			if( $this->CategoriasDisciplinasEvento->find('count', array('conditions'=>array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0)
			{	
					 		 $this->layout = 'pdf';
							 $data = $this->CategoriasDisciplinasEvento->find('all', array('conditions' => array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)),
																							'contain' =>array(
																									'Categoria',
																									'DisciplinasEvento'	=>array(
																										'Disciplina',
																										'Modalidad',
																										'Evento'=>array(
																											'fields'=>array(
																													'nombre', 
																													'f_inicio',
																													'f_fin'
																												)
																										)
																									),
																									'EventosPersona'=>array(
																										'Funcion',
																										'Persona'=>array(
																											'fields'=>array(
																															'cedula', 
																															'apellido', 
																															'nombre', 
																															'tel_local', 
																															'f_nacimiento',
																															'tel_celular'
																											),
																											'Talla'
																										)
																									)
																							)
															)
											);
							
						$this->set(compact('data'));		
				}else{
					$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría </b></em>/<em><b>Datos de Evento </b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
					$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlla
				}
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
				$this->redirect($this->referer());
		}
   }
   

    public function imprimir_excel($evento_id, $identificador)
   {
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{
			if( $this->CategoriasDisciplinasEvento->find('count', array('conditions'=>array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0)
			{	

							 $data = $this->CategoriasDisciplinasEvento->find('all', array('conditions' => array('CategoriasDisciplinasEvento.id'=>$this->Convert->decode($identificador)),
																							'contain' =>array(
																									'Categoria',
																									'DisciplinasEvento'	=>array(
																										'Disciplina',
																										'Modalidad',
																										'Evento'=>array(
																											'fields'=>array(
																													'nombre', 
																													'f_inicio',
																													'f_fin'
																												)
																										)
																									),
																									'EventosPersona'=>array(

																										'Persona'=>array(
																											'fields'=>array(
																															'cedula', 
																															'apellido', 
																															'nombre', 
																															'tel_local', 
																															'f_nacimiento',
																															'tel_celular',
																															'correo',
																															'estado_id'
																											),
																											'Talla',
																											'Genero',
																											'Estado'
																										)
																									)
																							)
															)
											);
				
						$this->set(compact('data'));		
				}else{
					$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría </b></em>/<em><b>Datos de Evento </b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
					$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlla
				}
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Categoría</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
				$this->redirect($this->referer());
		}
   }
   
   private function __beforeSave($data) 
  {
	  $tmp = array();
	   for($i = 0; $i < count($data['CategoriasDisciplinasEvento']['categoria_id']); $i++):
		   $tmp[] = array(
					'categoria_id'  => $data['CategoriasDisciplinasEvento']['categoria_id'][$i],
					'disciplinas_evento_id' => $data['CategoriasDisciplinasEvento']['disciplinas_evento_id'],
					'nparticipacion_ini' => $data['CategoriasDisciplinasEvento']['nparticipacion_ini'],
					'nparticipacion_fin' => $data['CategoriasDisciplinasEvento']['nparticipacion_fin'],
					'cantidad'		=> 0
		);
	endfor;
	return $tmp;
  }

}
?>