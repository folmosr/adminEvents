<?php
class ParroquiasController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_parroquia = NULL)
	{
			$var_configs = array(
				'paises'=>$this->Parroquia->Municipio->Estado->Paise->find('list', array(
																	'fields'=>array('Paise.descripcion'),
																	'order'=>'Paise.descripcion'
																	)
							)
							
			);	
			if(!empty($this->request->data))
			{
					
					$this->request->data['Parroquia']['id'] = (!empty($this->request->data['Parroquia']['id']))?$this->Convert->decode($this->request->data['Parroquia']['id']):NULL;
					if($this->Parroquia->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Parroquia</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/parroquias/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/parroquias/crear/');		
					}
			}
			if(!is_null($id_parroquia)){
				$this->Parroquia->Behaviors->load('Containable');
				$this->data = $this->Parroquia->find('first', array(
																'conditions'=>array('Parroquia.id'=>$this->Convert->decode($id_parroquia)),
																'recursive'=>-1,
																'contain'=>array(
																	'Municipio'=>array(
																			'Estado'=>array(
																				'Paise'
																			)
																	)
																)
															)
				);
				$var_configs['estados'] = $this->Parroquia->Municipio->Estado->find('list',  array(
																					'fields'=>array('Estado.descripcion'),
																					'conditions'=>array('Estado.pais_id'=>$this->data['Municipio']['Estado']['pais_id']),
																					'order'=>'Estado.descripcion'
																	)
				);
				$var_configs['municipios'] = $this->Parroquia->Municipio->find('list',  array(
																					'fields'=>array('Municipio.descripcion'),
																					'conditions'=>array('Municipio.estado_id'=>$this->data['Municipio']['estado_id']),
																					'order'=>'Municipio.descripcion'
																	)
				);

			}
			$this->set($var_configs);
		}


	public function q_on($id_parroquia)
	{
		if(!is_null($id_parroquia)){
			$id_parroquia = $this->Convert->decode($id_parroquia);
			if($this->Parroquia->delete($id_parroquia, true)){
							$this->Session->setFlash('<em><b>Datos de Parroquia</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/parroquias/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la parroquia a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/parroquias/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Parroquia</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/parroquias/crear/');		
		}
	}



	public function get_estados_list($pais_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Parroquia->Municipio->Estado->find('list', array(
																	'fields'=>array('Estado.descripcion'),
																	'conditions'=>array('Estado.pais_id'=>$pais_id),	
																	'order'=>'Estado.descripcion'
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}


	public function get_municipios_list($estado_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Parroquia->Municipio->find('list', array(
																	'fields'=>array('Municipio.descripcion'),
																	'conditions'=>array('Municipio.estado_id'=>$estado_id),	
																	'order'=>'Municipio.descripcion'
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}



	public function get_local_list($municipio_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Parroquia->find('list', array(
																	'fields'=>array('Parroquia.descripcion'),
																	'conditions'=>array('Parroquia.municipio_id'=>$this->Convert->decode($municipio_id)),
																		
																	'order'=>'Parroquia.descripcion'
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}




}
?>