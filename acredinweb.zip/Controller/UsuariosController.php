<?php
class UsuariosController extends AppController {

	public function beforeFilter()
	{
		parent::beforeFilter();
		$this->Auth->allow(array('recovery', 'secure'));
	}

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear()
	{        

		$var_configs = array(
			'perfiles'=>$this->Usuario->Perfil->find('list', array(		'fields'=>array('Perfil.descripcion'),	'order'=>'Perfil.descripcion'	))
		);
		
		if(!empty($this->request->data))
		{
			$newPass = $this->__getNewPass();
			$this->request->data['Usuario']['imagen'] =	$this->upload($this->request->data['Usuario']['imagen'], realpath('img/usuarios/'), $this->Convert->encode(strtolower(trim($this->request->data['Usuario']['correo']))));
			$this->request->data['Usuario']['password']   = $newPass;
			$this->request->data['Usuario']['activo'] = TRUE;  			
			if($this->Usuario->save($this->request->data)){
						$this->__send($this->request->data);
						$this->Session->setFlash('<em><b>Datos de Usuario</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
						$this->redirect('/usuarios/crear/');		
				  }else{
						$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/usuarios/crear/');		
				} 
                         			
		}
                 
		$this->set($var_configs);
	}
	
	
	public function editar()
	{
		$var_configs = array(
			'perfiles'=>$this->Usuario->Perfil->find('list', array(		'fields'=>array('Perfil.descripcion'),	'order'=>'Perfil.descripcion'	))
		);
		if(!empty($this->request->data))
		{
			if($this->request->data['Usuario']['imagen']['size'] > 0)
				$this->request->data['Usuario']['imagen'] =	$this->upload($this->request->data['Usuario']['imagen'], realpath('img/usuarios/'), $this->Convert->encode(strtolower(trim($this->request->data['Usuario']['correo']))));
			  else
			  	$this->request->data['Usuario']['imagen'] =	$this->request->data['Usuario']['img'];
			if(empty($this->request->data['Usuario']['password']))
				$this->request->data['Usuario']['password'] = $this->request->data['Usuario']['pwd'];
			if($this->Usuario->save($this->request->data)){
						$this->Session->setFlash('<em><b>Datos de Usuario</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
						$this->redirect('/usuarios/editar/');		
				  }else{
						$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/usuarios/editar/');		
					}
		}
		$this->set($var_configs);
	}
	
	
	public function listar()
	{

		$var_configs = array('data'=>$this->Usuario->find('all', array(	'order'=>'Usuario.f_creacion')));
		$this->set($var_configs);
	}



	public function q_on($usuario_id)
	{
		
		if(!is_null($usuario_id))
		{
			if( $this->Usuario->find('count', array('conditions'=>array('Usuario.id'=>$this->Convert->decode($usuario_id)))) > 0)
			{			
						@date_default_timezone_set('America/Caracas');
						$data =  $this->Usuario->find('first', array( 'recursive'=>-1, 'conditions' => array('Usuario.id' => $this->Convert->decode($usuario_id))));
						$data['Usuario']['activo'] = ($data['Usuario']['activo'])?false:true;
						if($this->Usuario->save($data)){
									$this->Session->setFlash('<em><b>Datos de Usuario</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/usuarios/listar');		
								}else{
									$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
									$this->redirect('/usuarios/listar/');		
							}			
				
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Usuario</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/usuarios/listar/');		
			}
		
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Usuario</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/usuarios/listar/');		
		}
		
	}
	
	public function login()
	{
		 if ($this->request->is('post')) {
        	if ($this->Auth->login()) {
           		  $this->redirect(array('controller'=>'eventos','action'=>'listar'));
        	}
        	$this->Session->setFlash(__('Correo o Contraña inválidos, vuelve a intentar'),  'default', array('class' => 'alerta'));
			
    	}else{
			$cookie = $this->Cookie->read('rememberMe');
			$this->set(compact('cookie'));
		}
		
	}

	public function logout() {
		return $this->redirect($this->Auth->logout());
	}	

	
	public function recovery($mail = NULL)
	{
		
		if(!empty($this->data)){
			
			$var_configs = array('data' => $this->Usuario->find('first', array(
																	'fields'=>array('nombre', 'apellido', 'correo', 'id'),
																	'conditions'=>array('Usuario.correo'=>$this->data['Usuario']['correo']) ,
																	 'recursive'=>-1
															)
													),
								'flag' => true					
							);
								
			
			if($this->__send($var_configs['data'], $var_configs['flag'])){
				$this->Session->setFlash('<em>se le ha enviado un correo con los pasos a seguir para la recuperación de la clave.</em>', 'default', array('class' => 'exito'));
				$this->redirect('/usuarios/login/');		
			}
			$this->set($var_configs);
		}
		
	}

	public function secure($correo, $usuario_id)
	{
		if(!is_null($usuario_id))
		{
			if( $this->Usuario->find('count', array('conditions'=>array('Usuario.id'=>$this->Convert->decode($usuario_id), 'Usuario.correo'=>$this->Convert->decode($correo)))) > 0)
			{		
			
					if(!empty($this->request->data)){
						$this->request->data['Usuario']['id']       =	$this->Convert->decode($this->request->data['Usuario']['id']);
						$this->request->data['Usuario']['nombre']   =	$this->Convert->decode($this->request->data['Usuario']['nb']);
						$this->request->data['Usuario']['apellido'] =	$this->Convert->decode($this->request->data['Usuario']['ap']);
						$this->request->data['Usuario']['correo']   =	$this->Convert->decode($this->request->data['Usuario']['ml']);

						if($this->Usuario->save($this->request->data)){
									$this->Session->setFlash('<em><b>Clave</b> recuperada satisfactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/usuarios/login/');		
								}else{
									$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
									$this->redirect('/usuarios/login/');		
							}			
				
					}
					
			            $data = $this->Usuario->find('first', array(
																	'fields'=>array('id', 'nombre', 'apellido', 'correo'),
																	'conditions'=>array('Usuario.id'=>$this->Convert->decode($usuario_id), 'Usuario.correo'=>$this->Convert->decode($correo)) ,
																	 'recursive'=>-1
															)
													);			
					$this->set(compact('data'));
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Usuario</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/usuarios/login/');		
			}
		
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Usuario</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/usuarios/login/');		
		}
	}


 	 private function __send($data, $flag = false) { 
			 $title = (!$flag)?'Registro de Usuario':'Recuperación de Clave';
			 $this->set(array('data' => $data,'flag' => $flag)); 
			 $this->Email->from = 'tutorneo@tutorneo.biz';
			 $this->Email->fromName = 'TuTorneo';
			 $this->Email->to = $data['Usuario']['correo']; 
			 $this->Email->subject = 'TuTorneo.biz. '.$title; 
			 return $this->Email->send();
			 		
    } 	

	
	
	private function __getNewPass($length = 8)
	{
		$password = "";
		$possible = "2346789bcdfghjkmnpqrtvwxyzBCDFGHJKLMNPQRTVWXYZ";
		$maxlength = strlen($possible);
		if ($length > $maxlength) {
		  $length = $maxlength;
		}
		$i = 0; 
		while ($i < $length) { 
		  $char = substr($possible, mt_rand(0, $maxlength-1), 1);
		  if (!strstr($password, $char)) { 
			$password .= $char;
			$i++;
		  }
		}
		return $password;
	}
	
	private function __rememberIt()
	{
		if ($this->request->data['Usuario']['remain']) {
			// After what time frame should the cookie expire
			$cookieTime = "12 months"; // You can do e.g: 1 week, 17 weeks, 14 days
			// remove "remember me checkbox"
			unset($this->request->data['Usuario']['remain']);
			// write the cookie
			$this->Cookie->write('rememberMe', $this->request->data['Usuario']['correo'], true, $cookieTime);
		}		
	}
}
?>