<?php
class CategoriasController extends AppController {

	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_categoria = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Categoria->find('all', array(
																	'order'=>'Categoria.descripcion',
																	'recursive'=>-1
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Categoria']['id'] = (!empty($this->request->data['Categoria']['id']))?$this->Convert->decode($this->request->data['Categoria']['id']):NULL;
					if($this->Categoria->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Categoría</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/categorias/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/categorias/crear/');		
					}
			}
			if(!is_null($id_categoria)){
				$this->Categoria->recursive=-1;
				$this->data = $this->Categoria->read(NULL,$this->Convert->decode($id_categoria));
			}
			$this->set($var_configs);
	}


	public function q_on($id_categoria)
	{
		if(!is_null($id_categoria)){
			$id_categoria =  $this->Convert->decode($id_categoria);
			if($this->Categoria->delete($id_categoria, false)){
							$this->Session->setFlash('<em><b>Datos de Categoría</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/categorias/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la categoria a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/categorias/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Categoría</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/categorias/crear/');		
		}
	}






}
?>