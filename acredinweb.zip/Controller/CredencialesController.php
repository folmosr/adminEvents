<?php
class CredencialesController extends AppController {
 
	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($evento_id, $credencial_id = NULL)
	{
		if(!is_null($evento_id))
		{
			if( $this->Credencial->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{
				$this->Credencial->Evento->Behaviors->load('Containable');
				$var_configs =  array(
										'evento_id'=>$evento_id,
										
										'data'=>$this->Credencial->Evento->find('all', array(
																								'conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)),
																								'contain'=>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),																										
																								),
																								'recursive'=>-1
																						)
										),
										'feature_keys'=>array(
														'activar_foto'	   =>	'Permitir carga de foto',
														'activar_grupo'	   =>	'Permitir agrupación de participantes',
														'activar_menor'	   =>	'Permitir participación de menor de edad',
														'activar_limite'   =>	'Limitar Nº de participantes',
														'activar_personal' =>	'Permitir registro de personal',
														
										),
									
										'tipos'=>$this->Credencial->Tipo->find('list', array(
																							'fields'=>array('descripcion')
																						)
											),
										
										'credenciales'=>$this->Credencial->find('all', array(
																								'conditions'=>array('Credencial.evento_id'=>$this->Convert->decode($evento_id)),			
																								'contain'=>array(
																										'Tipo'
																								)
																							)
										),
										'flag'=>(is_null($credencial_id))?true:false
											
				
				);
				if(!empty($this->request->data))
				{
					$w = NULL; 
					$h = NULL;
					if($this->request->data['Credencial']['imagen']['size'] > 0){
					 	if($this->request->data['Credencial']['tipo_id']==1){ $w = 1240;	$h = 725; }elseif($this->request->data['Credencial']['tipo_id']==3){	$w = 2250; $h = 595;	}
					 	if($this->request->data['Credencial']['tipo_id']!=5)
					 	{
					 		
					 			$this->request->data['Credencial']['w'] = 0;
					 			$this->request->data['Credencial']['h'] = 0;
					 		
					 	}
					 	
						if(!$this->request->data['Credencial']['imagen'] =	$this->upload($this->request->data['Credencial']['imagen'], realpath('img/credenciales/'), $this->Convert->encode(mb_strtolower(trim($this->request->data['Credencial']['descripcion']), 'UTF-8')), $w,$h))
								$this->redirect('/credenciales/crear/'.$evento_id);	
					}else
						$this->request->data['Credencial']['imagen'] =$this->Convert->decode($this->request->data['Credencial']['img']);
					
					$this->request->data['Credencial']['id'] 		= (array_key_exists('id',$this->request->data['Credencial']))?$this->Convert->decode($this->request->data['Credencial']['id']):NULL;	
					$this->request->data['Credencial']['evento_id'] = $this->Convert->decode($evento_id);
						
						
					if($this->Credencial->save($this->request->data)){
								$this->Session->setFlash('<em><b>Datos de Credencial</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
								$this->redirect('/credenciales/crear/'.$evento_id);		
					  }else{
								$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
								$this->redirect('/credenciales/crear/'.$evento_id);		
						}				
				}
				if(!is_null($credencial_id)){
					$this->Credencial->recursive=-1;
					$this->data = $this->Credencial->read(NULL,$this->Convert->decode($credencial_id));
				}
				
				$this->set($var_configs);
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}	
	}
	
	
	
	public function filtrar($evento_id)
	{
		if(!is_null($evento_id))
		{
			if( $this->Credencial->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{
				 $credenciales  = $this->Credencial->find('list', array(
																								'conditions'=>array('Credencial.evento_id'=>$this->Convert->decode($evento_id)),			
																								'fields'=>array('Credencial.descripcion'),
																								'order'=>'Credencial.descripcion',
																								'recurisve'=>-1		
																							)
										);
				if(count($credenciales) > 0)
				{						
					$this->Credencial->Evento->Behaviors->load('Containable');
					$this->Credencial->Evento->DisciplinasEvento->Behaviors->load('Containable');
					$var_configs = array(
										'data'=>$this->Credencial->Evento->find('all', array(
																								'conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)),
																								'contain'=>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),																										
																								),
																								'recursive'=>-1
																						)
										),
										'disciplinas'=>$this->Credencial->Evento->DisciplinasEvento->find('list', array( 'conditions'=>array(
																																	'DisciplinasEvento.evento_id'=>$this->Convert->decode($evento_id)
																																),
																															'contain'=>array(
																																		'Disciplina'
																															),
																															'fields' => array('Disciplina.id', 'Disciplina.descripcion') 													
																					)
											),
										'feature_keys'=>array(
														'activar_foto'	   =>	'Permitir carga de foto',
														'activar_grupo'	   =>	'Permitir agrupación de participantes',
														'activar_menor'	   =>	'Permitir participación de menor de edad',
														'activar_limite'   =>	'Limitar Nº de participantes',
														'activar_personal' =>	'Permitir registro de personal',
														
										),
										'funciones'=>$this->Credencial->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->EventosPersona->Funcion->find('list', array(
																																						'fields'=>array('descripcion'),
																																						'order'=>'Funcion.descripcion',
																																						'recursive'=>-1				
																																				)
																			),
										'credenciales'=>$credenciales,
										'evento_id'=>$evento_id
					);
					
						$this->set($var_configs);
					}else{
						$this->Session->setFlash('<em><b>ATENCION:</b> <em> Primero debe asignar los <b>Datos de credencial</b></em> para este evento.</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/credenciales/crear/'.$evento_id);		
					}
				}else{
					$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
					$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}	
	}
	
	public  function imprimir() {
	  if(!empty($this->data))
	  {	
		  $this->layout = 'pdf';
		  $this->Credencial->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->Behaviors->load('Containable');
		  $this->Credencial->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->recursive = -1;	
		  $var_configs['data'] = $this->Credencial->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->find('all', array(
						   'fields'=>array(
										'CategoriasDisciplinasEvento.id',
										'CategoriasDisciplinasEvento.disciplinas_evento_id'
							),	
						   'conditions'=>array(
										'CategoriasDisciplinasEvento.id'=>$this->data['Credencial']['categoria_id']
									),
						'contain'=>array(
										'DisciplinasEvento'=>array(
											'fields'=>array(
														'DisciplinasEvento.disciplina_id',
														'DisciplinasEvento.modalidad_id',
														'DisciplinasEvento.evento_id'
												),
										'Disciplina'=>array(
											'fields'=>array('Disciplina.descripcion')
												),
										'Modalidad'=>array(
												'fields'=>array('Modalidad.descripcion'),
											),
										'Evento'=>array(
												'fields'=>array('Evento.nombre'),
												)																									
											),
									     'Categoria'=>array(
											'fields'=>array('Categoria.descripcion')
										 ),
									  'EventosPersona'=>array(
									  		 'conditions'=>array(
											 			'EventosPersona.funcion_id IN ('.implode(',',$this->data['Credencial']['funciones']).')'
											 ),
											 'Persona'=>array(
												'fields'=>array(
														'Persona.cedula',
														'Persona.nombre',
														'Persona.apellido',
														'Persona.foto',
												)
										),
										'Funcion'
										)																						
									)
						)
			);

		if(count($var_configs['data'][0]['EventosPersona']) > 0)
		{
		  $var_configs['credencial'] = $this->Credencial->find('first', array(
																		'conditions'=>array('Credencial.id'=>$this->data['Credencial']['credencial_id']),
																		'contain'=>array(
																			'Tipo'
																		)
																)
					);
			
		  $this->set($var_configs);

		}else{
			$this->Session->setFlash('<em>La consulta no generó ningún tipo de resultado.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/listar/');		
		}
	  }else{
			$this->Session->setFlash('<em>Antes de ejecutar esta acción debe realizar una búsqueda .</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/listar/');		
	   }
	}
	
	
	
}
?>