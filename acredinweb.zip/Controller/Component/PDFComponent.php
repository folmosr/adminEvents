<?php
App::uses('Component', 'Controller');
class PDFComponent extends Component {
	
	
	function __construct()
	{
			App::import('Vendor','tcpdf'.DS.'tcpdf'); 
	}

	function sendingPDF($data, $base_url)
	{
		$style = array(
			'position' => '',
			'align' => 'R',
			'stretch' => false,
			'fitwidth' => false,
			'cellfitalign' => '',
			'border' => false,
			'hpadding' => 'auto',
			'vpadding' => 'auto',
			'fgcolor' => array(0,0,0),
			'bgcolor' => false, //array(255,255,255),
			'text' => false,
			'font' => 'helvetica',
			'fontsize' => 8,
			'stretchtext' => 4
		);
		
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		// set document information
		$pdf->SetCreator('TuTorneo');
		$pdf->SetAuthor('TuTorneo');
		$pdf->SetTitle('Constancia de Inscripción');
		$pdf->SetSubject('Constancia de Inscripción');
		$pdf->SetKeywords('TuTorneo, Constancia, Eventos, Deporte, Inscripción');
		
		// set default header data
		$pdf->SetHeaderData('Logo-TuTorneo_2_150x150.jpg', PDF_HEADER_LOGO_WIDTH, 'Constancia de Inscripción', "Por TuTorneo - www.tutorneo.biz\n+58 (295) 4173477\n eventos@tutorneo.biz", array(0,0,0), array(0,0,0));
		$pdf->setFooterData();
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		// set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, 35, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		// set image scale factor
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
		 
		////////////////////////////////// DATOS ////////////////////////////////////////////////////////////

		 
		// set font
		$pdf->SetFont('helvetica', '', 10);
		
		// add a page
		//$pdf->AddPage();
		

		// create some HTML content
		$html = '					
		<div style="margin:20px 0;">
			<img src="'.$base_url.'img/banners_eventos/'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['banner'].'" />
		</div>				
		<!--Datos personales-->
		<h1>Datos Personales</h1>
		<table  cellpadding="5" cellspacing="0">';
		
		if(!$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Caracteristica']['activar_menor'])
			$html.=	'<tr>
					<td><b>Cédula de Identidad</b></td>
					<td>'.$data[0]['Persona']['cedula'].'</td>
				</tr>';
			
		$html.=	'<tr>	
				<td><b>Apellido/Nombre</b></td>
				<td>'.$data[0]['Persona']['apellido'].' '.$data[0]['Persona']['nombre'].'</td>
			</tr>
			<tr>	
				<td><b>Fecha de Nacimiento</b></td>
				<td>'.$data[0]['Persona']['f_nacimiento'].'</td>
			</tr>
			<tr>	
				<td><b>Edad</b></td>
				<td>'.$data[0]['Persona']['edad'].'</td>
			</tr>
			<tr>	
				<td><b>Genero</b></td>
				<td>'.$data[0]['Persona']['Genero']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Categoría</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['Categoria']['descripcion'].'</td>
			</tr>
			
		';
		if($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Caracteristica']['activar_foto'])
			 $html.= '<tr>
					<td><b>Foto</b></td>
					<td><img src="'.$base_url.'img/photos/final/'.$data[0]['Persona']['foto'].'" width="100" /></td>
				</tr>';
		$html.= '</table><h1>Datos Deportivos</h1>
		<table  cellpadding="5" cellspacing="0">
			<tr>	
				<td><b>Evento</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['nombre'].'</td>
			</tr>
			<tr>	
				<td><b>Fecha/Hora del Evento</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['f_inicio'].' al '.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['f_fin'].'</td>
			</tr>
			<tr>	
				<td><b>Funciòn a Desempeñar</b></td>
				<td>'.$data[0]['Funcion']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Disciplina</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Disciplina']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Modalidad</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Modalidad']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Participación Número</b></td>
				<td>'.$data[0]['EventosPersona']['n_participacion'].'</td>
			</tr>
		
		</table>
 	   
        <tcpdf method="AddPage" />
		
        <h1>Datos Administrativos</h1>
		<table  cellpadding="5" cellspacing="0">
			<tr>	
				<td><b>Transacción Número</b></td>
				<td>'.$data[0]['EventosPersona']['n_transaccion'].'</td>
			</tr>
			<tr>	
				<td><b>Fecha/Hora de Transacción</b></td>
				<td>'.$data[0]['EventosPersona']['f_transaccion'].'</td>
			</tr>
		
		</table>
		<tcpdf method="AddPage" />
                <h1>Sobre el Evento</h1>
	        <p>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['descripcion'].'</p>		

		';
       if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_1']))
            $html.= $data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_1'];
       if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_2']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_2'];
        if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_3']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_3']; 
      if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_4']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_4'];
                     if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_5']))
         $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_5'];                     

		// add a page
		$pdf->AddPage();

// add Barcode
		
		$pdf->write1DBarcode($data[0]['EventosPersona']['id'], 'C39E+', '', '', '', 10, 0.4, $style, 'R');
		$pdf->Ln(20);		
		// output the HTML content
		$pdf->writeHTML($html, true, false, true, false, '');
		// reset pointer to the last page
		$pdf->lastPage();
		////////////////////////////7 CREACION DLE ARCHIVO /////////////////////////////////////////////////
		echo $pdf->Output(WWW_ROOT . 'files'.DS.'pdf' . DS . 'constancia_'.$data[0]['EventosPersona']['id'].'.pdf', 'F');
	}
    	
	
    	
	function makePDF($data, $base_url)
	{
		$style = array(
			'position' => '',
			'align' => 'R',
			'stretch' => false,
			'fitwidth' => false,
			'cellfitalign' => '',
			'border' => false,
			'hpadding' => 'auto',
			'vpadding' => 'auto',
			'fgcolor' => array(0,0,0),
			'bgcolor' => false, //array(255,255,255),
			'text' => false,
			'font' => 'helvetica',
			'fontsize' => 8,
			'stretchtext' => 4
		);
		
		$pdf = new TCPDF(PDF_PAGE_ORIENTATION, PDF_UNIT, PDF_PAGE_FORMAT, true, 'UTF-8', false);

		// set document information
		$pdf->SetCreator('TuTorneo');
		$pdf->SetAuthor('TuTorneo');
		$pdf->SetTitle('Constancia de Inscripción');
		$pdf->SetSubject('Constancia de Inscripción');
		$pdf->SetKeywords('TuTorneo, Constancia, Eventos, Deporte, Inscripción');
		
		// set default header data
		$pdf->SetHeaderData('Logo-TuTorneo_2_150x150.jpg', PDF_HEADER_LOGO_WIDTH, 'Constancia de Inscripción', "Por TuTorneo - www.tutorneo.biz\n+58 (295) 4173477\n eventos@tutorneo.biz", array(0,0,0), array(0,0,0));
		$pdf->setFooterData();
		
		// set header and footer fonts
		$pdf->setHeaderFont(Array(PDF_FONT_NAME_MAIN, '', PDF_FONT_SIZE_MAIN));
		$pdf->setFooterFont(Array(PDF_FONT_NAME_DATA, '', PDF_FONT_SIZE_DATA));
		
		// set default monospaced font
		$pdf->SetDefaultMonospacedFont(PDF_FONT_MONOSPACED);
		
		// set margins
		$pdf->SetMargins(PDF_MARGIN_LEFT, 35, PDF_MARGIN_RIGHT);
		$pdf->SetHeaderMargin(PDF_MARGIN_HEADER);
		$pdf->SetFooterMargin(PDF_MARGIN_FOOTER);
		
		// set auto page breaks
		$pdf->SetAutoPageBreak(TRUE, PDF_MARGIN_BOTTOM);
		
		// set image scale factor
		$pdf->setImageScale(PDF_IMAGE_SCALE_RATIO);
		 
		////////////////////////////////// DATOS ////////////////////////////////////////////////////////////

		 
		// set font
		$pdf->SetFont('helvetica', '', 10);
		
		// add a page
		//$pdf->AddPage();
		

		// create some HTML content
		$html = '					
		<div style="margin:20px 0;">
			<img src="'.$base_url.'img/banners_eventos/'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['banner'].'" />
		</div>	
                
		<!--Datos personales-->
		<h1>Datos Personales</h1>
		<table  cellpadding="5" cellspacing="0">';
		
		if(!$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Caracteristica']['activar_menor'])
			$html.=	'<tr>
					<td><b>Cédula de Identidad</b></td>
					<td>'.$data[0]['Persona']['cedula'].'</td>
				</tr>';
			
		$html.=	'<tr>	
				<td><b>Apellido/Nombre</b></td>
				<td>'.$data[0]['Persona']['apellido'].' '.$data[0]['Persona']['nombre'].'</td>
			</tr>
			<tr>	
				<td><b>Fecha de Nacimiento</b></td>
				<td>'.$data[0]['Persona']['f_nacimiento'].'</td>
			</tr>
			<tr>	
				<td><b>Edad</b></td>
				<td>'.$data[0]['Persona']['edad'].'</td>
			</tr>
			<tr>	
				<td><b>Genero</b></td>
				<td>'.$data[0]['Persona']['Genero']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Categoría</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['Categoria']['descripcion'].'</td>
			</tr>
			
		';
		if($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Caracteristica']['activar_foto'])
			 $html.= '<tr>
					<td><b>Foto</b></td>
					<td><img src="'.$base_url.'img/photos/final/'.$data[0]['Persona']['foto'].'" width="100" /></td>
				</tr>';
		$html.='</table><h1>Datos Deportivos</h1>
		<table  cellpadding="5" cellspacing="0">
			<tr>	
				<td><b>Evento</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['nombre'].'</td>
			</tr>
			<tr>	
				<td><b>Fecha/Hora del Evento</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['f_inicio'].' al '.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['f_fin'].'</td>
			</tr>
			<tr>	
				<td><b>Funciòn a Desempeñar</b></td>
				<td>'.$data[0]['Funcion']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Disciplina</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Disciplina']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Modalidad</b></td>
				<td>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Modalidad']['descripcion'].'</td>
			</tr>
			<tr>	
				<td><b>Participación Número</b></td>
				<td>'.$data[0]['EventosPersona']['n_participacion'].'</td>
			</tr>
		
		</table>
		
		<tcpdf method="AddPage" />
                <h1>Sobre el Evento</h1>
	        <p>'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['descripcion'].'</p>
		';
       if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_1']))
            $html.= $data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_1'];
       if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_2']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_2'];
        if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_3']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_3']; 
      if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_4']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_4'];
                  if(isset($data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_5']))
            $html.= '<tcpdf method="AddPage" />'.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['Configuracion']['pagina_5'];    
           
                            
	   
	   if(isset($data['Instapago']))
	    $html.='<tcpdf method="AddPage" /><h3>Factura de Pago On-Line</h3>'.str_replace('/r/n','/n',html_entity_decode(str_replace('table','table width="260px"',$data['Instapago'])));
	   // add a page
	   $pdf->AddPage();
		

// add Barcode
		
		$pdf->write1DBarcode($data[0]['EventosPersona']['id'], 'C39E+', '', '', '', 10, 0.4, $style, 'R');
		$pdf->Ln(20);		
		// output the HTML content
		$pdf->writeHTML($html, true, false, true, false, '');
		// reset pointer to the last page
		$pdf->lastPage();
		////////////////////////////7 CREACION DLE ARCHIVO /////////////////////////////////////////////////
		echo $pdf->Output(WWW_ROOT . 'files'.DS.'pdf' . DS . 'constancia_'.$data[0]['EventosPersona']['id'].'.pdf', 'F');
	}
		
}
?>