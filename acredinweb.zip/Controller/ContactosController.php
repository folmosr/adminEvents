<?php
class ContactosController extends AppController {

	public function beforeFilter()
	{
		parent::beforeFilter();
		$this->Auth->allow('index');
	}


	public $uses = array();

	
	
	public function index()
	{
		if(!empty($this->request->data)){
			
			if($this->__send($this->request->data)){
					$this->Session->setFlash('<em><b>Mensaje</b> enviado satisfactoriamente.</em>', 'default', array('class' => 'exito'));
					$this->redirect('/contactos/');
				}else {
					$this->Session->setFlash('<em>Han ocurrido errores al intentar enviar el mensaje.</em>', 'default', array('class' => 'alerta'));
					$this->redirect('/contactos/');
			}
		}
	}
	

	private function __send($data) { 
			 $this->set(compact('data')); 
			 $this->Email->from = $data['Contacto']['From'];
			 $this->Email->fromName = $data['Contacto']['Nombre'];
			 $this->Email->to = 'eventos@tutorneo.biz'; 
			 $this->Email->subject = $data['Contacto']['Asunto']; 
			 return debug($this->Email->send());
			 		
    } 	
	
}
?>