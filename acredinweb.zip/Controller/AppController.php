<?php
/**
 * Application level Controller
 *
 * This file is application-wide controller file. You can put all
 * application-wide controller-related methods here.
 *
 * PHP 5
 *
 * CakePHP(tm) : Rapid Development Framework (http://cakephp.org)
 * Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 *
 * Licensed under The MIT License
 * For full copyright and license information, please see the LICENSE.txt
 * Redistributions of files must retain the above copyright notice.
 *
 * @copyright     Copyright (c) Cake Software Foundation, Inc. (http://cakefoundation.org)
 * @link          http://cakephp.org CakePHP(tm) Project
 * @package       app.Controller
 * @since         CakePHP(tm) v 0.2.9
 * @license       http://www.opensource.org/licenses/mit-license.php MIT License
 */
App::uses('Controller', 'Controller');

/**
 * Application Controller
 *
 * Add your application-wide methods in the class below, your controllers
 * will inherit them.
 *
 * @package		app.Controller
 * @link		http://book.cakephp.org/2.0/en/controllers.html#the-app-controller
 */
class AppController extends Controller {


	public $helpers    = array('Form', 'Html', 'CustomFunctions');
	public $components  = array(
								'Convert',
								'Upload',
								'Session', 
								'RequestHandler',
								'Cookie', 
								'Email',

								 'Auth' => array(
								 		   'authorize' => 'Controller',
										   'loginAction' => array(
												'controller' => 'usuarios',
												'action' => 'login',
											),
										  'loginRedirect' => array(
												'controller' => 'eventos',
												'action' => 'listar'
											),
											'logoutRedirect' => array(
												'controller' => 'eventos',
												'action' => 'common'
											),											
											'authenticate' => array(
												'Form' => array(
													 'fields' => array('username' => 'correo', 'password'=>'password'),
													 'scope' =>array('activo IS TRUE'),
													 'userModel' => 'Usuario',
												     'passwordHasher' => array(
														'className' => 'Simple',
														'hashType' => 'sha256'
													)													
												)
											)
										)
					);
	
	
	public function beforeFilter()
	{
		//REDIRECT TO HTTPS IF REQUEST IS NOT HTTPS
		if($_SERVER['HTTPS']!="on")
		{
			$redirect= "https://".$_SERVER['HTTP_HOST'].$_SERVER['REQUEST_URI'];
			header( "HTTP/1.1 301 Moved Permanently" );
			header("Location:$redirect");
			exit;
		}
	}
 
	
	/**
		Función que realiza el proceso de cargar la imagen al servidor y devuve el nombre 
		de la misma
	*/
	public function upload($file, $destination, $new_name, $w = 250, $h = 250) {
		
		$Errors_logs = $Errors_text = NULL;
		
		$this->Upload->upload_file($file, $destination, $new_name.'.jpg',  
							  array('type' => 'resize', 
							  		'size' => $w,//array($w, $h),
									'quality'=>100, 
									'output' => 'jpg' ), 
							  array('jpg', 'jpeg'));

		if(count($this->Upload->errors)>0)
		{
			if(is_array($this->Upload->errors)){ 
			
				foreach($this->Upload->errors as $v):
						$Errors_logs.= $v.'\n';
				   		$Errors_text.= '<b>'.$v.'</b> '; 
				endforeach;
			}
			$this->Session->setFlash($Errors_text, 'default', array('class' => 'alerta'));
			return(false);
		}else{
				return($this->Upload->result);
		}
	}
	
	public function full($evento_id,  $mod)
	{
		$data =  array();
		$mod  = $this->Convert->decode($mod);
		if($mod == 'evento')	{
	  			$this->Evento->Behaviors->load('Containable');
	  			$this->Evento->recursive = -1;
				
				$data =  $this->Evento->find('first', array( 'contain' =>array('Caracteristica'=>array('fields'=>array('activar_foto', 'activar_grupo','activar_menor','activar_limite','activar_personal'))), 'conditions' => array('Evento.id' => $this->Convert->decode($evento_id))));
		
		}elseif($mod == 'modalidad'){

	  		//	$this->Evento->DisciplinasEvento->Behaviors->load('Containable');
	  			$this->Evento->DisciplinasEvento->recursive = -1;
				$data =  $this->Evento->DisciplinasEvento->find('all', array( 'contain' =>array(
																		   		'Disciplina',
																				'Modalidad'
																	          ),
																		   'conditions' => array(
																				'DisciplinasEvento.evento_id' => $this->Convert->decode($evento_id)
																			)
																	  )
																);
		
		}elseif($mod == 'categoria')	{
	  			//$this->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->Behaviors->load('Containable');
	  			$this->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->recursive = -1;
				$data =  $this->Evento->DisciplinasEvento->CategoriasDisciplinasEvento->find('all', array(
														
												 		'contain' =>array(
												 			'Categoria',
															'DisciplinasEvento'=>array(
																		
																		'Evento'=>array(
																				'Caracteristica'=>array(
																						'fields'=>array('activar_limite')
																				)
																		)
																	)
															), 
														'conditions' => array(
																			'CategoriasDisciplinasEvento.disciplinas_evento_id' => $this->Convert->decode($evento_id),
																			
																)
															
															
														)
													);
	  }
	  $this->set('response', $data);
	  $this->set('_serialize','response');
	}

	public function dataTableFilter(){
		 if($this->RequestHandler->responseType() == 'json') {
				  $this->paginate = array(
								'fields' => array('Evento.id', 'Evento.nombre',  'Evento.status','Evento.total'),
								'recursive'=>-1
				   );
				  $this->DataTable->fields = array('Evento.id', 'Evento.nombre', 'Evento.status','Evento.total');
				  $this->set('response', $this->DataTable->getResponse());
				  $this->set('_serialize','response');
			  }	
	}
	

 public function get_personal_list($Key, $SearchInModel, $FieldCondition)
    {
		$this->response->type('xml');
		$array_list = array();
		$FieldCondition = $this->Convert->decode($FieldCondition);
        switch($this->Convert->decode($SearchInModel)):
         case 'Estado': 
        	$array_list = $this->Persona->Estado->find('list', array(
		   																'fields' => array('Estado.id', 'Estado.descripcion'),
																		'conditions' => array('Estado.'.$FieldCondition => $Key),
															'order'=>'Estado.descripcion'));
                                                            		 break;	
		  case 'Municipio': 
		   			$array_list = $this->Persona->Municipio->find('list', array(
		   																'fields' => array('Municipio.id', 'Municipio.descripcion'),
																		'conditions' => array('Municipio.'.$FieldCondition => $Key),
																		'order'=>'Municipio.descripcion'
																)
															); 
			break;
		   case 'Parroquia': 
		   			$array_list = $this->Persona->Parroquia->find('list', array(
		   																'fields' => array('Parroquia.id', 'Parroquia.descripcion'),
																		'conditions' => array('Parroquia.'.$FieldCondition => $Key),
																		'order'=>'Parroquia.descripcion'
																		
																)
															); 
			break;
		endswitch;											
        echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.$valor.'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
    } 


	public function get_list($evt_id, $Key, $BaseModel, $SearchInModel, $FieldCondition){
		
		$this->response->type('xml');
		$array_list = array();
		$BaseModel = $this->Convert->decode($BaseModel);
		$FieldCondition = $this->Convert->decode($FieldCondition);
		switch($this->Convert->decode($SearchInModel)):
		   case 'Estado': 
		   			$array_list = $this->$BaseModel->Persona->Estado->find('list', array(
		   																'fields' => array('Estado.id', 'Estado.descripcion'),
																		'conditions' => array('Estado.'.$FieldCondition => $Key),
																		'order'=>'Estado.descripcion'
																)
															); 
			break;

		   case 'Municipio': 
		   			$array_list = $this->$BaseModel->Persona->Municipio->find('list', array(
		   																'fields' => array('Municipio.id', 'Municipio.descripcion'),
																		'conditions' => array('Municipio.'.$FieldCondition => $Key),
																		'order'=>'Municipio.descripcion'
																)
															); 
			break;
		   case 'Parroquia': 
		   			$array_list = $this->$BaseModel->Persona->Parroquia->find('list', array(
		   																'fields' => array('Parroquia.id', 'Parroquia.descripcion'),
																		'conditions' => array('Parroquia.'.$FieldCondition => $Key),
																		'order'=>'Parroquia.descripcion'
																		
																)
															); 
			break;
		   case 'Modalidad': 
					//$this->$BaseModel->CategoriasDisciplinasEvento->DisciplinasEvento->Behaviors->load('Containable');
		   			$array_list = $this->$BaseModel->CategoriasDisciplinasEvento->DisciplinasEvento->find('all', array(
																			 	'fields'=>array('DISTINCT modalidad_id'),
																			 	'conditions'=>array(
																									'DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id), 
																									'DisciplinasEvento.'.$FieldCondition => $Key
																									), 
																				'recursive'=>-1,
																				'contain'=>array(
																						'Modalidad'=>array(
																									'fields'=>array('id','descripcion')
																								)
																						)
																					)
																			); 
					$array_list = 	$this->likeAList($array_list, 'Modalidad');	
			break;
		   case 'Categoria':
		   			list($mod_id, $disc_id) = explode('_', $Key);
					//$this->$BaseModel->CategoriasDisciplinasEvento->DisciplinasEvento->Behaviors->load('Containable');
		   			$array_list = $this->$BaseModel->CategoriasDisciplinasEvento->DisciplinasEvento->find('all', array(
																			 	'fields'=>array('id'),
																			 	'conditions'=>array('DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id), 'DisciplinasEvento.disciplina_id'=>$disc_id, 'DisciplinasEvento.modalidad_id'=>$mod_id), 
																				'recursive'=>-1,
																				'contain'=>array(
																						'CategoriasDisciplinasEvento'=>array(
																									'fields'=>array('id','disciplinas_evento_id'),
																									'Categoria'
																								)
																						)
																					)
																			);
					$array_list = 	$this->likeAList($array_list, 'CategoriasDisciplinasEvento', 'Categoria');	
			break;
		   case 'Credencial_Modalidad': 
					$this->$BaseModel->Evento->DisciplinasEvento->Behaviors->load('Containable');
		   			$array_list = $this->$BaseModel->Evento->DisciplinasEvento->find('list', array( 'conditions'=>array(
																																	'DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id),
																																	'DisciplinasEvento.'.$FieldCondition => $Key
																														),
																															'contain'=>array(
																																		'Modalidad'
																															),
																															'fields' => array('Modalidad.id', 'Modalidad.descripcion') 													
																					)
											);
			break;
		   case 'Credencial_Categoria': 
   		   			list($disc_id, $mod_id) = explode('_', $Key);
					//$this->$BaseModel->Evento->DisciplinasEvento->Behaviors->load('Containable');
		   			 $array_list = $this->$BaseModel->Evento->DisciplinasEvento->find('all', array(
																							'conditions'=>array(
																										'DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id),
																										'DisciplinasEvento.disciplina_id' => $disc_id,
																										'DisciplinasEvento.modalidad_id' => $mod_id
																							  ),
																							  'contain'=>array(
																							  		'CategoriasDisciplinasEvento'=>
																										array(
																												'fields'=>array('id','categoria_id'),
																												'Categoria'=>array(
																													'fields'=>array('Categoria.id', 'Categoria.descripcion')
																												)
																											)
																							  ),
																			)																							  
									);
									
					$array_list = 	$this->categoriaEventoList($array_list, 'CategoriasDisciplinasEvento', 'Categoria');
			break;
		endswitch;						
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.$valor.'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}

	public function get_limited_list($evt_id, $func_id, $mod_id, $disc_id, $flag, $menor)
	{
				/*if(($func_id == 1 )	|| ($func_id == 2))			
					$Query.=	'			*/
		$this->response->type('xml');
		$array_list = array();
		$this->EventosPersona->Behaviors->load('Containable');
		if ($flag > 0)
		{
			$Query = 'SELECT CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin , '.$this->__get_field($func_id).' 
			  FROM disciplinas_eventos AS DisciplinasEvento
				INNER JOIN (
							categorias_disciplinas_eventos AS CategoriasDisciplinasEvento 
								LEFT OUTER JOIN 
								(
									eventos_personas AS EventosPersona 
											INNER JOIN personas AS Persona ON 
												(
													EventosPersona.persona_id = Persona.id AND Persona.genero_id='.$func_id.'
												)
								)	
						 on (EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id)) on (DisciplinasEvento.id = CategoriasDisciplinasEvento.disciplinas_evento_id)
					  INNER JOIN categorias AS Categoria ON (CategoriasDisciplinasEvento.categoria_id = Categoria.id)
				WHERE DisciplinasEvento.evento_id = '.$this->Convert->decode($evt_id).' AND DisciplinasEvento.disciplina_id = '.$disc_id.' AND DisciplinasEvento.modalidad_id = '.$mod_id.' AND
				';
			  $Query.= ($menor > 0)?' Categoria.clasificacion IS TRUE':' Categoria.clasificacion IS FALSE '; 	
			 $Query.='	GROUP BY CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin
				HAVING  COUNT(EventosPersona.id) < '.$this->__get_field($func_id).'
			';
		}else{
		  $Query = 'SELECT CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin  
						   FROM disciplinas_eventos AS DisciplinasEvento	
								INNER JOIN categorias_disciplinas_eventos AS CategoriasDisciplinasEvento  ON (DisciplinasEvento.id = CategoriasDisciplinasEvento.disciplinas_evento_id)
								INNER JOIN categorias AS Categoria ON (CategoriasDisciplinasEvento.categoria_id = Categoria.id)
					WHERE DisciplinasEvento.evento_id = '.$this->Convert->decode($evt_id).' AND DisciplinasEvento.disciplina_id = '.$disc_id.' AND DisciplinasEvento.modalidad_id = '.$mod_id.' AND
			';
			 $Query.= ($menor > 0)?' Categoria.clasificacion IS TRUE':' Categoria.clasificacion IS FALSE '; 			
		}
		$array_list = $this->likeAList($this->EventosPersona->query($Query),'CategoriasDisciplinasEvento',NULL, 1); //1 => $isCategoria
	
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
				foreach($array_list as $clave => $valor):
						echo '<Element key="'.$clave.'" ini="'.$valor[1].'" fin="'.$valor[2].'" nparticipacion_ini="'.$valor[3].'" nparticipacion_fin="'.$valor[4].'">'.$valor[0].'</Element>';		
				endforeach;
		echo '</List>';
		$this->autoRender = false;
	}


	public function get_limited_list_by_funcion($evt_id, $func_id, $mod_id, $disc_id, $flag){
		
		$this->response->type('xml');
		$array_list = array();
		$this->EventosPersona->Behaviors->load('Containable');
		if ($flag)
		{
			 $Query = 'SELECT CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin, '.$this->__get_field($func_id).' 
			  FROM disciplinas_eventos AS DisciplinasEvento
				INNER JOIN (
							categorias_disciplinas_eventos AS CategoriasDisciplinasEvento 
								LEFT OUTER JOIN 
								(
									eventos_personas AS EventosPersona 
											INNER JOIN personas AS Persona ON 
												(
													EventosPersona.persona_id = Persona.id AND EventosPersona.funcion_id='.$func_id.'
												)
								)	
						
							  on (EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id)) on (DisciplinasEvento.id = CategoriasDisciplinasEvento.disciplinas_evento_id)
					  INNER JOIN categorias AS Categoria ON (CategoriasDisciplinasEvento.categoria_id = Categoria.id)
				WHERE DisciplinasEvento.evento_id = '.$this->Convert->decode($evt_id).' AND DisciplinasEvento.disciplina_id = '.$disc_id.' AND DisciplinasEvento.modalidad_id = '.$mod_id.'
				';
			 $Query.='	GROUP BY CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin
				HAVING  COUNT(EventosPersona.id) < '.$this->__get_field($func_id).'
			';
		}else{
			$Query = 'SELECT CategoriasDisciplinasEvento.id, Categoria.descripcion, Categoria.ini, Categoria.fin, CategoriasDisciplinasEvento.nparticipacion_ini, CategoriasDisciplinasEvento.nparticipacion_fin  
						   FROM disciplinas_eventos AS DisciplinasEvento	
								INNER JOIN categorias_disciplinas_eventos AS CategoriasDisciplinasEvento  ON (DisciplinasEvento.id = CategoriasDisciplinasEvento.disciplinas_evento_id)
								INNER JOIN categorias AS Categoria ON (CategoriasDisciplinasEvento.categoria_id = Categoria.id)
					WHERE DisciplinasEvento.evento_id = '.$this->Convert->decode($evt_id).' AND DisciplinasEvento.disciplina_id = '.$disc_id.' AND DisciplinasEvento.modalidad_id = '.$mod_id.'
			';
		}
		$array_list = $this->likeAList($this->EventosPersona->query($Query), 'CategoriasDisciplinasEvento',NULL, 1); //1 => $isCategoria
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
				foreach($array_list as $clave => $valor):
						echo '<Element key="'.$clave.'" ini="'.$valor[1].'" fin="'.$valor[2].'" nparticipacion_ini="'.$valor[3].'" nparticipacion_fin="'.$valor[4].'">'.$valor[0].'</Element>';		
				endforeach;
		echo '</List>';
		$this->autoRender = false;
	}

	public function likeAList($data, $index, $subIndex = NULL, $isCategoria = NULL)
	{
             
		$tmp = array();
			if(is_null($subIndex))
			{

				for($i=0; $i < count($data); $i++ ):
					if($isCategoria)
						$tmp[$data[$i][$index]['id']] = array($data[$i]['Categoria']['descripcion'], $data[$i]['Categoria']['ini'], $data[$i]['Categoria']['fin'],$data[$i][$index]['nparticipacion_ini'], $data[$i][$index]['nparticipacion_fin'] ); 
						else
							$tmp[$data[$i][$index]['id']] = $data[$i][$index]['descripcion'];
				endfor;
			}else{
				for($i=0; $i < count($data); $i++ ):
					for($j=0; $j < count($data[$i][$index]); $j++ ):
						$tmp[$data[$i][$index][$j][$subIndex]['id']] = $data[$i][$index][$j][$subIndex]['descripcion']; 
					endfor;
				endfor;
			}
		return $tmp;		
	}

                


	public function categoriaEventoList($data, $index, $subIndex = NULL, $isCategoria = NULL)
	{
		$tmp = array();
		for($i=0; $i < count($data); $i++ ):
					for($j=0; $j < count($data[$i][$index]); $j++ ):
						$tmp[$data[$i][$index][$j]['id']] = $data[$i][$index][$j][$subIndex]['descripcion']; 
					endfor;
				endfor;
		return $tmp;		
	}
	
	public function sendup()
	{
		$this->response->type('json');		
		/*
			This file receives the JPEG snapshot from
			assets/webcam/webcam.swf as a POST request.
		*/
		
		// We only need to handle POST requests:
		if(strtolower($_SERVER['REQUEST_METHOD']) != 'post'){
			exit;
		}
		
		$folder = realpath('img/photos/');
		$filename = md5($_SERVER['REMOTE_ADDR'].rand()).'.jpg';
		
		$original = $folder.'\\'.$filename;
		
		// The JPEG snapshot is sent as raw input:
		$input = file_get_contents('php://input');
		
		if(md5($input) == '7d4df9cc423720b7f1f3d672b89362be'){
			// Blank image. We don't need this one.
			exit;
		}
		
		$result = file_put_contents($original, $input);
		if (!$result) {
			echo '{
				"error"		: 1,
				"message"	: "Failed save the image. Make sure you chmod the uploads folder and its subfolders to 777."
			}';
			exit;
		}
		
		$info = getimagesize($original);
		if($info['mime'] != 'image/jpeg'){
			unlink($original);
			exit;
		}
		
		// Moving the temporary file to the originals folder:
		rename($original,realpath('img/photos/tmp/').DS.$filename);
		$original = realpath('img/photos/tmp/').DS.$filename;
		
		// Using the GD library to resize
		// the image into a thumbnail:
		
		$origImage	= imagecreatefromjpeg($original);
		$newImage	= imagecreatetruecolor(154,110);
		imagecopyresampled($newImage,$origImage,0,0,0,0,154,110,520,370); 
		
		imagejpeg($newImage,realpath('img/photos/final/').DS.$filename);
		
		unlink($original);
		echo '{"status":1,"message":"Success!","filename":"'.$filename.'"}';
		$this->autoRender = false;
				
	}
	
	public function discard_file($filename)
	{
		$this->response->type('json');		
		/*
			This file receives the JPEG snapshot from
			assets/webcam/webcam.swf as a POST request.
		*/
		
		if(file_exists(realpath('img/photos/final/').'/'.$filename.'.jpg')){
			unlink(realpath('img/photos/final/').'/'.$filename.'.jpg');
			echo '{"status":1,"message":"Success!"}';
		}else{
			echo '{
				"error"		: 1,
				"message"	: "Error."
			}';
		}
		
		
		$this->autoRender = false;
		
	}
	
	private function __get_field($func_id)
	{	
		$field = NULL;
		switch($func_id){
			case 1:	$field = 'CategoriasDisciplinasEvento.cantidad_m';	break;
			case 2:	$field = 'CategoriasDisciplinasEvento.cantidad_f';	break;
			case 4:	$field = 'CategoriasDisciplinasEvento.entrenador';	break;
			case 5:	$field = 'CategoriasDisciplinasEvento.delegado';	break;
			case 6:	$field = 'CategoriasDisciplinasEvento.acompanante';	break;
			case 7:	$field = 'CategoriasDisciplinasEvento.voluntario';	break;
		}
		return $field;
	}
	
	
	public function load_persona($persona_id)
	{
		 $this->response->type('xml');		
		 $data =  $this->EventosPersona->Persona->find('all', array(
											'conditions'=>array('Persona.cedula'=>$persona_id),
											'recursive'=>-1
									)
			);
		
	
		$xml = '<?xml version="1.0" encoding="UTF-8"?>';
		if(count($data) > 0)
		{
			$xml.='<Persona>';
				foreach($data[0]['Persona'] as $key => $value):
					$xml .= '<'.$key.'>'.$value.'</'.$key.'>';
				endforeach;	
			echo $xml.='</Persona>';
		}

		$this->autoRender = false;
	}
	
	
	public function get_action_number_by_event($event_id)
	{
	   $this->response->type('xml');
	   $uses = array();	
	   $limit = $this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->Caracteristica->find('first', 
	   			array(
	   					'fields' => array('p_atl'),
	   					'conditions'=>array('Caracteristica.evento_id'=>$this->Convert->decode($event_id))	
	   			 )

	   	);
	   $total_registered = $this->EventosPersona->CountNumberRegisterByEvent($this->Convert->decode($event_id));
	  if($total_registered < $limit['Caracteristica']['p_atl']) {

		   $rs = $this->EventosPersona->GetNumberActionByEvent($this->Convert->decode($event_id));
		  /* for ($i=0; $i < count($rs) ; $i++) { 
		 			$uses[$i]= $rs[$i]['EventosPersona']['n_participacion'];
		 	}*/
		  // $selected = $uses[0];
		 /*  while (in_array($selected, $uses)) {
		   		$selected = rand(1, $limit['Caracteristica']['p_atl']);		
		   }*/
		 //$selected = (count($rs)== 0 )?1:$uses[count($uses)-1]+1;
		  $selected = (count($rs)== 0 )?1:$rs['EventosPersona']['n_participacion'] + 1;
		 
		}else
			$selected = 'false'	;
		
	  echo $xml = '<?xml version="1.0" encoding="UTF-8"?>
			<Persona>
				<numero>
						'.$selected.'
				</numero>
			</Persona>';	
	   $this->autoRender = false;
	}

	
	
	
	
	
	
	public function get_action_number($relacion_id, $r_ini, $r_fin)
	{
		$this->response->type('xml');	
		$flag = false	;
		$disponibles = array();
		$random	      = null;
		$usados		 = $this->EventosPersona->find('all', array(
															'fields'	 => array('n_participacion'),
															'conditions' =>array('EventosPersona.categorias_disciplinas_evento_id' => $relacion_id),
															'recursive'  =>-1		
														)
		);
		for($i = $r_ini; $i <= $r_fin; $i++):
			 $disponibles[] = $i;	
		endfor;

		if(count($usados) > 0){

			for($i= 0 ; $i < count($usados); $i++):
					unset($disponibles[array_search($usados[$i]['EventosPersona']['n_participacion'], $disponibles)]);
			endfor;
			
		}
		
		if(count($disponibles) > 0){
			while(!$flag){
				$index = rand(0,(count($disponibles)-1));
				if(array_key_exists($index,$disponibles)){
					$random = $disponibles[$index];
					$flag = true;
				   }
				};
			}else
				$random = 'false';
		echo $xml = '<?xml version="1.0" encoding="UTF-8"?>
		<Persona>
			<numero>
					'.$random.'
			</numero>
		</Persona>';

		$this->autoRender = false;
	}
	
	
	
	public function generating_ci()
	{
		$this->response->type('xml');		
		$cod  = $this->__getCIRadom();
		$c    = 0;
		$cis  = $this->__PrepareArray($this->EventosPersona->Persona->find('all', array(
																'fields'=>array('Persona.cedula'),
																'recursive'=>-1
															)		
		), 'Persona', 'cedula');
		while( in_array($cod, $cis)):
			$cod = $this->__getCIRadom();
			$c++;
		endwhile;
		echo $xml = '<?xml version="1.0" encoding="UTF-8"?>
		<Persona>
			<cedula>
					'.$cod.'
			</cedula>
		</Persona>';
		$this->autoRender = false;
	}
	
	private function __getCIRadom()
	{
		$i = 0;
		$tmp = mt_rand(1,7);
		do {
			$tmp .= mt_rand(0, 7);
		} while(++$i < 7);		
		return $tmp;
	}
	
	private function __PrepareArray($data, $index, $field)
	{
		$tmp = array();
		for($i = 0; $i < count($data); $i++):
			$tmp[] = $data[$i][$index][$field];
		endfor;
		return $tmp;
	}
	
	public function add_member($k_persona, $evento_id)
	{
		$this->response->type('xml');
		$xml = '<?xml version="1.0" encoding="UTF-8"?>
		<Persona>';
		$contador = $this->Conjunto->query('SELECT COUNT(ConjuntosPersona.id) AS count
								FROM conjuntos AS Conjunto
									INNER JOIN (
											conjuntos_personas AS ConjuntosPersona
											INNER JOIN personas AS Persona 	ON (ConjuntosPersona.persona_id = Persona.id  AND Persona.cedula = \''.$this->Convert->decode($k_persona).'\')
										)
										on (Conjunto.id = ConjuntosPersona.conjunto_id)
								WHERE Conjunto.evento_id ='.$this->Convert->decode($evento_id));

		if($contador[0][0]['count'] > 0)
			$xml.= '<existe>1</existe>';
		else
		{

			$data = $this->Conjunto->query('SELECT Persona.id, 
													Persona.cedula,
													Persona.Nombre, 
													Persona.Apellido, 
													Persona.foto, 
													Categoria.id AS Categoria_id,
													Disciplina.id AS Disciplina_id,
													Modalidad.id AS Modalidad_id,
													Categoria.descripcion AS Categoria,
													Disciplina.descripcion AS Disciplina,
													Modalidad.descripcion AS Modalidad
							FROM personas AS Persona 
											INNER JOIN (
													eventos_personas AS EventosPersona 
														INNER JOIN 
															(
																categorias_disciplinas_eventos AS CategoriasDisciplinasEvento 
																	INNER JOIN
																		(
																			disciplinas_eventos AS DisciplinasEvento 
																			
																			INNER JOIN disciplinas AS Disciplina ON (DisciplinasEvento.disciplina_id = Disciplina.id)
																			INNER JOIN modalidades AS Modalidad ON (DisciplinasEvento.modalidad_id = Modalidad.id)
																		)
																			ON (
																				CategoriasDisciplinasEvento.disciplinas_evento_id = DisciplinasEvento.id
																				AND
																					DisciplinasEvento.evento_id = '.$this->Convert->decode($evento_id).'
																				)
																INNER JOIN categorias AS Categoria ON (CategoriasDisciplinasEvento.categoria_id = Categoria.id)
															)
														ON (EventosPersona.categorias_disciplinas_evento_id = CategoriasDisciplinasEvento.id )
												)
											ON (EventosPersona.persona_id = Persona.id)
									WHERE Persona.cedula = \''.$this->Convert->decode($k_persona).'\'
			');


			$xml.='<miembro>';
			if(count($data) > 0)
			{
			$xml.= '<id>'.$data[0]['Persona']['id'].'</id>
					<cedula>'.$data[0]['Persona']['cedula'].'</cedula>
					<nombre>'.$data[0]['Persona']['Nombre'].'</nombre>
					<apellido>'.$data[0]['Persona']['Apellido'].'</apellido>
					<foto>'.$data[0]['Persona']['foto'].'</foto>
					<categoria id="'.$data[0]['Categoria']['Categoria_id'].'">'.$data[0]['Categoria']['Categoria'].'</categoria>
					<disciplina id="'.$data[0]['Disciplina']['Disciplina_id'].'">'.$data[0]['Disciplina']['Disciplina'].'</disciplina>
					<modalidad id="'.$data[0]['Modalidad']['Modalidad_id'].'">'.$data[0]['Modalidad']['Modalidad'].'</modalidad>';

			}
			 $xml.='
				</miembro>';
		}
		echo $xml.='</Persona>';
		$this->autoRender = false;
	}
	
	public function load_associe($rep_id)
	{
		 $this->response->type('json');		
		 $data =  $this->EventosPersona->Persona->find('all', array(
											'conditions'=>array('Persona.representante'=>$this->Convert->decode($rep_id)),
											'recursive'=>-1
									)
			);
		
	
		if(count($data) > 0)
		{
				for($i = 0; $i < count($data); $i++):
						echo json_encode($data[$i]);
				endfor;	
		}else
			echo json_encode(array('Data'=>false));
			

		$this->autoRender = false;
	}
	
}