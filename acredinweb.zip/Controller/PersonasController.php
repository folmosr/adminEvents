<?php
class PersonasController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	
    

	public function buscar()
	{
	   $data = array();
	   if($this->request->is('post')){  
             $this->Persona->Behaviors->load('Containable');
             if($this->data['Persona']['criterio']=='EventosPersona.n_transaccion'){
               $data = $this->Persona->EventosPersona->find('first', array(
                                            'contain'=>array(

                                                
                                                   'Persona',
                                                    'CategoriasDisciplinasEvento'=>array(
                                                        'DisciplinasEvento'=>array(
                                                            'Evento'
                                                      
                                                    )
                                                )
                                            ),
                                            'conditions'=>array(
                                                            $this->data['Persona']['criterio'] => $this->data['Persona']['valor']
                                            )
                      )
                ) ;
           }else{
             $data = $this->Persona->find('first', array(
                                            'contain'=>array(

                                                'EventosPersona'=>array(
                                                
                                                    'CategoriasDisciplinasEvento'=>array(
                                                        'DisciplinasEvento'=>array(
                                                            'Evento'
                                                        )
                                                    )
                                                )
                                            ),
                                            'conditions'=>array(
                                                            $this->data['Persona']['criterio'] => $this->data['Persona']['valor']
                                            )
                      )
               ) ;


               }
            
	     }

       	            $this->set(compact('data'))  ;
	}
    
	public function editar($id = NULL)
	{
	   if(!is_null($id))
       {
       
          
          if($this->request->is('put')){
               
                $this->request->data['Persona']['id'] = $this->Convert->decode( $this->request->data['Persona']['id']);
                if($this->request->data['Persona']['foto']['size'] == 0){
										$this->request->data['Persona']['foto'] = $this->request->data['Persona']['fotocam'];
						}else{
									$this->request->data['Persona']['foto'] = $this->upload($this->request->data['Persona']['foto'], realpath('img/photos/final/'), md5(trim($this->request->data['Persona']['cedula'])));
					}
     	          if($this->Persona->save($this->request->data))
     	                  	$this->Session->setFlash('<em><b>Datos</b> de <b>Persona</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
                      else
                        	$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta')); 
                $this->redirect('/personas/buscar/');
          }   else {
            
              $this->data = $this->Persona->read(NULL,$this->Convert->decode($id));

         $data = array(
							'title_for_layout' => 'Personas - Editar(Registro)',
							'generos'	  	   => $this->Persona->Genero->find('list', array('fields' => array('id', 'descripcion'))),
							'grupos'	  	   => $this->Persona->Grupo->find('list', array('fields' => array('id', 'descripcion'))),
							'tallas'	  	   => $this->Persona->Talla->find('list', array('fields' => array('id', 'descripcion'))),
							'paises'  	   	   => $this->Persona->Pais->find('list', array('fields' => array('id', 'descripcion'))),
                            'estados'  	   	   => $this->Persona->Pais->Estado->find('list', array('fields' => array('id', 'descripcion'), 'conditions'=>array('Estado.pais_id'=>$this->data['Persona']['paise_id']))),    				
                            'municipios'  	   => $this->Persona->Pais->Estado->Municipio->find('list', array('fields' => array('id', 'descripcion'), 'conditions'=>array('Municipio.estado_id'=>$this->data['Persona']['paise_id']))),    				
                            'parroquias'   	   => $this->Persona->Pais->Estado->Municipio->Parroquia->find('list', array('fields' => array('id', 'descripcion'), 'conditions'=>array('Parroquia.municipio_id'=>$this->data['Persona']['paise_id']))),    				

						);        
                        
          $this->set($data);  
            
          }         
       }else{
        	$this->Session->setFlash('<em>Datos de Persona no encontrados.</em>', 'default', array('class' => 'alerta'));
								$this->redirect('/personas/buscar/');
        
       }
       	
	}

    
}
?>