<?php
class EventosPersonasController extends AppController {

	public function beforeFilter()
	{
		parent::beforeFilter();
		$this->Auth->allow();
	}
	
	var $components =  array('PDF');
	
	
	

	
	public  function inscribir($evt_id = null) {
		
	    if(!is_null($evt_id)){
            
            if($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('count', 
                    array(
						    'conditions'=>array(
						        'Evento.id'=>$this->Convert->decode($evt_id), 
						        'Evento.status'=>true
						    ), 																											
						    'recursive'=>-1	
				         )
				) > 0)
		    {	
			    $feat = $this->EventosPersona->GetEventFeatures($this->Convert->decode($evt_id));
                $count = $this->EventosPersona->CountNumberRegisterByEvent($this->Convert->decode($evt_id));
                 
                 
                if($feat['Caracteristica']['activar_general']){
                    
                    if($count < $feat['Caracteristica']['p_atl']){
                    
                    	    $to_year = date('Y',(date("Y")+strtotime('+10 years')));	
                    	
                    	    for($i = date('Y'); $i < $to_year; $i++):
                    	 	    $yy[$i] = $i;
                    	    endfor;
                    	 
                            $data = array(
        							'title_for_layout' => 'Participantes - Evento (Registro)',
        							'features'		   => $feat,
        							'evento'    =>$this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('first', array(
        																											'conditions'=>array('Evento.id'=>$this->Convert->decode($evt_id)),
        																											'recursive'=>-1	
        																								)
        				            ),
                                    'evt_id'		 =>	$evt_id	,
        							'generos'	  	   => $this->EventosPersona->Persona->Genero->find('list', array('fields' => array('id', 'descripcion'))),
        							'generated_id'	   => $this->EventosPersona->find('first', array(
																						'fields' => array('id'),
																						'recursive' => -1,
																						'order' => array('id DESC')
																					)
																			),
        							'grupos'	  	   => $this->EventosPersona->Persona->Grupo->find('list', array('fields' => array('id', 'descripcion'))),
        				            'clubes'	  	   => $this->EventosPersona->Persona->Club->find('list', array('fields' => array('id', 'descripcion'))),									
        							'tallas'	  	   => $this->EventosPersona->Persona->Talla->find('list', array('fields' => array('id', 'descripcion'))),
        							'paises'  	   	   => $this->EventosPersona->Persona->Pais->find('list', array('fields' => array('id', 'descripcion'))),
        							'yy' =>	$yy,			
        							'disciplinas'      => $this->likeAList($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->find('all', array(
        																							'fields'=>array('DISTINCT disciplina_id'),
        																							'conditions'=>array('DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id)), 
        																							'recursive'=>-1,
        																							'contain'=>array(
        																									'Disciplina'=>array(
        																												'fields'=>array('id','descripcion')
        																										)
        																								)
        																							)
        																						), 'Disciplina'),
        																		
        				    );            
                        
                            $this->set($data);
                                
                            if($this->request->is('post')){
                                
                                $flag = $this->EventosPersona->_check_cedula($this->request->data['Persona']['cedula'],$this->Convert->decode($evt_id));
                                if($flag==0){
                                    
                                                $this->request->data['EventosPersona']['categorias_disciplinas_evento_id'] =$this->Convert->decode($this->request->data['CategoriasDisciplinasEvento']['id']);										
                    						    $this->request->data['EventosPersona']['n_participacion'] = trim($this->Convert->decode( $this->request->data['EventosPersona']['n_participacion']));
                    							
                    							unset($this->request->data['CategoriasDisciplinasEvento']);
                    							
                    							if($feat['Caracteristica']['activar_foto'])
                    							{
                    								
                    								if($this->request->data['Persona']['foto']['size'] == 0){
                    										$this->request->data['Persona']['foto'] = $this->request->data['Persona']['fotocam'];
                    								}else{
                    									if(!$this->request->data['Persona']['foto'] = $this->upload($this->request->data['Persona']['foto'], realpath('img/photos/final/'), md5(trim($this->request->data['Persona']['cedula']))))
                    										$this->redirect('/EventosPersonas/inscribir/'.$evt_id);
                    								}
                    							}
                    							
                                                $check = $this->EventosPersona->__check_nparticipacion($this->request->data);
            						            if($check)
            						            {
            						                $this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br><b>NOTA:</b> El Número de particición ya esta registrado en nuestra Base de Datos, refresque el navegador y vuelva a intentarlo o <br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
                                                    $this->redirect('/EventosPersonas/inscribir/'.$evt_id); 
            						            }
            						            
                    							if((isset($this->request->data['EventosPersona']['opcion_pago']))&&($this->request->data['EventosPersona']['opcion_pago']==1))
                    							{		
            						                
            						                 $resp =  json_decode($this->__Instapago($this->request->data));
            						                 $code = intval($resp->code);
            						                 if($code == 201)
            						                 { 
                    							        $this->request->data['EventosPersona']['n_transaccion'] = $resp->approval;
                    							        $this->request->data['EventosPersona']['f_transaccion'] = date('d/M/Y');
                    							        $this->request->data['EventosPersona']['t_transaccion'] = 'P';
                    							        $inscripcion = $this->EventosPersona->saveAssociated($this->request->data);
                    							        if(count($inscripcion) > 0){
                    							            $data = $this->__consultingData($this->EventosPersona->id);
            											    $data['Instapago'] = $resp->voucher;
            											
            											    $this->PDF->makePDF($data, Router::url('/', true)); 
            											    if($this->__send($data))
            											    {
            												    $this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b> recuerde revisar la cuenta de correo que registró en el sistema con el fin de validar el envío de su constacia de validación.', 'default', array('class' => 'exito'));
            												}else{
            													$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
            												}
            												
            											    $this->__removeFile($data);
            											    $this->redirect('/EventosPersonas/inscribir/'.$evt_id);
                    							        }else{
                    							             $this->Session->setFlash('<em>Se ha realizado el pago mas no se ha podido registrar su participación.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            										         $this->redirect('/EventosPersonas/inscribir/'.$evt_id);
                    							        }
            						                 }else{
            							                    $this->Session->setFlash('<em>Han ocurrido errores al intentar de realizar el pago: Código:'.$resp->code.':'.$resp->message.'.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            							                    $this->redirect('/EventosPersonas/inscribir/'.$evt_id);
            							              }
            					                }elseif((isset($this->request->data['EventosPersona']['opcion_pago']))&&($this->request->data['EventosPersona']['opcion_pago']==2)){
            					                    
            					                    $check = $this->EventosPersona->__check_ntransaccion($this->request->data);
            						                if($check)
            						                {
            						                    $this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br><b>NOTA:</b> El Número de trasacción ya esta registrado en nuestra Base de Datos<br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
                                                        $this->redirect('/EventosPersonas/inscribir/'.$evt_id);
            						                }
            						                $inscripcion = $this->EventosPersona->saveAssociated($this->request->data);
            						                if(count($inscripcion) > 0)
            						                {
            											$data = $this->__consultingData($this->EventosPersona->id);
            											$this->PDF->makePDF($data, Router::url('/', true)); 
            											if($this->__send($data))
            											{
            												$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b> recuerde revisar la cuenta de correo que registró en el sistema con el fin de validar el envío de su constacia de validación.', 'default', array('class' => 'exito'));
            											}else
            											{
            												$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
            											}
            											$this->__removeFile($data);
            											$this->redirect('/EventosPersonas/inscribir/'.$evt_id);

            									    }else{
            											$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            											$this->redirect('/EventosPersonas/inscribir/'.$evt_id);
            								        }             		
            					                }else{
            					                         $inscripcion = $this->EventosPersona->saveAssociated($this->request->data);
            						                     if(count($inscripcion) > 0)
            						                     {
                											$data = $this->__consultingData($this->EventosPersona->id);
                											$this->PDF->makePDF($data, Router::url('/', true)); 
                											if($this->__send($data))
                											{
                												$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b> recuerde revisar la cuenta de correo que registró en el sistema con el fin de validar el envío de su constacia de validación.', 'default', array('class' => 'exito'));
                											}else
                											{
                												$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
                											}
                											$this->__removeFile($data);
                											$this->redirect('/EventosPersonas/inscribir/'.$evt_id);
            					                        }else{
            					                            	$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            											        $this->redirect('/EventosPersonas/inscribir/'.$evt_id);
            					                        }
            			                    	}		
                                }elseif($flag==1){
                                                    $this->Session->setFlash('<em>No se ha proporcionado valor para el campo Cédula de Identidad.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            										$this->redirect('/EventosPersonas/inscribir/'.$evt_id);
                                }elseif($flag==2){
                                                    $this->Session->setFlash('<em>La Cédula de Identida proporcionada ya se encuentra registrada para este evento.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
            										$this->redirect('/EventosPersonas/inscribir/'.$evt_id);
                              }
                        
                            }
                        }else{
                                $this->Session->setFlash('<em>Las incripciones on-line para este <b>Evento</b> ya han sido alcanzadas .</em>', 'default', array('class' => 'alerta'));
						        $this->redirect('/eventos/common/');
                        }
                }else{
                        $this->Session->setFlash('<em>Este <b>Evento</b> aún no cuenta con la participación general .</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
				        $this->redirect('/eventos/common/');
                }
            }else{
                    $this->Session->setFlash('<em>El <b>Evento</b> seleccionado no existe o ha sido cerrado, elija un <b>Evento</b> de la lista mostrada a continuación .</em>', 'default', array('class' => 'alerta'));
					$this->redirect('/eventos/common/');	
            }
	   }else{
	            $this->Session->setFlash('<em>Seleccione un <b>Evento</b> de la lista mostrada a continuación .</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
	            $this->redirect('/eventos/common/');
	   }
      
	}
	


	public  function menores($evt_id) {
		if(!is_null($evt_id)){
                
                 if($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('count', array(
																											'conditions'=>array('Evento.id'=>$this->Convert->decode($evt_id), 'Evento.status'=>true ),
																											'recursive'=>-1	
				)) > 0)
		    {	
				 $feat = $this->EventosPersona->GetEventFeatures($this->Convert->decode($evt_id));
                 $count = $this->EventosPersona->CountNumberRegisterByEvent($this->Convert->decode($evt_id));
                 
                 
                 if($feat['Caracteristica']['activar_menor']){
                    
                    if($count < $feat['Caracteristica']['p_atl']){																		
						$data = array(
								'title_for_layout' => 'Participantes - Evento (Registro)',
								'features'		   => $feat,
								'evento'    =>$this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('first', array(
																											'conditions'=>array('Evento.id'=>$this->Convert->decode($evt_id)),
																											'recursive'=>-1	
																								)
				),
								'generated_id'	   => $this->EventosPersona->find('first', array(
																							'fields' => array('id'),
																							'recursive' => -1,
																							'order' => array('id DESC')
																						)
																				),
								'generos'	  	   => $this->EventosPersona->Persona->Genero->find('list', array('fields' => array('id', 'descripcion'))),
								'grupos'	  	   => $this->EventosPersona->Persona->Grupo->find('list', array('fields' => array('id', 'descripcion'))),
								'tallas'	  	   => $this->EventosPersona->Persona->Talla->find('list', array('fields' => array('id', 'descripcion'))),
								'paises'  	   	   => $this->EventosPersona->Persona->Pais->find('list', array('fields' => array('id', 'descripcion'))),				
								'disciplinas'	   => $this->likeAList($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->find('all', array(
																								'fields'=>array('DISTINCT disciplina_id'),
																								'conditions'=>array('DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id)), 
																								'recursive'=>-1,
																								'contain'=>array(
																										'Disciplina'=>array(
																													'fields'=>array('id','descripcion')
																											)
																									)
																								)
																							), 'Disciplina'),
								'evt_id'		 =>	$evt_id														
							);
						
						if(!empty($this->request->data)){
							
								$this->request->data['EventosPersona']['categorias_disciplinas_evento_id'] =$this->Convert->decode($this->request->data['CategoriasDisciplinasEvento']['id']);										
								$this->request->data['EventosPersona']['persona_id'] = $this->request->data['Persona']['id']	;
								$this->request->data['EventosPersona']['n_participacion'] = trim($this->Convert->decode( $this->request->data['EventosPersona']['n_participacion']));
								
								unset($this->request->data['CategoriasDisciplinasEvento']);
								
								if($feat['Caracteristica']['activar_foto'])
								{
									if($this->request->data['Persona']['foto']['size'] == 0){
											$this->request->data['Persona']['foto'] = $this->request->data['Persona']['fotocam'];
									}else{
										$this->request->data['Persona']['foto'] = $this->upload($this->request->data['Persona']['foto'], realpath('img/photos/final/'), md5(trim($this->request->data['Persona']['cedula'])));
									}
								}
								if($this->EventosPersona->saveAssociated($this->request->data)){
												$data = $this->__consultingData($this->EventosPersona->id);							
												$this->PDF->makePDF($data, Router::url('/', true)); 
												if($this->__send($data))
													$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b> recuerde revisar la cuenta de correo que registró en el sistema con el fin de validar el envío de su constacia de validación.', 'default', array('class' => 'exito'));
													else
														$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
												$this->__removeFile($data);
												$this->redirect('/EventosPersonas/menores/'.$evt_id);
											
										}else{
												$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
												//$this->redirect('/EventosPersonas/menores/'.$evt_id);
									}
												
				
								
						}
						$this->set($data);
								}else{
						$this->Session->setFlash('<em>Las incripciones on-line para este <b>Evento</b> ya han sido alcanzadas .</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/common/');	
								}
					}else{
						$this->Session->setFlash('<em>Este <b>Evento</b> no cuenta con la participación de <b>Categorías</b> menores a las <b>Pre-Infantiles</b> e <b>Infantiles</b>.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/common/');	
					}
		   }else{
						$this->Session->setFlash('<em>El <b>Evento</b> seleccionado no existe o ha sido cerrado, elija un <b>Evento</b> de la lista mostrada a continuación .</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/common/');	
		   }
		}else{
				$this->Session->setFlash('<em>Seleccione un <b>Evento</b> de la lista mostrada a continuación .</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/common/');	
		}
	}



	public  function delegacion($evt_id) {
	if(!is_null($evt_id)){
                
                 if($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('count', array(
																											'conditions'=>array('Evento.id'=>$this->Convert->decode($evt_id), 'Evento.status'=>true ),
																											'recursive'=>-1	
				)) > 0)
		    {	
				 $feat = $this->EventosPersona->GetEventFeatures($this->Convert->decode($evt_id));
                 $count = $this->EventosPersona->CountNumberRegisterByEvent($evt_id);
                 
                 
                 if($feat['Caracteristica']['activar_personal']){
                    
                
				
					$data = array(
							'title_for_layout' => 'Participantes - Evento (Registro)',
							'features'		   => $feat,
							'evento'    =>$this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('first', array(
																											'conditions'=>array('Evento.id'=>$this->Convert->decode($evt_id)),
																											'recursive'=>-1	
																								)
				),
							'generated_id'	   => $this->EventosPersona->find('first', array(
																						'fields' => array('id'),
																						'recursive' => -1,
																						'order' => array('id DESC')
																					)
																			),
							'generos'	  	   => $this->EventosPersona->Persona->Genero->find('list', array('fields' => array('id', 'descripcion'))),
							'grupos'	  	   => $this->EventosPersona->Persona->Grupo->find('list', array('fields' => array('id', 'descripcion'))),
							'tallas'	  	   => $this->EventosPersona->Persona->Talla->find('list', array('fields' => array('id', 'descripcion'))),
							'paises'  	   	   => $this->EventosPersona->Persona->Pais->find('list', array('fields' => array('id', 'descripcion'))),				
							'funciones'		   => $this->EventosPersona->Funcion->find('list', array('conditions'=>array('Funcion.id > '=>1), 'fields' => array('id', 'descripcion'))),
							'disciplinas'	   => $this->likeAList($this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->find('all', array(
																							'fields'=>array('DISTINCT disciplina_id'),
																							'conditions'=>array('DisciplinasEvento.evento_id'=>$this->Convert->decode($evt_id)), 
																							'recursive'=>-1,
																							'contain'=>array(
																									'Disciplina'=>array(
																												'fields'=>array('id','descripcion')
																										)
																								)
																							)
																						), 'Disciplina'),
							'evt_id'		 =>	$evt_id														
						);
					
					if(!empty($this->request->data)){
							
							$this->request->data['EventosPersona']['categorias_disciplinas_evento_id'] =$this->Convert->decode($this->request->data['CategoriasDisciplinasEvento']['id']);										
							$this->request->data['EventosPersona']['persona_id'] = $this->request->data['Persona']['id']	;
							$this->request->data['EventosPersona']['funcion_id'] = $this->request->data['Persona']['funcion_id'];
							
							unset($this->request->data['CategoriasDisciplinasEvento']);
							
							if($feat['Caracteristica']['activar_foto'])
							{
								if($this->request->data['Persona']['foto']['size'] == 0){
										$this->request->data['Persona']['foto'] = $this->request->data['Persona']['fotocam'];
								}else{
									$this->request->data['Persona']['foto'] = $this->upload($this->request->data['Persona']['foto'], realpath('img/photos/final/'), md5(trim($this->request->data['Persona']['cedula'])));
								}
							}
							if($this->EventosPersona->saveAssociated($this->request->data)){
											$data = $this->__consultingData($this->EventosPersona->id);
											$this->PDF->makePDF($data, Router::url('/', true)); 
											if($this->__send($data))
												$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
												else
													$this->Session->setFlash('<em><b>Datos</b> de <b>Participante</b> procesados satisfactoriamente.</em><br/><b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
											$this->__removeFile($data);
											$this->redirect('/EventosPersonas/delegacion/'.$evt_id);
									}else{
											$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
											$this->redirect('/EventosPersonas/delegacion/'.$evt_id);
								}
											
			
							
					}
					$this->set($data);
					}else{
						$this->Session->setFlash('<em>Este <b>Evento</b> no tiene contemplado el registro on-line de la delegación en su totalidad (Entrenadores, Delegados, Acompañantes y Voluntarios).</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/common/');	
					}
		   }else{
						$this->Session->setFlash('<em>El <b>Evento</b> seleccionado no existe o ha sido cerrado, elija un <b>Evento</b> de la lista mostrada a continuación .</em>', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/common/');	
		   }
		}else{
				$this->Session->setFlash('<em>Seleccione un <b>Evento</b> de la lista mostrada a continuación .</em><br /><a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/common/');	
		}
	}

public function print_constancia($id = null)
    {
       $this->layout = 'pdf';
        if(!is_null($id))
        {
        	
            	$data = $this->__consultingData($this->Convert->decode($id));
            	
          
		$this->set(compact('data'));
            
        }else{
					$this->Session->setFlash('<em>Datos de Evento no encontrados.</em>', 'default', array('class' => 'alerta'));
				    $this->redirect($this->referer());          
            
        }
      
    }
    
    
     public function send_constancia($id = null)
    {
        
        if(!is_null($id))
        {
            	$data = $this->__consultingData($this->Convert->decode($id));
				$this->PDF->sendingPDF($data, Router::url('/', true)); 
                	if($this->__send($data))
												$this->Session->setFlash('<em><b>Datos</b> de <b>Participación</b> enviados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
												else
													$this->Session->setFlash('<b>Nota:</b>No se ha podido enviar correo con constancia de inscripción, <a href="acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
											$this->__removeFile($data);
										$this->redirect($this->referer());  
        }else{
					$this->Session->setFlash('<em>Datos de Evento no encontrados.</em>', 'default', array('class' => 'alerta'));
				    $this->redirect($this->referer());          
            
        }
        
        
    }

  public function descartar($id){
      	    if(!is_null($id))
       {
        if($this->EventosPersona->find('count', array(
																											'conditions'=>array('EventosPersona.id'=>$this->Convert->decode($id) ),
																											'recursive'=>-1	
				)) > 0)
		    {	
		    
		    		 $data = $this->EventosPersona->findById($this->Convert->decode($id) );
		   		 $this->EventosPersona->delete($data['EventosPersona']['id']);
		   		 $this->Session->setFlash('<em><b> Participación  descartada satisfactoriamente.</em>', 'default', array('class' => 'exito'));
		    		$this->redirect('/personas/buscar/');
		    
       			}else{
       					$this->Session->setFlash('<em>Datos de Persona no encontrados.</em>', 'default', array('class' => 'alerta'));
								$this->redirect('/personas/buscar/');
       			}
          }else{
        	$this->Session->setFlash('<em>Datos de Persona no encontrados.</em>', 'default', array('class' => 'alerta'));
								$this->redirect('/personas/buscar/');
        
       }
      }



	private function __send($data) { 
		 	 

			 $this->set(compact('data')); 
			// $this->Email->SMTPAuth = false;
            // $this->Email->SMTPSecure = false;
			 $this->Email->from = 'tutorneo@tutorneo.biz';
			 $this->Email->fromName = 'TuTorneo';
			 $this->Email->to = $data[0]['Persona']['correo']; 
			 $this->Email->subject = 'TuTorneo.biz. Inscripción en Evento - '.$data[0]['CategoriasDisciplinasEvento']['DisciplinasEvento']['Evento']['nombre']; 
			 $this->Email->attach(WWW_ROOT . 'files'.DS.'pdf' . DS . 'constancia_'.$data[0]['EventosPersona']['id'].'.pdf'); 
			 return $this->Email->send();
			 		
    } 	
	  
	private function __consultingData($id)
	{
			$this->EventosPersona->Behaviors->load('Containable');
			return($this->EventosPersona->find(
										'all', array(
												'conditions'=>array('EventosPersona.id'=>$id),
												'contain'=>array(
													'Persona'=>array(
															'fields'=>array(
																			'Persona.cedula',
																			'Persona.nombre', 
																			'Persona.apellido', 
																			'Persona.f_nacimiento', 
																			'Persona.genero_id', 
																			'Persona.edad', 
																			'Persona.foto',
																			'Persona.correo'
																			),
															'Genero',
													),
													'Funcion',
													'CategoriasDisciplinasEvento'=>array(
															'fields'=>array(
																'disciplinas_evento_id',
																'categoria_id'
															),
															'Categoria'=>array(
																'fields'=>array('descripcion')
															),
															'DisciplinasEvento'=>array(
																	'Evento'=>array(
																			'fields'=>array(
																							'Evento.nombre', 
																							'Evento.f_inicio', 
																							'Evento.f_fin',
																							'Evento.banner',
                                         'Evento.descripcion'
																							),
                                                                      'Configuracion',
                                                                      'Caracteristica'
																	),
																	'Disciplina',
																	'Modalidad'																
															),
													)
												)
										)
			));
	}
	
	
	public function __removeFile($data)
	{
		if (file_exists(WWW_ROOT . 'files'.DS.'pdf' . DS . 'constancia_'.$data[0]['EventosPersona']['id'].'.pdf'))
			unlink(WWW_ROOT . 'files'.DS.'pdf' . DS . 'constancia_'.$data[0]['EventosPersona']['id'].'.pdf');
	}
	
	
	public function check_num_transacc($val)
	{
		$this->autoRender = false;
    	$this->response->type('json');
	    if(($this->EventosPersona->find('count', array(
		 					'conditions'=>array(
										'n_transaccion'=>$this->Convert->decode($val)
							),
							'recursive'=>-1
					)
			)
		) > 0)
		    $json = json_encode(array('rs'=>'1'));
		else
		    $json = json_encode(array('rs'=>'0'));
			
    	$this->response->body($json);		
	}
	
	private function __Instapago($data)
	{
	
		$evt_nombre = $this->EventosPersona->CategoriasDisciplinasEvento->DisciplinasEvento->Evento->find('first', 
							array(
							          'fields'=>('Evento.Nombre'),
							          'conditions'=>array('Evento.id'=>$data['EventosPersona']['evento_id']), 
							          //,'Evento.status'=>true	
							          'recursive'=>-1	
								)
				);
		$url = 'https://api.instapago.com/payment';
		$fields = array(
				"KeyID" => "70AE4F9B-E3ED-4063-8693-84565EEE8A93",//"CEBF11A0-C5FA-4144-A6C0-C3B064CCDD0E" , 
				"PublicKeyId" => "2c3627ec1d48a2b502a700e71d482df5",//"2c3627ec1d48a2b502a700e71d482df5", 
				"Amount" =>$data['EventosPersona']['monto'],
				"Description" => "INSCRIPCION EVENTO ".$evt_nombre['Evento']['Nombre'] ,
				"CardHolder"=> $data['EventosPersona']['t_nombre'],
				"CardHolderId"=> $data['EventosPersona']['t_cedula'], 
				"CardNumber" => $data['EventosPersona']['n_tarjeta'], 
				"CVC" => $data['EventosPersona']['t_cvc'],
				"ExpirationDate" => ($data['EventosPersona']['t_mes_ven']."/". $data['EventosPersona']['t_year_ven']), 
				"StatusId" => "2");
		$ch = curl_init();
		curl_setopt($ch, CURLOPT_URL,$url );
		curl_setopt($ch, CURLOPT_POST, 1);
		curl_setopt($ch, CURLOPT_POSTFIELDS,http_build_query($fields));
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		$server_output = curl_exec ($ch);
		curl_close ($ch);
		return  $server_output ;
	
	
	}
	
	
	
	
	
}
?>