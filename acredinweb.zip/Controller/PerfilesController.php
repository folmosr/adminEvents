<?php
class PerfilesController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_perfil = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Perfil->find('all', array(
																	'order'=>'Perfil.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Perfil']['id'] = (!empty($this->request->data['Perfil']['id']))?$this->Convert->decode($this->request->data['Perfil']['id']):NULL;
					if($this->Perfil->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Perfil</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/perfiles/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/perfiles/crear/');		
					}
			}
			if(!is_null($id_perfil)){
				$this->Perfil->recursive=-1;
				$this->data = $this->Perfil->read(NULL,$this->Convert->decode($id_perfil));
			}
			$this->set($var_configs);
		}


	public function q_on($id_perfil)
	{
		if(!is_null($id_perfil)){
			$id_perfil =  $this->Convert->decode($id_perfil);
			if($this->Perfil->delete($id_perfil, true)){
							$this->Session->setFlash('<em><b>Datos de Perfil</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/perfiles/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el perfil a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/perfiles/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Perfil</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/perfiles/crear/');		
		}
	}






}
?>