<?php
class EventosController extends AppController {

	public function beforeFilter()
	{
		parent::beforeFilter();
		$this->Auth->allow(array('common', 'descripcion'));
	}
 
	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	


 	public $helpers 	= array('Wysiwyg.Nicedit', 'CustomFunctions');
    	public $components  = array('DataTable','Paginator');
	public $paginate = array(
    	    'limit' => 100,
        	'order' => array(
            	'Evento.f_inicio' => 'asc'
        	),
			'contain'=>array(
				'Caracteristica'
			),
			'conditions'=>array(
					'Evento.status'=>true
			)
    );	


		
	public  function crear() {
	
		$data = array(
				'title_for_layout' => 'Módulo Aprendiz (Crear)');
		if(!empty($this->request->data)){
	   		
			if(
			
			($this->request->data['Evento']['imagen'] =	$this->upload($this->request->data['Evento']['imagen'], realpath('img/img_eventos/'), $this->Convert->encode(strtolower(trim($this->request->data['Evento']['nombre'])))))
			
			&&

($this->request->data['Evento']['banner'] =	$this->upload($this->request->data['Evento']['banner'], realpath('img/banners_eventos/'), $this->Convert->encode(strtolower(trim($this->request->data['Evento']['nombre']))), 720, 215))			
			
			){
				
				//$this->request->data['Caracteristica']['evento_id'] = $this->Convert->decode($this->request->data['Caracteristica']['evento_id']);
				if($this->Evento->saveAssociated($this->request->data)){
								
								$this->Session->setFlash('<em><b>Datos Básicos</b> de <b>Evento</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
								$this->redirect('/eventos/listar/');	
						}else{
							
								$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
								$this->redirect('/eventos/listar/');		
					}
				}
		}
	   $this->set($data);
	}
	
	
		
	public function activar($evento_id){
		if(!is_null($evento_id))
		{
			if( $this->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{	
				$this->Evento->Behaviors->load('Containable');
				$this->Evento->recursive = -1;
				$config_vars = array(
									'data' => $this->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($evento_id)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
										'feature_keys'=>array(
														'activar_foto'	   =>	'Permitir carga de foto',
														'activar_grupo'	   =>	'Permitir agrupación de participantes',
														'activar_menor'	   =>	'Permitir participación de menor de edad',
														'activar_limite'   =>	'Limitar Nº de participantes',
														'activar_personal' =>	'Permitir registro de personal',
														
										)
					);
				if(!empty($this->request->data)){
						$this->request->data['Evento']['id'] =$this->Convert->decode($this->request->data['Evento']['id']) ;
						if($this->Evento->save($this->request->data)){
									$this->Session->setFlash('<em><b>Datos Activación</b> de <b>Evento</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/eventos/activar/'.$evento_id);		
								}else{
									$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
									$this->redirect('/eventos/activar/'.$evento_id);		
							}			
				}
				$this->set($config_vars);
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}
	}
	
	public function detalle($evento_id)
	{
		if(!is_null($evento_id))
		{
			if( $this->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{	

				$this->Evento->Behaviors->load('Containable');
				$this->Evento->recursive = -1;
				$config_vars = array(
										'data' =>$this->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($evento_id)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
										'feature_keys'=>array(
														'activar_foto'	   =>	'Permitir carga de foto',
														'activar_grupo'	   =>	'Permitir agrupación de participantes',
														'activar_menor'	   =>	'Permitir participación de menor de edad',
														'activar_limite'   =>	'Limitar Nº de participantes',
														'activar_personal' =>	'Permitir registro de personal',
														
										)
					);

				$this->set($config_vars);
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}

	}
	
	public function editar($evento_id)
	{

                   
		$this->Evento->Behaviors->load('Containable');
		if(!is_null($evento_id))
		{
			if( $this->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)), 'recursive'=>-1)) > 0)
			{	
				if($this->request->is('put')){
						if(!$this->request->data['Caracteristica']['activar_grupo']){
							$this->request->data['Caracteristica']['n_grupo'] = 0;
							$this->request->data['Caracteristica']['p_grupo'] = 0;
						}
						if($this->request->data['Evento']['imagen']['size'] > 0){
							if(file_exists(realpath('img/img_eventos/'.$this->request->data['Evento']['photo_temp'])))
									unlink(realpath('img/img_eventos/'.$this->request->data['Evento']['photo_temp']));
							 if(!$this->request->data['Evento']['imagen'] =	$this->upload($this->request->data['Evento']['imagen'], realpath('img/img_eventos/'), $this->Convert->encode(strtolower(trim($this->request->data['Evento']['nombre'])))))
									$this->redirect('/eventos/editar/'.$evento_id);										
							
						}else
								$this->request->data['Evento']['imagen'] =	$this->request->data['Evento']['photo_temp'];
								
						if($this->request->data['Evento']['banner']['size'] > 0){
							if(file_exists(realpath('img/banners_eventos/'.$this->request->data['Evento']['banner_temp'])))
									unlink(realpath('img/banners_eventos/'.$this->request->data['Evento']['banner_temp']));
							 if(!$this->request->data['Evento']['banner'] =	$this->upload($this->request->data['Evento']['banner'], realpath('img/banners_eventos/'), $this->Convert->encode(strtolower(trim($this->request->data['Evento']['nombre']))), 720, 215))
									$this->redirect('/eventos/editar/'.$evento_id);										
							
						}else
								$this->request->data['Evento']['banner'] =	$this->request->data['Evento']['banner_temp'];		
								
								
							    $this->request->data['Evento']['id'] =	$this->Convert->decode($this->request->data['Evento']['identificador']);	
								$this->request->data['Caracteristica']['evento_id'] =	$this->Convert->decode($this->request->data['Evento']['identificador']);	
								$this->request->data['Caracteristica']['id'] =	$this->Convert->decode($this->request->data['Caracteristica']['identificador']);	
							if($this->Evento->saveAssociated($this->request->data)){
												$this->Session->setFlash('<em><b>Datos de <b>Evento</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
												$this->redirect('/eventos/listar');		
											}else{
												$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
												$this->redirect('/eventos/listar');		
										}			
				}else{
									$this->data = $this->Evento->find('first', array(
																		'conditions' => array('Evento.id' => $this->Convert->decode($evento_id)),
																		'contain'=>array('Caracteristica'),
																		'recursive'=>-1
																	)
													);
				}
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}
	}



	public function q_on($evento_id){
		if(!is_null($evento_id))
		{
			if( $this->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{			
						
						$data =  $this->Evento->find('first', array( 'recursive'=>-1, 'conditions' => array('Evento.id' => $this->Convert->decode($evento_id))));
						$data['Evento']['status'] = ($data['Evento']['status'])?false:true;
						if($this->Evento->save($data)){
									$this->Session->setFlash('<em><b>Datos Activación</b> de <b>Evento</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/eventos/listar');		
								}else{
									$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
									$this->redirect('/eventos/listar/');		
							}			
				
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}
	}



	public function common()
	{
		 $this->Evento->Behaviors->load('Containable');
		 $this->Paginator->settings = $this->paginate;
		 $data = $this->Paginator->paginate('Evento');
		 $config_vars =  array(
		 	'data'=> $data
		 );
		 $this->set( $config_vars );			
	}
	
	public function descripcion ($evento_id)
	{
		if(!is_null($evento_id))
		{
			if( $this->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{			
					$feat = $this->Evento->Caracteristica->find('first', array(
																											'conditions'=>array('Caracteristica.evento_id'=>$this->Convert->decode($evento_id)),
																											'recursive'=>-1	
																											)
																									);
						$var_configs =array(
								'data'=>$this->Evento->find('first', array( 'recursive'=>-1, 'conditions' => array('Evento.id' => $this->Convert->decode($evento_id)))),
								'features' => $feat,
								'evt_id'=>$evento_id
							);
						$this->set($var_configs);				
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/common/');		
			}
		
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/common/');		
		}
	}
	
	public function listar(){}
	
}