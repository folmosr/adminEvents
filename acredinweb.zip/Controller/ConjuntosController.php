<?php
class ConjuntosController extends AppController {
 
	public function beforeFilter()
	{
		parent::beforeFilter();
		$this->Auth->allow();
	}
	
	public function crear ($evnt_id)
	{
		$config = array(
			'generated_id'	   =>	$this->Conjunto->find('first', array(
																			'fields' => array('id'),
																			'recursive' => -1,
																			'order' => array('Conjunto.id DESC')
																			)
																	),
			'features'=>$this->Conjunto->Evento->Caracteristica->find('first', array('conditions'=>array('Caracteristica.evento_id'=>$this->Convert->decode($evnt_id)),
																											'recursive'=>-1	
																											)
																										),														
			'evnt_id'=>$evnt_id,
			
			'n_grupos'=>$this->Conjunto->find('count', array(
																'conditions'=>array('Conjunto.evento_id'=>$this->Convert->decode($evnt_id))			
															)
							)
		);
		if(!empty($this->request->data)){
				$this->request->data['Conjunto']['evento_id'] =  $this->Convert->decode($evnt_id);
				$this->request->data['ConjuntosPersona']['conjunto_id'] = $this->request->data['Conjunto']['id'];
				unset($this->request->data['Persona']);
				for($i = 0; $i < count($this->request->data['ConjuntosPersona']['persona_id']); $i++):
				  $data[] =  array(
						  			'persona_id'=>$this->request->data['ConjuntosPersona']['persona_id'][$i],
									'conjuntos_id'=>$this->request->data['Conjunto']['id'],
									'capitan'	=> ($this->request->data['ConjuntosPersona']['capitan'] == $this->request->data['ConjuntosPersona']['persona_id'][$i] )? true:false
							  );
				endfor;
				$this->request->data['ConjuntosPersona'] = $data;
				if($this->Conjunto->saveAssociated($this->request->data)){
					    if($this->__send($this->__getTeamInfo($this->Conjunto->id)))
						{
							$this->Session->setFlash('<em>El equipo <b>'.$this->request->data['Conjunto']['descripcion'].'</b> se ha creado con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/conjuntos/crear/'.$evnt_id);		
						}else{
							$this->Session->setFlash('<em>El equipo <b>'.$this->request->data['Conjunto']['descripcion'].'</b> se ha creado con éxito</em>, pero no se ha podido comunicar vía correo. <br /><a href="/acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'exito'));
							$this->redirect('/conjuntos/crear/'.$evnt_id);		
						}
					}else{
						$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em><br /><a href="/acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
						$this->redirect('/conjuntos/crear/'.$evnt_id);		
				}
		}
		$this->set($config);
		
	}
	
	private function __getTeamInfo($k_team)
	{
		return($this->Conjunto->find('all', array(
												'conditions'=>array('Conjunto.id'=>$k_team),
												'contain'=>array(
															'Evento'=>array(
																	'fields'=>array(
																					'Evento.nombre',
																					'Evento.f_inicio',
																					'Evento.f_fin'
																					)
															),
															'ConjuntosPersona'=>array(
																		'Persona'=>array(
																				'fields'=>array(
																							'Persona.cedula',
																							'Persona.nombre',
																							'Persona.apellido',
																							'Persona.correo'
																				)
																		)
																)
														)
								)
		));		
	}
	
	private function __send($data) {
		 $this->set(compact('data')); 
		 $this->Email->from = 'tutorneo@tutorneo.biz';
		 $this->Email->fromName = 'TuTorneo';
		 $this->Email->to = $this->__getEmailCapitan($data[0]['ConjuntosPersona']); 
		 $this->Email->subject = 'TuTorneo.biz. Creación de Equipo - '.$data[0]['Evento']['nombre']; 
		 return $this->Email->send();
			 		
    } 	
	
	private function __getEmailCapitan($data)
	{
		$mail = NULL;
		for($i = 0; $i < count($data); $i++):
				if((bool)$data[$i]['capitan']){
					$mail = $data[$i]['Persona']['correo'];
					break;
				}
		endfor;
		return($mail);
	}


	public function imprimir($evento_id)
	{

		if(!is_null($evento_id))
		{

			$this->layout = 'pdf';
			$data = $this->Conjunto->find('all', array(
												'conditions'=>array('Conjunto.evento_id'=>$this->Convert->decode($evento_id)),
												'order'=>array('Conjunto.id'),
												'contain'=>array(
															'Evento'=>array(
																	'fields'=>array(
																					'Evento.nombre',
																					'Evento.f_inicio',
																					'Evento.f_fin'
																					)
															),
															'ConjuntosPersona'=>array(
																		'Persona'=>array(
																				'fields'=>array(
																							'Persona.cedula',
																							'Persona.nombre',
																							'Persona.apellido',
																							'Persona.correo'
																				)
																		)
																)
														)
								)
		);
			if(count($data) > 0)
				$this->set(compact('data'));
			else{

						$this->Session->setFlash('<em>No encontraron Equipos conformados para este Evento.</em><br /><b>NOTA/:</b> Revise si para este Evento está disponible la opción de conformar Equipos, addemás <br /> <a href="/acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/listar/');	


			}


		}else{

						$this->Session->setFlash('<em>Es necesario el seleccionar un evento.</em><br /><a href="/acredinweb/contactos/">Contáctanos</a> y reportanos el inconveniente.', 'default', array('class' => 'alerta'));
						$this->redirect('/eventos/listar/');	

		}

	}
}
?>