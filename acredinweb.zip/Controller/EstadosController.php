<?php
class EstadosController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	


	public function crear($id_estado = NULL)
	{
			$var_configs = array(
				'paises'=>$this->Estado->Paise->find('list', array(
																	'fields'=>array('Paise.descripcion'),
																	'order'=>'Paise.descripcion'
																	)
							)
			);	
			if(!empty($this->request->data))
			{
					
					$this->request->data['Estado']['id'] = (!empty($this->request->data['Estado']['id']))?$this->Convert->decode($this->request->data['Estado']['id']):NULL;
					if($this->Estado->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Estado</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/estados/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/estados/crear/');		
					}
			}
			if(!is_null($id_estado)){
				$this->Estado->recursive=-1;
				$this->data = $this->Estado->read(NULL,$this->Convert->decode($id_estado));
			}
			$this->set($var_configs);
		}


	public function q_on($id_estado)
	{
		if(!is_null($id_estado)){
			$id_estado =  $this->Convert->decode($id_estado);
			if($this->Estado->delete($id_estado, true)){
							$this->Session->setFlash('<em><b>Datos de Estado</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/estados/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el estado a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/estados/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Estado</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/estados/crear/');		
		}
	}

	public function get_local_list($pais_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Estado->find('list', array(
																	'fields'=>array('Estado.descripcion'),
																	'conditions'=>array('Estado.pais_id'=>$this->Convert->decode($pais_id)),
																	'order'=>'Estado.descripcion'
																	
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}




}
?>