<?php
class TiposController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_tipo = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Tipo->find('all', array(
																	'order'=>'Tipo.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Tipo']['id'] = (!empty($this->request->data['Tipo']['id']))?$this->Convert->decode($this->request->data['Tipo']['id']):NULL;
					if($this->Tipo->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Tipo de Credencial</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/tipos/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/tipos/crear/');		
					}
			}
			if(!is_null($id_tipo)){
				$this->Tipo->recursive=-1;
				$this->data = $this->Tipo->read(NULL,$this->Convert->decode($id_tipo));
			}
			$this->set($var_configs);
		}


	public function q_on($id_tipo)
	{
		if(!is_null($id_tipo)){
			$id_tipo =  $this->Convert->decode($id_tipo);
			if($this->Tipo->delete($id_tipo, true)){
							$this->Session->setFlash('<em><b>Datos de Tipo de Credencial</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/tipos/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el tipo de credencial a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/tipos/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Tipo de Credencial</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/tipos/crear/');		
		}
	}






}
?>