<?php
class DisciplinasEventosController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function add($evento_id){
		if(!is_null($evento_id))
		{
			if( $this->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0)
			{	
				$this->DisciplinasEvento->Evento->Behaviors->load('Containable');
				$this->DisciplinasEvento->Evento->recursive = -1;
				$config_vars = array(
									'data' => $this->DisciplinasEvento->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($evento_id)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
										'feature_keys'=>array(
														'activar_foto'	   =>	'Permitir carga de foto',
														'activar_grupo'	   =>	'Permitir agrupación de participantes',
														'activar_menor'	   =>	'Permitir participación de menor de edad',
														'activar_limite'   =>	'Limitar Nº de participantes',
														'activar_personal' =>	'Permitir registro de personal',
														
							),
							'disciplinas'=>$this->DisciplinasEvento->Disciplina->find('list',array('fields'=>array('id','descripcion'))),
							'modalidades'=>$this->DisciplinasEvento->Modalidad->find('list',array('fields'=>array('id','descripcion'))),
				);
				if(!empty($this->request->data)){
						$this->request->data['DisciplinasEvento']['evento_id'] =$this->Convert->decode($this->request->data['DisciplinasEvento']['evento_id']) ;
						if($this->DisciplinasEvento->save($this->request->data)){
									$this->Session->setFlash('<em><b>Datos Deportivos</b> de <b>Evento</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/DisciplinasEventos/add/'.$evento_id);		
								}else{
									$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
									$this->redirect('/DisciplinasEventos/add/'.$evento_id);		
							}			
				}
				$this->set($config_vars);
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no encontrado.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/');		
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos Evento</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}
	}
 
    public  function edit($evento_id, $identificador) {

		if((!is_null($evento_id)) && (!is_null($identificador)))
		{
			if(( $this->DisciplinasEvento->find('count', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0) &&  ( $this->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0))
			{	
				$this->DisciplinasEvento->Evento->Behaviors->load('Containable');
				$this->DisciplinasEvento->Evento->recursive = -1;
				$config_vars = array(
				
							'data' => $this->DisciplinasEvento->Evento->find('all', array('conditions' => array('Evento.id'=>$this->Convert->decode($evento_id)),
																						'contain' =>array(
																											'Caracteristica'=>array('fields'=>array(
																																				'activar_foto',
																																				'activar_grupo',
																																				'activar_menor',
																																				'activar_limite',
																																				'activar_personal'
																																				)
																																	),
																									'DisciplinasEvento'=>array(
																												'Disciplina',
																												'Modalidad',
																												'CategoriasDisciplinasEvento'=>array(
																															'Categoria'
																												)
																											)
																																																										
																								),
																									
																								
																						)
																		
																			),
							'data_disciplina' => $this->DisciplinasEvento->find('all', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)), 'recursive'=>-1)),												
							'disciplinas'  	  => $this->DisciplinasEvento->Disciplina->find('list',array('fields'=>array('id','descripcion'))),
							'modalidades'  	  => $this->DisciplinasEvento->Modalidad->find('list',array('fields'=>array('id','descripcion'))),
							'feature_keys'	  =>array(
																'activar_foto'	   =>	'Permitir carga de foto',
																'activar_grupo'	   =>	'Permitir agrupación de participantes',
																'activar_menor'	   =>	'Permitir participación de menor de edad',
																'activar_limite'   =>	'Limitar Nº de participantes',
																'activar_personal' =>	'Permitir registro de personal',
																
												)	
						);


				if(!empty($this->request->data)){
								$this->request->data['DisciplinasEvento']['id'] = $this->Convert->decode($this->request->data['DisciplinasEvento']['id']) ;
								if($this->DisciplinasEvento->save($this->request->data)){
											$this->Session->setFlash('<em><b>Datos de Disciplina</b> procesados satisfactoriamente.</em>', 'default', array('class' => 'exito'));
											$this->redirect('/DisciplinasEventos/edit/'.$evento_id.'/'.$identificador);		
										}else{
											$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em>', 'default', array('class' => 'alerta'));
											$this->redirect('/DisciplinasEventos/edit/'.$evento_id.'/'.$identificador);		
									}			
				}
				$this->set($config_vars);
						
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em> no encontrado.</em><br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect($this->referer());// crear pàgina de detalle de evento
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect('/eventos/crear/');		
		}
	}
	

	public function discard($identificador, $evento_id)
	{
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{
			if(( $this->DisciplinasEvento->find('count', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0) &&  ( $this->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0))
			{	
		
					if($this->DisciplinasEvento->deleteAll(array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)), false)){
									$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina </b></em> eliminado sastifactoriamente.</em>', 'default', array('class' => 'exito'));
									$this->redirect('/eventos/detalle/'.$evento_id);		
						}else{
								$this->Session->setFlash('<em>Han ocurrido errores al intentar de procesar los datos.</em> <br /> <b>ATENCION:</b> Debido a que existen registro en la base de datos que dependen de esta información, el resultado no ha sido satisfactorio.', 'default', array('class' => 'alerta'));
								$this->redirect($this->referer());
					}
			}else{
				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em> no encontrado.</em><br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlle del evento
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect($this->referer());
		}

	}
	
	public function imprimir($identificador, $evento_id)
	{
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{

			if(( $this->DisciplinasEvento->find('count', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0) &&  ( $this->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0))
			{	
				 		 $this->layout = 'pdf';
		                 $data = $this->DisciplinasEvento->find('all', array('conditions' => array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)),
																						'contain' =>array(
																									'Disciplina',
																									'Evento'=>array(
																										'fields'=>array(
																												'nombre', 
																												'f_inicio',
																												'f_fin'
																										)
																									),
																									'Modalidad',
																									'CategoriasDisciplinasEvento'=>array(
																										'fields'=>array(
																												'id',
																												'disciplinas_evento_id',
																												'categoria_id'
																										),
																										'Categoria',
																										'EventosPersona'=>array(
																											'Funcion',
																											'Persona'=>array(
																												'fields'=>array(
																															'cedula', 
																															'apellido', 
																															'f_nacimiento',
																															'nombre', 
																															'tel_local', 
																															'tel_celular'
																												),
'Talla'																											)
																										)
																									)																																																															
																								),
																									
																								
																						)
																		
							);


					$this->set(compact('data'));		
			 

			}else{

				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em> no encontrado.</em><br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlle del evento
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect($this->referer());
		}

	}
	

	public function imprimir_excel($identificador, $evento_id)
	{
		if((!is_null($evento_id)) && (!is_null($identificador)))
		{

			if(( $this->DisciplinasEvento->find('count', array('conditions'=>array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)))) > 0) &&  ( $this->DisciplinasEvento->Evento->find('count', array('conditions'=>array('Evento.id'=>$this->Convert->decode($evento_id)))) > 0))
			{	

		                 $data = $this->DisciplinasEvento->find('all', array('conditions' => array('DisciplinasEvento.id'=>$this->Convert->decode($identificador)),
																						'contain' =>array(
																									'Disciplina',
																									'Evento'=>array(
																										'fields'=>array(
																												'nombre', 
																												'f_inicio',
																												'f_fin'
																										)
																									),
																									'Modalidad',
																									'CategoriasDisciplinasEvento'=>array(
																										'fields'=>array(
																												'id',
																												'disciplinas_evento_id',
																												'categoria_id'
																										),
																										'Categoria',
																										'EventosPersona'=>array(
																										'Persona'=>array(
																												'fields'=>array(
																															'cedula', 
																															'apellido', 
																															'f_nacimiento',
																															'nombre', 
																															'correo',
																															'estado_id',
																															'tel_local', 
																															'tel_celular'
																												),
																												

'Talla',
																												'Genero',
																												'Estado'																										)
																										)
																									)																																																															
																								),
																									
																								
																						)
																		
							);
					
					$this->set(compact('data'));		
			 

			}else{

				$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em> no encontrado.</em><br /><b>NOTA:</b><em>Error al procesar los datos recibidos.</em>', 'default', array('class' => 'alerta'));
				$this->redirect('/eventos/listar/'); //crear pagina para mostrar detlle del evento
			}
		}else{
			$this->Session->setFlash('<em><b>ATENCION:</b> <em><b>Datos de Disciplina</b></em>/<em><b>Datos de Evento </b></em> no recibido.</em>', 'default', array('class' => 'alerta'));
			$this->redirect($this->referer());
		}

	}

}
?>