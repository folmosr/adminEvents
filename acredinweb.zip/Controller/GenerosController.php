<?php
class GenerosController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_genero = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Genero->find('all', array(
																	'order'=>'Genero.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Genero']['id'] = (!empty($this->request->data['Genero']['id']))?$this->Convert->decode($this->request->data['Genero']['id']):NULL;
					if($this->Genero->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Género</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/generos/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/generos/crear/');		
					}
			}
			if(!is_null($id_genero)){
				$this->Genero->recursive=-1;
				$this->data = $this->Genero->read(NULL,$this->Convert->decode($id_genero));
			}
			$this->set($var_configs);
		}


	public function q_on($id_genero)
	{
		if(!is_null($id_genero)){
			$id_genero =  $this->Convert->decode($id_genero);
			if($this->Genero->delete($id_genero, true)){
							$this->Session->setFlash('<em><b>Datos de Género</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/generos/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el género a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/generos/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Género</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/generos/crear/');		
		}
	}






}
?>