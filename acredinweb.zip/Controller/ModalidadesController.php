<?php
class ModalidadesController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_modalidad = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Modalidad->find('all', array(
																	'order'=>'Modalidad.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Modalidad']['id'] = (!empty($this->request->data['Modalidad']['id']))?$this->Convert->decode($this->request->data['Modalidad']['id']):NULL;
					if($this->Modalidad->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Modalidad</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/modalidades/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/modalidades/crear/');		
					}
			}
			if(!is_null($id_modalidad)){
				$this->Modalidad->recursive=-1;
				$this->data = $this->Modalidad->read(NULL,$this->Convert->decode($id_modalidad));
			}
			$this->set($var_configs);
	}


	public function q_on($id_modalidad)
	{
		if(!is_null($id_modalidad)){
			$id_modalidad =  $this->Convert->decode($id_modalidad);
			if($this->Modalidad->delete($id_modalidad, false)){
							$this->Session->setFlash('<em><b>Datos de Modalidad</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/modalidades/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la modalidad a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/modalidades/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Modalidad</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/modalidades/crear/');		
		}
	}






}
?>