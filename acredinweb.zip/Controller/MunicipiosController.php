<?php
class MunicipiosController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_municipio = NULL)
	{
			$var_configs = array(
				'paises'=>$this->Municipio->Estado->Paise->find('list', array(
																	'fields'=>array('Paise.descripcion'),
																	'order'=>'Paise.descripcion'
																	)
							)
			);	
			if(!empty($this->request->data))
			{
					
					$this->request->data['Municipio']['id'] = (!empty($this->request->data['Municipio']['id']))?$this->Convert->decode($this->request->data['Municipio']['id']):NULL;
					if($this->Municipio->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Municipio</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/municipios/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/municipios/crear/');		
					}
			}
			if(!is_null($id_municipio)){
				$this->Municipio->recursive=0;
				$this->data = $this->Municipio->read(NULL,$this->Convert->decode($id_municipio));
				$var_configs['estados'] = $this->Municipio->Estado->find('list',  array(
																					'fields'=>array('Estado.descripcion'),
																					'conditions'=>array('Estado.pais_id'=>$this->data['Estado']['pais_id']),
																					'order'=>'Estado.descripcion'
																	)
				);
			}
			$this->set($var_configs);
		}


	public function q_on($id_municipio)
	{
		if(!is_null($id_municipio)){
			$id_municipio =  $this->Convert->decode($id_municipio);
			if($this->Municipio->delete($id_municipio, true)){
							$this->Session->setFlash('<em><b>Datos de Municipio</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/municipios/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el municipio a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/municipios/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Municipio</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/municipios/crear/');		
		}
	}



	public function get_estados_list($pais_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Municipio->Estado->find('list', array(
																	'fields'=>array('Estado.descripcion'),
																	'conditions'=>array('Estado.pais_id'=>$pais_id),	
																	'order'=>'Estado.descripcion'
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}



	public function get_local_list($estado_id)
	{
		$this->response->type('xml');
		$array_list = array();
		$array_list = $this->Municipio->find('list', array(
																	'fields'=>array('Municipio.descripcion'),
																	'conditions'=>array('Municipio.estado_id'=>$this->Convert->decode($estado_id))	
																	
																	)
							);
		echo '<?xml version="1.0" encoding="UTF-8"?>
		<List>';
			foreach($array_list as $clave => $valor):
					echo '<Element key="'.$clave.'">'.ucwords(mb_strtolower($valor,"UTF-8")).'</Element>';		
			endforeach;
		echo '</List>';
		$this->autoRender = false;
	}




}
?>