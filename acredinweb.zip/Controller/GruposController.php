<?php
class GruposController extends AppController {


 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_grupo = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Grupo->find('all', array(
																	'order'=>'Grupo.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Grupo']['id'] = (!empty($this->request->data['Grupo']['id']))?$this->Convert->decode($this->request->data['Grupo']['id']):NULL;
					if($this->Grupo->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Grupo Sanguíneo</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/grupos/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/grupos/crear/');		
					}
			}
			if(!is_null($id_grupo)){
				$this->Grupo->recursive=-1;
				$this->data = $this->Grupo->read(NULL,$this->Convert->decode($id_grupo));
			}
			$this->set($var_configs);
		}


	public function q_on($id_grupo)
	{
		if(!is_null($id_grupo)){
			$id_grupo =  $this->Convert->decode($id_grupo);
			if($this->Grupo->delete($id_grupo, true)){
							$this->Session->setFlash('<em><b>Datos de Grupo Sanguíneo</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/grupos/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el grupo sanguíneo a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/grupos/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Grupo Sanguíneo</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/grupos/crear/');		
		}
	}






}
?>