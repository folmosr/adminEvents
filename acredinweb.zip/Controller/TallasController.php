<?php
class TallasController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_talla = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Talla->find('all', array(
																	'order'=>'Talla.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Talla']['id'] = (!empty($this->request->data['Talla']['id']))?$this->Convert->decode($this->request->data['Talla']['id']):NULL;
					if($this->Talla->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Talla</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/tallas/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/tallas/crear/');		
					}
			}
			if(!is_null($id_talla)){
				$this->Talla->recursive=-1;
				$this->data = $this->Talla->read(NULL,$this->Convert->decode($id_talla));
			}
			$this->set($var_configs);
		}


	public function q_on($id_talla)
	{
		if(!is_null($id_talla)){
			$id_talla =  $this->Convert->decode($id_talla);
			if($this->Talla->delete($id_talla, true)){
							$this->Session->setFlash('<em><b>Datos de Talla</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/tallas/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la talla a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/tallas/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Talla</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/tallas/crear/');		
		}
	}






}
?>