<?php
class PaisesController extends AppController {

 	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_pais = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Paise->find('all', array(
																	'order'=>'Paise.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Paise']['id'] = (!empty($this->request->data['Paise']['id']))?$this->Convert->decode($this->request->data['Paise']['id']):NULL;
					if($this->Paise->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de País</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/paises/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/paises/crear/');		
					}
			}
			if(!is_null($id_pais)){
				$this->Paise->recursive=-1;
				$this->data = $this->Paise->read(NULL,$this->Convert->decode($id_pais));
			}
			$this->set($var_configs);
		}


	public function q_on($id_pais)
	{
		if(!is_null($id_pais)){
			$id_pais =  $this->Convert->decode($id_pais);
			
			
			if($this->Paise->delete($id_pais, true)){
							$this->Session->setFlash('<em><b>Datos de País</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/paises/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que el país a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/paises/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de País</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/paises/crear/');		
		}
	}






}
?>