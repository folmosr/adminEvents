<?php
class DisciplinasController extends AppController {

	public function isAuthorized($usuario = NULL) {
	   return (bool)($usuario['Perfil']['descripcion'] === 'Administrador');
	}	

	public function crear($id_disciplina = NULL)
	{
			$var_configs =  array(
					'data'=> $this->Disciplina->find('all', array(
																	'order'=>'Disciplina.descripcion'
																)
														
											)
			
			);
			if(!empty($this->request->data))
			{
					$this->request->data['Disciplina']['id'] = (!empty($this->request->data['Disciplina']['id']))?$this->Convert->decode($this->request->data['Disciplina']['id']):NULL;
					if($this->Disciplina->save($this->request->data)){
							$this->Session->setFlash('<em><b>Datos de Disciplina</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/disciplinas/crear/');		
					}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/disciplinas/crear/');		
					}
			}
			if(!is_null($id_disciplina)){
				$this->Disciplina->recursive=-1;
				$this->data = $this->Disciplina->read(NULL,$this->Convert->decode($id_disciplina));
			}
			$this->set($var_configs);
		}


	public function q_on($id_disciplina)
	{
		if(!is_null($id_disciplina)){
			$id_disciplina =  $this->Convert->decode($id_disciplina);
			if($this->Disciplina->delete($id_disciplina, false)){
							$this->Session->setFlash('<em><b>Datos de Disciplina</b> procesados con éxito.</em>', 'default', array('class' => 'exito'));
							$this->redirect('/disciplinas/crear/');		
				}else{
							$this->Session->setFlash('<em>Han ocurrido errores al intento de procesar los datos.</em><p><b>NOTA:</b> Asegurese que la disciplina a descartar no poseea relación con otros datos vitales para el desempeño del sistema.</p>', 'default', array('class' => 'alerta'));
							$this->redirect('/disciplinas/crear/');		
			}
			
		}else{
							$this->Session->setFlash('<em><b>Datos de Disciplina</b> no recibidos.</em>', 'default', array('class' => 'alerta'));
							$this->redirect('/disciplinas/crear/');		
		}
	}






}
?>