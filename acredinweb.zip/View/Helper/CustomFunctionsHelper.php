<?php
App::uses('AppHelper', 'View/Helper');

class CustomFunctionsHelper extends AppHelper {

	public $helpers = array('Html');

	public function ini_object(){
		  	 App::import('Vendor', 'encode', array('file' => 'encode'.DS.'class.encode.php')); 
			 return(new Encode());
	}
	
	public function encode($a){
		$object = $this->ini_object();
		return($object->AsciiToHex(base64_encode($a))); 
	}

	public function decode($a){
		$object = $this->ini_object();
		return(base64_decode($object->HexToAscii($a))); 
	}
	
	public function getNacionalidad($v){
		return(($v==1)?'V':'E');
	 }
	
	public function completeDate($date)
	{
		setlocale(LC_ALL,"es_ES@euro","es_ES","esp"); 
		echo ucwords(strftime("%A %d de %B del %Y", strtotime($date)));
		
	}
	
	
	public function getNombreCapitan($data)
	{
		$nombre = NULL;
		for($i = 0; $i < count($data[0]['ConjuntosPersona']); $i++):
				if((bool)$data[0]['ConjuntosPersona'][$i]['capitan']){
					$nombre = $data[0]['ConjuntosPersona'][$i]['Persona']['apellido'].' '.$data[0]['ConjuntosPersona'][$i]['Persona']['nombre'];
					break;
				}
		endfor;
		return($nombre);
	}
	
	public function getIntegrantes($data, $html)
	{
		if($html)
		{
			$color = '#fff';
			$text = '<table cellpadding="0" cellspacing="0"><thead ><tr><td>Cédula</td><td>Apellido/Nombre</td></tr></thead><tbody>';
			for($i = 0; $i < count($data[0]['ConjuntosPersona']); $i++):
					$color = ($color=='#fff')?'#f4f4f4':'#fff';
					$text.='<tr style="background:'.$color.'"><td>'.$data[0]['ConjuntosPersona'][$i]['Persona']['cedula'].'</td><td>'.$data[0]['ConjuntosPersona'][$i]['Persona']['apellido'].' '.$data[0]['ConjuntosPersona'][$i]['Persona']['nombre'].'</td></tr>';
			endfor;
			$text.= '</tbody></table>';
		}else{
			$text = NULL;
			for($i = 0; $i < count($data[0]['ConjuntosPersona']); $i++):
					$text='\n'.$data[0]['ConjuntosPersona'][$i]['Persona']['cedula'].'\t'.$data[0]['ConjuntosPersona'][$i]['Persona']['apellido'].' '.$data[0]['ConjuntosPersona'][$i]['Persona']['nombre'];
			endfor;
		}
		return($text);
	}
		
}
?>